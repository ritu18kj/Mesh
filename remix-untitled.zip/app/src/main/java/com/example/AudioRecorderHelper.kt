package com.example

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File
import kotlin.concurrent.thread

class AudioRecorderHelper(private val context: Context) {
    private var recorder: MediaRecorder? = null
    var outputFile: File? = null
        private set

    @Volatile
    private var isPreparing = false

    fun startRecording() {
        if (isPreparing || recorder != null) return
        isPreparing = true
        
        thread {
            try {
                val fileName = "audio_msg_${System.currentTimeMillis()}.m4a"
                val newOutputFile = File(context.cacheDir, fileName)
                
                val newRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    MediaRecorder(context)
                } else {
                    @Suppress("DEPRECATION")
                    MediaRecorder()
                }

                newRecorder.setAudioSource(MediaRecorder.AudioSource.MIC)
                newRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                newRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                newRecorder.setOutputFile(newOutputFile.absolutePath)
                
                newRecorder.prepare()
                newRecorder.start()
                
                outputFile = newOutputFile
                recorder = newRecorder
            } catch (e: Exception) {
                Log.e("AudioRecorder", "Start failed", e)
                try {
                    recorder?.release()
                } catch (ex: Exception) {}
                recorder = null
                outputFile = null
            } finally {
                isPreparing = false
            }
        }
    }

    fun stopRecording(): File? {
        if (isPreparing) {
            // It's still preparing, abort recording.
            try {
                recorder?.release()
            } catch (e: Exception) {}
            recorder = null
            outputFile?.delete()
            outputFile = null
            isPreparing = false
            return null
        }
        
        var validFile = outputFile
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            Log.e("AudioRecorder", "Stop failed", e)
            validFile?.delete()
            validFile = null
        } finally {
            recorder = null
        }
        
        // Final size check
        if (validFile != null && validFile.exists() && validFile.length() > 0) {
            return validFile
        } else {
            validFile?.delete()
            outputFile = null
            return null
        }
    }
}
