package com.example

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

data class RadarNode(
    val id: String,
    val name: String,
    val distanceMeters: Double,
    val bearingDegrees: Double,
    val xPos: Float,
    val yPos: Float
)

@Composable
fun RadarView(
    userLocations: Map<String, LocationMessage>,
    myId: String,
    knownUserNames: Map<String, String> = emptyMap(),
    isEcoMode: Boolean = false,
    onToggleEco: (Boolean) -> Unit = {},
    onRefreshLocation: () -> Unit = {},
    onNodeAction: (nodeId: String, nodeName: String, action: String) -> Unit = { _, _, _ -> }
) {
    val myLocation = userLocations[myId]
    var selectedNode by remember { mutableStateOf<RadarNode?>(null) }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0A0F1C))) {
        if (myLocation == null) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.align(Alignment.Center)) {
                CircularProgressIndicator(color = Color(0xFF10B981), strokeWidth = 3.dp, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "Calibrating Mesh Radar...",
                    color = Color(0xFFA1A1AA),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onRefreshLocation,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF10B981))
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Trigger Location Fix")
                }
            }
            return@Box
        }

        val infiniteTransition = rememberInfiniteTransition(label = "RadarSweep")
        val rotation by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(if (isEcoMode) 8000 else 4000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "RadarRotation"
        )
        
        val pulseAnimation by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(if (isEcoMode) 4000 else 2000, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "RadarPulse"
        )

        // Precompute nodes
        val maxDistanceMeters = 150.0
        val detectedNodes = remember(userLocations, myLocation) {
            userLocations.filter { it.key != myId }.map { (id, loc) ->
                val dist = haversine(myLocation.lat, myLocation.lng, loc.lat, loc.lng)
                val bear = bearing(myLocation.lat, myLocation.lng, loc.lat, loc.lng)
                val fallbackName = if (loc.name.isNotBlank()) loc.name else "Node ${id.take(4)}"
                val nodeName = knownUserNames[id] ?: fallbackName
                RadarNode(id, nodeName, dist, bear, 0f, 0f)
            }
        }
        
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val widthPx = constraints.maxWidth.toFloat()
            val heightPx = constraints.maxHeight.toFloat()
            val center = Offset(widthPx / 2, heightPx / 2)
            val maxRadius = (widthPx / 2.2f).coerceAtMost(heightPx / 2.4f)

            Canvas(modifier = Modifier.fillMaxSize()) {
                // Pulsing outer perimeter
                drawCircle(
                    color = Color(0xFF10B981).copy(alpha = 0.1f * (1f - pulseAnimation)),
                    radius = maxRadius + (pulseAnimation * 40f),
                    center = center
                )
                
                // Distance Range Rings (Near 25m, Medium 75m, Far 150m)
                val ringLabels = listOf(0.25f, 0.5f, 0.75f, 1.0f)
                ringLabels.forEach { fraction ->
                    drawCircle(
                        color = Color(0xFF1E293B).copy(alpha = 0.9f),
                        radius = maxRadius * fraction,
                        center = center,
                        style = Stroke(width = 1.dp.toPx())
                    )
                }

                // Crosshairs
                drawLine(
                    color = Color(0xFF1E293B).copy(alpha = 0.6f),
                    start = Offset(center.x, center.y - maxRadius),
                    end = Offset(center.x, center.y + maxRadius),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = Color(0xFF1E293B).copy(alpha = 0.6f),
                    start = Offset(center.x - maxRadius, center.y),
                    end = Offset(center.x + maxRadius, center.y),
                    strokeWidth = 1.dp.toPx()
                )
                
                // Sweeping beam
                rotate(degrees = rotation, pivot = center) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xFF10B981).copy(alpha = 0.05f),
                                Color(0xFF10B981).copy(alpha = 0.45f)
                            ),
                            center = center
                        ),
                        startAngle = -90f,
                        sweepAngle = 90f,
                        useCenter = true,
                        topLeft = Offset(center.x - maxRadius, center.y - maxRadius),
                        size = Size(maxRadius * 2, maxRadius * 2)
                    )
                    drawLine(
                        color = Color(0xFF10B981),
                        start = center,
                        end = Offset(center.x, center.y - maxRadius),
                        strokeWidth = 2.5f
                    )
                }
                
                // Local device indicator
                drawCircle(color = Color(0xFF10B981).copy(alpha = 0.25f), radius = 28f, center = center)
                drawCircle(color = Color(0xFF10B981), radius = 10f, center = center)
            }

            val density = androidx.compose.ui.platform.LocalDensity.current

            // Interactive clickable node blips
            detectedNodes.forEach { node ->
                val clampedDist = node.distanceMeters.coerceAtMost(maxDistanceMeters)
                val radiusPx = (clampedDist / maxDistanceMeters) * maxRadius
                val angleRad = Math.toRadians(node.bearingDegrees - 90).toFloat()
                val x: Float = center.x + (radiusPx * cos(angleRad.toDouble())).toFloat()
                val y: Float = center.y + (radiusPx * sin(angleRad.toDouble())).toFloat()

                val xDp = with(density) { x.toDp() } - 22.dp
                val yDp = with(density) { y.toDp() } - 22.dp

                // Blip glow calculation
                val blipAngle = (node.bearingDegrees + 360) % 360
                val currentAngle = (rotation + 360) % 360
                val diff = (currentAngle - blipAngle + 360) % 360
                val isSwept = diff < 90

                Box(
                    modifier = Modifier
                        .offset(x = xDp, y = yDp)
                        .size(44.dp)
                        .clickable {
                            selectedNode = node.copy(xPos = x.toFloat(), yPos = y.toFloat())
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(if (isSwept) 28.dp else 20.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF25D366).copy(alpha = if (isSwept) 0.35f else 0.15f))
                    )
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF25D366))
                    )
                }
            }
        }
        
        // Header
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "M E S H   R A D A R",
                color = Color(0xFF10B981),
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                "${detectedNodes.size} nodes spotted • Ring zones: 25m | 75m | 150m",
                color = Color(0xFFA1A1AA),
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Battery saver duty-cycle toggle pill & Ping beacon button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isEcoMode) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFF1F2C34),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isEcoMode) Color(0xFF10B981) else Color(0xFF374151)
                    ),
                    modifier = Modifier.clickable { onToggleEco(!isEcoMode) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isEcoMode) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                            contentDescription = "Battery Mode",
                            tint = if (isEcoMode) Color(0xFF10B981) else Color(0xFF9CA3AF),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isEcoMode) "Eco (50% Battery Save)" else "Continuous Scan",
                            fontSize = 11.sp,
                            color = if (isEcoMode) Color(0xFF10B981) else Color(0xFF9CA3AF),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF1F2C34),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF374151)),
                    modifier = Modifier.clickable { onRefreshLocation() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Ping Nodes",
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Ping Mesh",
                            fontSize = 11.sp,
                            color = Color(0xFFE4E4E7),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Selected Node 1-Tap Quick Action Sheet
        selectedNode?.let { node ->
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1F2C34))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = node.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                            val distanceText = if (node.distanceMeters < 5) "Immediate (< 5m)" else "${node.distanceMeters.toInt()}m away"
                            Text(
                                text = "Proximity: $distanceText",
                                color = Color(0xFF25D366),
                                fontSize = 13.sp
                            )
                        }
                        IconButton(onClick = { selectedNode = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF8696A0))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                onNodeAction(node.id, node.name, "chat")
                                selectedNode = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Chat", color = Color.Black, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                onNodeAction(node.id, node.name, "call")
                                selectedNode = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF005D4B)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Call", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// Haversine formula for distance in meters
fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val R = 6371e3 // metres
    val φ1 = Math.toRadians(lat1)
    val φ2 = Math.toRadians(lat2)
    val Δφ = Math.toRadians(lat2 - lat1)
    val Δλ = Math.toRadians(lon2 - lon1)
    val a = sin(Δφ / 2) * sin(Δφ / 2) +
            cos(φ1) * cos(φ2) *
            sin(Δλ / 2) * sin(Δλ / 2)
    val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
}

// Initial bearing in degrees
fun bearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val φ1 = Math.toRadians(lat1)
    val φ2 = Math.toRadians(lat2)
    val Δλ = Math.toRadians(lon2 - lon1)
    val y = sin(Δλ) * cos(φ2)
    val x = cos(φ1) * sin(φ2) - sin(φ1) * cos(φ2) * cos(Δλ)
    val θ = Math.atan2(y, x)
    return (Math.toDegrees(θ) + 360) % 360
}
