package com.example

import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.GlobalScope
import java.util.concurrent.ConcurrentHashMap

class MeshRouter(private val localNodeId: String) {
    var localNodeName: String = ""
    private val cryptoManager = CryptoManager()

    data class NetworkMessage(
        val messageId: String,
        val senderId: String,
        val senderName: String = "",
        val ttl: Int,
        val payload: String,
        val timestamp: Long,
        val signature: String = "",
        val publicKey: String = ""
    )

    private val blockedUsers = ConcurrentHashMap.newKeySet<String>()

    fun blockUser(userId: String) {
        blockedUsers.add(userId)
        Log.i("MeshRouter", "User $userId blocked.")
    }

    private val messageCache = ConcurrentHashMap<String, Long>()
    private val CACHE_EXPIRY_MS = 10 * 60 * 1000L

    private val _incomingMessages = MutableSharedFlow<NetworkMessage>(extraBufferCapacity = 10)
    val incomingMessages = _incomingMessages.asSharedFlow()

    private val _outboundBroadcasts = MutableSharedFlow<NetworkMessage>(extraBufferCapacity = 10)
    val outboundBroadcasts = _outboundBroadcasts.asSharedFlow()

    val localPublicKey: String
        get() = cryptoManager.publicKeyBase64

    private val chunkBuffer = ConcurrentHashMap<String, MutableMap<Int, String>>()
    private val chunkTimestamp = ConcurrentHashMap<String, Long>()

    private fun emitDecrypted(message: NetworkMessage) {
        var finalPayload = message.payload
        if (finalPayload.startsWith("ENC:")) {
            val aesKey = com.example.MeshNetworkManager.roomAesKey
            if (aesKey != null) {
                try {
                    finalPayload = com.example.CryptoManager.decryptAES(finalPayload.removePrefix("ENC:"), aesKey)
                } catch (e: Exception) {
                    Log.e("MeshRouter", "Failed to decrypt message, dropping", e)
                    return
                }
            } else {
                Log.w("MeshRouter", "Received encrypted message but we have no AES key. Dropping.")
                return
            }
        }
        _incomingMessages.tryEmit(message.copy(payload = finalPayload))
    }

    private fun handleChunk(message: NetworkMessage) {
        try {
            val parts = message.payload.split(":", limit = 5)
            if (parts.size == 5 && parts[0] == "CHUNK") {
                val groupId = parts[1]
                val index = parts[2].toInt()
                val total = parts[3].toInt()
                val data = parts[4]

                val groupMap = chunkBuffer.getOrPut(groupId) { ConcurrentHashMap() }
                groupMap[index] = data
                chunkTimestamp[groupId] = System.currentTimeMillis()

                if (groupMap.size == total) {
                    val fullPayload = StringBuilder()
                    for (i in 0 until total) {
                        fullPayload.append(groupMap[i] ?: "")
                    }
                    chunkBuffer.remove(groupId)
                    chunkTimestamp.remove(groupId)
                    
                    val assembledMessage = message.copy(
                        messageId = groupId,
                        payload = fullPayload.toString()
                    )
                    emitDecrypted(assembledMessage)
                }
            }
        } catch (e: Exception) {
            Log.e("MeshRouter", "Error handling chunk", e)
        }
    }

    fun processIncomingPacket(message: NetworkMessage) {
        cleanupCache()

        if (blockedUsers.contains(message.senderId)) {
            Log.d("MeshRouter", "Message dropped from blocked user: ${message.senderId}")
            return
        }

        if (messageCache.containsKey(message.messageId)) {
            Log.d("MeshRouter", "Duplicate message dropped: ${message.messageId}")
            return
        }

        if (message.senderId == localNodeId) {
            return
        }

        val dataToVerify = "${message.messageId}:${message.senderId}:${message.payload}:${message.timestamp}"
        val isValid = CryptoManager.verify(dataToVerify, message.signature, message.publicKey)

        if (!isValid) {
            Log.w("MeshRouter", "Invalid signature for message: ${message.messageId}. Dropping spoofed message.")
            return
        }

        messageCache[message.messageId] = System.currentTimeMillis()
        Log.i("MeshRouter", "New verified message received: ${message.messageId} from ${message.senderId}")
        
        if (message.payload.startsWith("CHUNK:")) {
            handleChunk(message)
        } else {
            emitDecrypted(message)
        }

        val newTtl = message.ttl - 1
        if (newTtl > 0) {
            val rebroadcastMessage = message.copy(ttl = newTtl)
            Log.d("MeshRouter", "Rebroadcasting message ${message.messageId} with TTL $newTtl")
            _outboundBroadcasts.tryEmit(rebroadcastMessage)
        } else {
            Log.d("MeshRouter", "Message ${message.messageId} reached max hops (TTL=0). Dropping.")
        }
    }

    fun routeLocalMessage(rawPayload: String) {
        try {
            val payload = com.example.MeshNetworkManager.roomAesKey?.let { 
                "ENC:" + com.example.CryptoManager.encryptAES(rawPayload, it) 
            } ?: rawPayload
            val maxChunkSize = 450
            if (payload.length > maxChunkSize) {
                val groupId = java.util.UUID.randomUUID().toString()
                val chunks = payload.chunked(maxChunkSize)
                kotlinx.coroutines.GlobalScope.launch {
                    chunks.forEachIndexed { index, chunkData ->
                        val chunkPayload = "CHUNK:$groupId:$index:${chunks.size}:$chunkData"
                        sendNetworkMessage(chunkPayload)
                        kotlinx.coroutines.delay(200)
                    }
                }
            } else {
                sendNetworkMessage(payload)
            }
        } catch(e: Exception) {
            Log.e("MeshRouter", "Error routing local message", e)
        }
    }

    private fun sendNetworkMessage(payload: String) {
        try {
            val messageId = java.util.UUID.randomUUID().toString()
            val timestamp = System.currentTimeMillis()
            
            val dataToSign = "$messageId:$localNodeId:$payload:$timestamp"
            val signature = cryptoManager.sign(dataToSign)
    
            val networkMessage = NetworkMessage(
                messageId = messageId,
                senderId = localNodeId,
                senderName = localNodeName,
                ttl = 3,
                payload = payload,
                timestamp = timestamp,
                signature = signature,
                publicKey = cryptoManager.publicKeyBase64
            )
    
            messageCache[messageId] = System.currentTimeMillis()
            Log.i("MeshRouter", "Routing local message for broadcast: $messageId")
            DiagnosticLogger.log("Message Lifecycle", "Router Processing", "Host phone assigned unique Message ID and signed it: $messageId", EventStatus.SUCCESS)
            _outboundBroadcasts.tryEmit(networkMessage)
        } catch(e: Exception) {
            Log.e("MeshRouter", "Error sending network message", e)
            DiagnosticLogger.log("Message Lifecycle", "Router Processing", "Failed to process message: ${e.message}", EventStatus.ERROR)
        }
    }

    private fun cleanupCache() {
        val now = System.currentTimeMillis()
        val iterator = messageCache.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (now - entry.value > CACHE_EXPIRY_MS) {
                iterator.remove()
            }
        }
        
        val chunkIterator = chunkTimestamp.entries.iterator()
        while (chunkIterator.hasNext()) {
            val entry = chunkIterator.next()
            if (now - entry.value > CACHE_EXPIRY_MS) {
                chunkBuffer.remove(entry.key)
                chunkIterator.remove()
            }
        }
    }
}
