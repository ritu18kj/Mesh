package com.example

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.text.DecimalFormat

object MeshStorageManager {
    private const val TAG = "MeshStorageManager"
    private const val CACHE_DIR_NAME = "mesh_cache"
    private const val MAX_CACHE_SIZE_BYTES = 100 * 1024 * 1024L // 100 MB max cache cap
    private const val PURGE_TARGET_BYTES = 60 * 1024 * 1024L   // Purge down to 60 MB
    private const val MAX_FILE_AGE_MS = 24 * 60 * 60 * 1000L   // 24 hours age limit

    fun getCacheDir(context: Context): File {
        val dir = File(context.cacheDir, CACHE_DIR_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun getCacheFile(context: Context, fileName: String): File {
        return File(getCacheDir(context), sanitizeFileName(fileName))
    }

    /**
     * Sanitizes fileName to avoid directory traversal or invalid characters.
     */
    fun sanitizeFileName(rawName: String): String {
        val cleanName = rawName.substringAfterLast("/").substringAfterLast("\\").trim()
        return if (cleanName.isBlank()) "mesh_file_${System.currentTimeMillis()}" else cleanName
    }

    /**
     * Resolves local file if available in cache or legacy shared directory.
     */
    fun findLocalFile(context: Context, urlOrName: String): File? {
        val fileName = sanitizeFileName(urlOrName)
        
        // 1. Primary: Check context.cacheDir/mesh_cache/
        val cacheFile = File(getCacheDir(context), fileName)
        if (cacheFile.exists() && cacheFile.length() > 0) {
            return cacheFile
        }

        // 2. Secondary: Check context.filesDir/shared_files/ (legacy fallback)
        val legacyFile = File(File(context.filesDir, "shared_files"), fileName)
        if (legacyFile.exists() && legacyFile.length() > 0) {
            return legacyFile
        }

        // 3. Tertiary: If urlOrName was a direct local path or URI
        if (urlOrName.startsWith("/")) {
            val directFile = File(urlOrName)
            if (directFile.exists() && directFile.length() > 0) return directFile
        }

        return null
    }

    /**
     * Returns a content:// FileProvider URI for direct local sharing or opening.
     */
    fun getFileProviderUri(context: Context, file: File): Uri? {
        return try {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create FileProvider URI for ${file.absolutePath}", e)
            null
        }
    }

    /**
     * Saves an incoming Uri (e.g., picked photo or document) into context.cacheDir/mesh_cache/.
     */
    suspend fun saveUriToCache(context: Context, uri: Uri): Pair<File, String> = withContext(Dispatchers.IO) {
        var fileName = getDisplayNameFromUri(context, uri) ?: "mesh_upload_${System.currentTimeMillis()}"
        val mimeType = context.contentResolver.getType(uri) ?: getMimeType(fileName)
        
        // Ensure extension exists
        if (!fileName.contains(".") && mimeType.isNotBlank()) {
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)
            if (ext != null) {
                fileName += ".$ext"
            } else if (mimeType.startsWith("image/")) {
                fileName += ".jpg"
            }
        }

        fileName = sanitizeFileName(fileName)
        val targetFile = File(getCacheDir(context), fileName)

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(targetFile).use { output ->
                input.copyTo(output)
            }
        }

        // Trigger asynchronous background cache purge check
        autoPurgeCache(context)

        Pair(targetFile, fileName)
    }

    /**
     * Streams an InputStream into context.cacheDir/mesh_cache/ under the given fileName.
     */
    suspend fun saveStreamToCache(context: Context, fileName: String, inputStream: InputStream): File = withContext(Dispatchers.IO) {
        val cleanName = sanitizeFileName(fileName)
        val targetFile = File(getCacheDir(context), cleanName)
        
        FileOutputStream(targetFile).use { output ->
            inputStream.copyTo(output)
        }

        autoPurgeCache(context)
        targetFile
    }

    /**
     * Auto-purges temporary cached transfer files:
     * 1. Evicts files older than 24 hours.
     * 2. If remaining cache exceeds 100MB, evicts oldest files until below 60MB.
     */
    fun autoPurgeCache(context: Context) {
        try {
            val cacheDir = getCacheDir(context)
            val files = cacheDir.listFiles() ?: return
            val now = System.currentTimeMillis()

            var totalSize = 0L
            val fileList = mutableListOf<File>()

            for (file in files) {
                if (!file.isFile) continue
                
                // Evict files older than 24 hours
                if (now - file.lastModified() > MAX_FILE_AGE_MS) {
                    file.delete()
                    Log.d(TAG, "Auto-purged expired cache file: ${file.name}")
                } else {
                    totalSize += file.length()
                    fileList.add(file)
                }
            }

            // If total cache size still exceeds 100MB, purge oldest files
            if (totalSize > MAX_CACHE_SIZE_BYTES) {
                fileList.sortBy { it.lastModified() } // oldest first
                for (file in fileList) {
                    val size = file.length()
                    if (file.delete()) {
                        totalSize -= size
                        Log.d(TAG, "Evicted cache file due to 100MB cap: ${file.name}")
                    }
                    if (totalSize <= PURGE_TARGET_BYTES) break
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error during cache auto-purge", e)
        }
    }

    /**
     * Streams file directly into public Downloads/MeshChat/ folder via MediaStore on Android 10+
     * or public Downloads directory on legacy Android.
     */
    suspend fun saveFileToPublicDownloads(
        context: Context,
        sourceFile: File,
        displayName: String? = null
    ): Uri? = withContext(Dispatchers.IO) {
        val fileName = sanitizeFileName(displayName ?: sourceFile.name)
        val mimeType = getMimeType(fileName)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/MeshChat")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { outStream ->
                        FileInputStream(sourceFile).use { inStream ->
                            inStream.copyTo(outStream)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    Log.i(TAG, "Saved to public Downloads/MeshChat: $uri")
                    return@withContext uri
                }
            } else {
                // Legacy external storage (< Android 10)
                @Suppress("DEPRECATION")
                val downloadsDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MeshChat")
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val destFile = File(downloadsDir, fileName)
                FileInputStream(sourceFile).use { inStream ->
                    FileOutputStream(destFile).use { outStream ->
                        inStream.copyTo(outStream)
                    }
                }
                return@withContext Uri.fromFile(destFile)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save file to public Downloads", e)
        }
        return@withContext null
    }

    /**
     * Streams image file directly into public Pictures/MeshChat/ folder via MediaStore.
     */
    suspend fun saveImageToPublicGallery(
        context: Context,
        sourceFile: File,
        displayName: String? = null
    ): Uri? = withContext(Dispatchers.IO) {
        val fileName = sanitizeFileName(displayName ?: sourceFile.name)
        val mimeType = getMimeType(fileName).let { if (it.startsWith("image/")) it else "image/jpeg" }

        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/MeshChat")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { outStream ->
                    FileInputStream(sourceFile).use { inStream ->
                        inStream.copyTo(outStream)
                    }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }
                Log.i(TAG, "Saved image to public Gallery: $uri")
                return@withContext uri
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save image to Gallery", e)
        }
        return@withContext null
    }

    /**
     * Robust MIME type determination for all common extensions.
     */
    fun getMimeType(fileNameOrUrl: String): String {
        val ext = getFileExtension(fileNameOrUrl).lowercase()
        val mapped = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        if (!mapped.isNullOrBlank()) return mapped

        return when (ext) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "svg" -> "image/svg+xml"
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            "mp3" -> "audio/mpeg"
            "m4a", "aac" -> "audio/mp4"
            "wav" -> "audio/wav"
            "ogg" -> "audio/ogg"
            "pdf" -> "application/pdf"
            "zip" -> "application/zip"
            "apk" -> "application/vnd.android.package-archive"
            "json" -> "application/json"
            "txt", "log" -> "text/plain"
            "html", "htm" -> "text/html"
            "doc", "docx" -> "application/msword"
            "xls", "xlsx" -> "application/vnd.ms-excel"
            "ppt", "pptx" -> "application/vnd.ms-powerpoint"
            else -> "application/octet-stream"
        }
    }

    fun getFileExtension(fileNameOrUrl: String): String {
        val clean = sanitizeFileName(fileNameOrUrl)
        return clean.substringAfterLast(".", "")
    }

    fun isImageFile(fileNameOrUrl: String): Boolean {
        val ext = getFileExtension(fileNameOrUrl).lowercase()
        return ext in listOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic") ||
                getMimeType(fileNameOrUrl).startsWith("image/")
    }

    fun isAudioFile(fileNameOrUrl: String): Boolean {
        val ext = getFileExtension(fileNameOrUrl).lowercase()
        return ext in listOf("m4a", "mp3", "aac", "wav", "ogg", "opus", "flac") ||
                fileNameOrUrl.contains("/audio_") ||
                getMimeType(fileNameOrUrl).startsWith("audio/")
    }

    fun isVideoFile(fileNameOrUrl: String): Boolean {
        val ext = getFileExtension(fileNameOrUrl).lowercase()
        return ext in listOf("mp4", "mkv", "webm", "avi", "mov", "3gp") ||
                getMimeType(fileNameOrUrl).startsWith("video/")
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
    }

    @SuppressLint("Range")
    private fun getDisplayNameFromUri(context: Context, uri: Uri): String? {
        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (index != -1) {
                            return cursor.getString(index)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error getting display name from cursor", e)
            }
        }
        return uri.lastPathSegment?.substringAfterLast("/")
    }
}
