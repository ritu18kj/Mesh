package com.example
import com.example.MeshNode


import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

@SuppressLint("MissingPermission")
class BleMeshManager(private val context: Context) {
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager.adapter
    private val scanner = bluetoothAdapter?.bluetoothLeScanner
    private val advertiser = bluetoothAdapter?.bluetoothLeAdvertiser

    // Unique UUIDs for our Mesh application
    private val MESH_SERVICE_UUID = UUID.fromString("0000FEAA-0000-1000-8000-00805F9B34FB")
    private val MESH_CHAR_UUID = UUID.fromString("0000FEAB-0000-1000-8000-00805F9B34FB")
    private val PARCEL_UUID = ParcelUuid(MESH_SERVICE_UUID)

    private val _incomingPackets = MutableSharedFlow<String>(extraBufferCapacity = 50)
    val incomingPackets = _incomingPackets.asSharedFlow()
    
    private val _activeNodes = MutableStateFlow<List<MeshNode>>(emptyList())
    val activeNodes: StateFlow<List<MeshNode>> = _activeNodes.asStateFlow()


    private var isScanning = false
    var emergencyMode = false 
    var longRangeMode = true // BLE Coded PHY (S=8) long-range fallback
    private var isAdvertising = false
    private var gattServer: BluetoothGattServer? = null

    val isCodedPhySupported: Boolean
        get() = (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O && bluetoothAdapter?.isLeCodedPhySupported == true)
    
    // The current payload we are hosting for others to read
    private var currentPayload: ByteArray = ByteArray(0)
    private var pendingPwd: String? = null
    private var pendingIp: String? = null
    
    // Queue for payloads to broadcast
    private val broadcastQueue = kotlinx.coroutines.channels.Channel<String>(kotlinx.coroutines.channels.Channel.UNLIMITED)
    private val scope = CoroutineScope(Dispatchers.IO)
    
    init {
        scope.launch {
            for (payload in broadcastQueue) {
                if (bluetoothAdapter?.isEnabled == true && advertiser != null) {
                    if (payload.contains("\"sys_handshake\"")) {
                        try {
                            val mainObj = org.json.JSONObject(payload)
                            val innerObj = org.json.JSONObject(mainObj.getString("payload"))
                            val ssid = innerObj.getString("ssid")
                            val pwd = innerObj.getString("pwd")
                            val ip = innerObj.getString("ip")
                            val isPrivate = innerObj.optBoolean("isPrivate", false)
                            
                            // Start with SSID, queue the rest for automatic sequential reads
                            pendingPwd = if (isPrivate) null else pwd
                            pendingIp = ip
                            val chunk = if (isPrivate) "S:PRIVATE|$ssid" else "S:$ssid"
                            val chunks = listOf(chunk) // Just advertise S:, the rest happens on read
                            for (c in chunks) {
                                currentPayload = c.toByteArray(java.nio.charset.StandardCharsets.UTF_8)
                                val txPower = if (emergencyMode) android.bluetooth.le.AdvertiseSettings.ADVERTISE_TX_POWER_HIGH else android.bluetooth.le.AdvertiseSettings.ADVERTISE_TX_POWER_LOW
                                val advMode = if (emergencyMode) android.bluetooth.le.AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY else android.bluetooth.le.AdvertiseSettings.ADVERTISE_MODE_BALANCED
                                val data = android.bluetooth.le.AdvertiseData.Builder()
                                    .setIncludeDeviceName(false)
                                    .addServiceUuid(PARCEL_UUID)
                                    .build()
                                val settings = android.bluetooth.le.AdvertiseSettings.Builder()
                                    .setAdvertiseMode(advMode)
                                    .setConnectable(true)
                                    .setTimeout(0)
                                    .setTxPowerLevel(txPower)
                                    .build()
                                try {
                                    advertiser.stopAdvertising(advertiseCallback)
                                    advertiser.startAdvertising(settings, data, advertiseCallback)
                                    isAdvertising = true
                                } catch (e: Exception) {}

                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                    if (bluetoothAdapter.isLeCodedPhySupported && bluetoothAdapter.isLeExtendedAdvertisingSupported) {
                                        try {
                                            val params = android.bluetooth.le.AdvertisingSetParameters.Builder()
                                                .setLegacyMode(false)
                                                .setConnectable(true)
                                                .setInterval(android.bluetooth.le.AdvertisingSetParameters.INTERVAL_LOW)
                                                .setTxPowerLevel(android.bluetooth.le.AdvertisingSetParameters.TX_POWER_HIGH)
                                                .setPrimaryPhy(android.bluetooth.BluetoothDevice.PHY_LE_CODED)
                                                .setSecondaryPhy(android.bluetooth.BluetoothDevice.PHY_LE_CODED)
                                                .build()
                                            
                                            if (currentAdvertisingSet != null) {
                                                advertiser.stopAdvertisingSet(advertiseSetCallback as android.bluetooth.le.AdvertisingSetCallback)
                                            }
                                            advertiser.startAdvertisingSet(params, data, null, null, null, advertiseSetCallback as android.bluetooth.le.AdvertisingSetCallback)
                                        } catch (e: Exception) {}
                                    }
                                }
                                kotlinx.coroutines.delay(2000)
                            }
                            continue
                        } catch(e: Exception) { e.printStackTrace() }
                    }
                    
                    currentPayload = payload.toByteArray(java.nio.charset.StandardCharsets.UTF_8)
                    android.util.Log.d("BleMeshManager", "Setting current payload to ${currentPayload.size} bytes")
                    
                    val txPower = if (emergencyMode) AdvertiseSettings.ADVERTISE_TX_POWER_HIGH else AdvertiseSettings.ADVERTISE_TX_POWER_LOW
                    val advMode = if (emergencyMode) AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY else AdvertiseSettings.ADVERTISE_MODE_BALANCED
                    val settings = AdvertiseSettings.Builder()
                        .setAdvertiseMode(advMode)
                        .setConnectable(true)
                        .setTimeout(0)
                        .setTxPowerLevel(txPower)
                        .build()

                    val data = AdvertiseData.Builder()
                        .setIncludeDeviceName(false)
                        .addServiceUuid(PARCEL_UUID)
                        .build()

                    try {
                        advertiser.stopAdvertising(advertiseCallback)
                        advertiser.startAdvertising(settings, data, advertiseCallback)
                        isAdvertising = true
                    } catch (e: Exception) {
                        Log.e("BleMeshManager", "Failed to start advertising", e)
                    }
                }
                delay(4000) // Hold the advertisement for 4 seconds so peers can read it
            }
        }
    }

    // Handshake cache for sequential BLE reads
    private var lastHandshakeSsid: String? = null
    private var lastHandshakePwd: String? = null
    private var lastHandshakeIp: String? = null

    // Keep track of recently read devices to avoid infinite read loops
    private val recentDevices = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private val gattServerCallback = object : BluetoothGattServerCallback() {
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            Log.d("BleMeshManager", "GATT Server connection state change: $status -> $newState")
        }

        override fun onCharacteristicReadRequest(
            device: BluetoothDevice, requestId: Int, offset: Int, characteristic: BluetoothGattCharacteristic
        ) {
            if (characteristic.uuid == MESH_CHAR_UUID) {
                // GATT allows reading in chunks. `offset` tells us where to start.
                val remaining = currentPayload.size - offset
                val value = if (remaining > 0) {
                    val length = kotlin.math.min(remaining, 500)
                    currentPayload.copyOfRange(offset, offset + length)
                } else {
                    ByteArray(0)
                }
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value)
                
                // Automatic Sequential Fallback (SSID -> PWD -> IP)
                val sentStr = String(value, java.nio.charset.StandardCharsets.UTF_8)
                if (sentStr.startsWith("S:")) {
                    if (pendingPwd != null) {
                        currentPayload = ("P:" + pendingPwd).toByteArray(java.nio.charset.StandardCharsets.UTF_8)
                    } else if (pendingIp != null) {
                        currentPayload = ("I:" + pendingIp).toByteArray(java.nio.charset.StandardCharsets.UTF_8)
                    }
                } else if (sentStr.startsWith("P:") && pendingIp != null) {
                    currentPayload = ("I:" + pendingIp).toByteArray(java.nio.charset.StandardCharsets.UTF_8)
                }
            } else {
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_FAILURE, offset, null)
            }
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val now = System.currentTimeMillis()
            
            val rssi = result.rssi
            _activeNodes.update { nodes ->
                val existing = nodes.find { it.id == device.address }
                if (existing != null) {
                    nodes.map { if (it.id == device.address) it.copy(signalStrength = rssi) else it }
                } else {
                    val name = device.name ?: "Unknown Device"
                    nodes + MeshNode(device.address, name, rssi)
                }
            }
            
            // Only connect if we haven't read from this device in the last 2 seconds
            if (!recentDevices.containsKey(device.address) || (now - recentDevices[device.address]!! > 2000)) {
                recentDevices[device.address] = now
                connectAndRead(device)
            }
        }
    }
    
    private fun connectAndRead(device: BluetoothDevice) {
        Log.d("BleMeshManager", "Connecting to GATT server on ${device.address}")
        device.connectGatt(context, false, object : BluetoothGattCallback() {
            private var fullPayloadBytes = ByteArray(0)

            override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    Log.d("BleMeshManager", "Connected to GATT server on ${gatt.device.address}, requesting MTU 512")
                    val mtuRequested = gatt.requestMtu(512)
                    if (!mtuRequested) {
                        Log.d("BleMeshManager", "requestMtu failed, discovering services immediately")
                        gatt.discoverServices()
                    }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    Log.d("BleMeshManager", "Disconnected from GATT server on ${gatt.device.address}")
                    gatt.close()
                }
            }
            override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
                super.onMtuChanged(gatt, mtu, status)
                Log.d("BleMeshManager", "MTU changed to $mtu for ${gatt.device.address}, discovering services")
                gatt.discoverServices()
            }
            override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    val service = gatt.getService(MESH_SERVICE_UUID)
                    val char = service?.getCharacteristic(MESH_CHAR_UUID)
                    if (char != null) {
                        Log.d("BleMeshManager", "Found Mesh Characteristic, requesting read")
                        gatt.readCharacteristic(char)
                    } else {
                        Log.w("BleMeshManager", "Mesh Characteristic not found on ${gatt.device.address}")
                        gatt.close()
                    }
                } else {
                    Log.w("BleMeshManager", "Service discovery failed with status $status")
                    gatt.close()
                }
            }

            @Suppress("DEPRECATION")
            override fun onCharacteristicRead(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                value: ByteArray,
                status: Int
            ) {
                if (status == BluetoothGatt.GATT_SUCCESS && characteristic.uuid == MESH_CHAR_UUID) {
                    if (value.isNotEmpty()) {
                        fullPayloadBytes += value
                        val payloadString = String(fullPayloadBytes, java.nio.charset.StandardCharsets.UTF_8)
                        _incomingPackets.tryEmit(payloadString)
                    }
                }
                gatt.close()
            }

            override fun onCharacteristicRead(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                status: Int
            ) {
                if (status == BluetoothGatt.GATT_SUCCESS && characteristic.uuid == MESH_CHAR_UUID) {
                    val data = characteristic.value
                    if (data != null && data.isNotEmpty()) {
                        val payloadString = String(data, java.nio.charset.StandardCharsets.UTF_8)
                        
                        if (payloadString.startsWith("S:")) {
                            val rawSsid = payloadString.substring(2)
                            if (rawSsid.startsWith("PRIVATE|")) {
                                lastHandshakeSsid = rawSsid.substring(8)
                                lastHandshakePwd = "PRIVATE"
                            } else {
                                lastHandshakeSsid = rawSsid
                            }
                        } else if (payloadString.startsWith("P:")) {
                            lastHandshakePwd = payloadString.substring(2)
                        } else if (payloadString.startsWith("I:")) {
                            lastHandshakeIp = payloadString.substring(2)
                            if (lastHandshakeSsid != null && lastHandshakePwd != null) {
                                try {
                                    val hsJson = org.json.JSONObject()
                                    hsJson.put("type", "handshake")
                                    hsJson.put("ssid", lastHandshakeSsid)
                                    hsJson.put("pwd", lastHandshakePwd)
                                    hsJson.put("ip", lastHandshakeIp)
                                    _incomingPackets.tryEmit(hsJson.toString())
                                } catch(e: Exception) {}
                            }
                        } else {
                            fullPayloadBytes += data
                            val fullPayloadString = String(fullPayloadBytes, java.nio.charset.StandardCharsets.UTF_8)
                            _incomingPackets.tryEmit(fullPayloadString)
                        }
                    }
                } else {
                    Log.e("BleMeshManager", "Read failed with status $status")
                }
                gatt.close() // Disconnect after reading
            }
        })
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
            Log.d("BleMeshManager", "Advertising started successfully")
            isAdvertising = true
            DiagnosticLogger.log("BLE", "Advertising", "Started successfully", EventStatus.SUCCESS)
        }
        override fun onStartFailure(errorCode: Int) {
            Log.e("BleMeshManager", "Advertising failed: $errorCode")
            isAdvertising = false
            try { 
                gattServer?.clearServices() 
                gattServer?.close() 
                gattServer = null 
            } catch (e: Exception) {}
            DiagnosticLogger.log("BLE", "Advertising", "Failed with code: $errorCode", EventStatus.ERROR)
        }
    }

    fun startScanning() {
        if (bluetoothAdapter?.isEnabled == true && !isScanning && scanner != null) {
            startGattServer()
            
            val filter = ScanFilter.Builder()
                .setServiceUuid(PARCEL_UUID)
                .build()
            val settingsBuilder = ScanSettings.Builder()
                .setScanMode(if (emergencyMode) ScanSettings.SCAN_MODE_LOW_LATENCY else ScanSettings.SCAN_MODE_BALANCED)
            
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                settingsBuilder.setPhy(if (emergencyMode || longRangeMode) ScanSettings.PHY_LE_ALL_SUPPORTED else android.bluetooth.BluetoothDevice.PHY_LE_1M)
            }
            val settings = settingsBuilder.build()
            try {
                scanner.startScan(listOf(filter), settings, scanCallback)
                isScanning = true
                Log.d("BleMeshManager", "Started BLE scanning")
                DiagnosticLogger.log("BLE", "Scanning", "Started BLE Scanning", EventStatus.SUCCESS)
            } catch (e: Exception) {
                Log.e("BleMeshManager", "Failed to start scan", e)
                DiagnosticLogger.log("BLE", "Scanning", "Failed to start scan: ${e.message}", EventStatus.ERROR)
            }
        } else {
             Log.w("BleMeshManager", "Cannot start scanning. Adapter enabled: ${bluetoothAdapter?.isEnabled}, isScanning: $isScanning, scanner: $scanner")
        }
    }
    
    private fun startGattServer() {
        if (gattServer == null && bluetoothManager != null) {
            try {
                gattServer = bluetoothManager.openGattServer(context, gattServerCallback)
                val service = BluetoothGattService(MESH_SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
                val characteristic = BluetoothGattCharacteristic(
                    MESH_CHAR_UUID,
                    BluetoothGattCharacteristic.PROPERTY_READ,
                    BluetoothGattCharacteristic.PERMISSION_READ
                )
                service.addCharacteristic(characteristic)
                gattServer?.addService(service)
                Log.d("BleMeshManager", "Started GATT server")
            } catch (e: Exception) {
                Log.e("BleMeshManager", "Failed to start GATT server", e)
            }
        }
    }

    fun stopScanning() {
        try { 
            gattServer?.clearServices() 
            gattServer?.close() 
            gattServer = null 
        } catch (e: Exception) {}
        if (isScanning && scanner != null) {
            try {
                scanner.stopScan(scanCallback)
            } catch (e: Exception) {
                Log.e("BleMeshManager", "Failed to stop scan", e)
            }
            isScanning = false
            Log.d("BleMeshManager", "Stopped BLE scanning")
        }
    }

    fun stopAdvertising() {
        if (isAdvertising && advertiser != null) {
            try {
                advertiser.stopAdvertising(advertiseCallback)
            } catch (e: Exception) {
                Log.e("BleMeshManager", "Failed to stop advertising", e)
            }
            isAdvertising = false
            try { 
                gattServer?.clearServices() 
                gattServer?.close() 
                gattServer = null 
            } catch (e: Exception) {}
            Log.d("BleMeshManager", "Stopped advertising")
        }
    }

    // 3-Tier Long Range Upgrade
    private var currentAdvertisingSet: android.bluetooth.le.AdvertisingSet? = null
    private val advertiseSetCallback = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
        object : android.bluetooth.le.AdvertisingSetCallback() {
            override fun onAdvertisingSetStarted(advertisingSet: android.bluetooth.le.AdvertisingSet?, txPower: Int, status: Int) {
                currentAdvertisingSet = advertisingSet
            }
        }
    } else null

    fun pulseBleChunk(chunk: String) {
        if (bluetoothAdapter?.isEnabled == true && advertiser != null) {
            currentPayload = chunk.toByteArray(java.nio.charset.StandardCharsets.UTF_8)
            val txPower = if (emergencyMode) AdvertiseSettings.ADVERTISE_TX_POWER_HIGH else AdvertiseSettings.ADVERTISE_TX_POWER_LOW
            val advMode = if (emergencyMode) AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY else AdvertiseSettings.ADVERTISE_MODE_BALANCED
            
            val data = AdvertiseData.Builder()
                .setIncludeDeviceName(false)
                .addServiceUuid(PARCEL_UUID)
                .build()
            
            // 1. Start Legacy BLE (Tier 2 - normal range for old phones)
            val settings = AdvertiseSettings.Builder()
                .setAdvertiseMode(advMode)
                .setConnectable(true)
                .setTimeout(0)
                .setTxPowerLevel(txPower)
                .build()
            try {
                advertiser.stopAdvertising(advertiseCallback)
                advertiser.startAdvertising(settings, data, advertiseCallback)
                isAdvertising = true
            } catch (e: Exception) {}

            // 2. Start Coded PHY (S=8) Extended Advertising (Tier 3 - 1km range for Android 8+)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                if (bluetoothAdapter.isLeCodedPhySupported && bluetoothAdapter.isLeExtendedAdvertisingSupported) {
                    try {
                        val params = android.bluetooth.le.AdvertisingSetParameters.Builder()
                            .setLegacyMode(false)
                            .setConnectable(true)
                            .setInterval(android.bluetooth.le.AdvertisingSetParameters.INTERVAL_LOW)
                            .setTxPowerLevel(android.bluetooth.le.AdvertisingSetParameters.TX_POWER_HIGH)
                            .setPrimaryPhy(if (emergencyMode || longRangeMode) android.bluetooth.BluetoothDevice.PHY_LE_CODED else android.bluetooth.BluetoothDevice.PHY_LE_1M)
                            .setSecondaryPhy(if (emergencyMode || longRangeMode) android.bluetooth.BluetoothDevice.PHY_LE_CODED else android.bluetooth.BluetoothDevice.PHY_LE_2M)
                            .build()
                        
                        if (currentAdvertisingSet != null) {
                            advertiser.stopAdvertisingSet(advertiseSetCallback as android.bluetooth.le.AdvertisingSetCallback)
                        }
                        advertiser.startAdvertisingSet(params, data, null, null, null, advertiseSetCallback as android.bluetooth.le.AdvertisingSetCallback)
                    } catch (e: Exception) {
                        android.util.Log.e("BleMeshManager", "Failed to start Coded PHY advertising", e)
                    }
                }
            }
        }
    }

    fun broadcastPacket(payload: String) {
        if (bluetoothAdapter?.isEnabled == true && advertiser != null) {
            broadcastQueue.trySend(payload)
        } else {
            Log.w("BleMeshManager", "Cannot broadcast. Adapter enabled: ${bluetoothAdapter?.isEnabled}, advertiser: $advertiser")
        }
    }
}
