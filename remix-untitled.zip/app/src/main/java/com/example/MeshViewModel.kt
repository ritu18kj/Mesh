package com.example
import kotlinx.coroutines.flow.update

import android.app.Application
import android.webkit.MimeTypeMap
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.annotation.SuppressLint
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

enum class DeliveryStatus {
    PENDING,    // Clock / Sending
    SENT,       // Single checkmark (sent to mesh socket)
    DELIVERED   // Double blue checkmark (acknowledged / received by peers)
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderName: String,
    val senderHandle: String = "",
    val senderId: String = "",
    val recipientId: String? = null, // null for group/public mesh room, or specific peer node ID for 1-on-1 DM
    val message: String,
    val isFromMe: Boolean,
    val isBurner: Boolean = false,
    val isEmergency: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val deliveryStatus: DeliveryStatus = DeliveryStatus.DELIVERED
)

data class SOSBeaconAlert(
    val senderId: String,
    val senderName: String,
    val senderHandle: String = "",
    val message: String,
    val lat: Double? = null,
    val lng: Double? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class MeshNode(
    val id: String,
    val name: String,
    val signalStrength: Int // 0 to 100
)

data class MediaInvite(val type: String, val url: String, val hostId: String = "", val mode: String = "collaborative", val maxSeats: Int = 0)
data class PendingUser(val id: String, val name: String, val publicKeyBase64: String, val ip: String)

data class MeshState(
    val localUserName: String = android.os.Build.MODEL,
    val localUsernameId: String = "@" + android.os.Build.MODEL.lowercase().replace("[^a-z0-9_]".toRegex(), "") + "_" + (100..999).random(),
    val isUsernamePermanent: Boolean = false,
    val isGhostMode: Boolean = false,
    val knownUsers: Map<String, String> = emptyMap(),
    val knownUserIds: Map<String, String> = emptyMap(),
    val isScanning: Boolean = false,
    val isEmergencyMode: Boolean = false,
    val isConnected: Boolean = false,
    val isWifiConnected: Boolean = false,
    val isHotspotActive: Boolean = false,
    val isPrivateRoom: Boolean = false,
    val isBurnerRoomActive: Boolean = false,
    val burnerRoomCountdown: Int = 0,
    val burnerRoomId: String = "",
    val activeBurnerKeys: List<String> = emptyList(),
    val hotspotSsid: String = "",
    val hotspotPassword: String = "",
    val hotspotError: String? = null,
    val hotspotIp: String = "",
    val connectedNodes: List<MeshNode> = emptyList(),
    val messages: List<ChatMessage> = emptyList(),
    val webClientConnectedEvent: Boolean = false,
    val isWebServerRunning: Boolean = false,
    val autoJoinBeaconEnabled: Boolean = true,
    val discoveredHostSsid: String? = null,
    val discoveredHostPwd: String? = null,
    val discoveredHostIp: String? = null,
    val canvasPaths: List<DrawPath> = emptyList(),
    val lasers: Map<String, androidx.compose.ui.geometry.Offset> = emptyMap(),
    val canvasBackground: String = "",
    val activePoll: PollState? = null,
    val activeRandomizer: RandomizerState? = null,
    val userLocations: Map<String, LocationMessage> = emptyMap(),
    val sharedMediaType: String = "none",
        val sharedMediaUrl: String = "",
    val mediaHostId: String = "",
    val mediaMode: String = "collaborative",
    val activePlayers: List<String> = emptyList(),
    val maxSeats: Int = 0,
    val incomingInvite: MediaInvite? = null,
    val ludoState: LudoState = LudoState(),
    val ticTacToeState: com.example.TicTacToeState = com.example.TicTacToeState(),
    val connect4State: com.example.Connect4State = com.example.Connect4State(),
    val chessState: ChessState = ChessState(),
    val pendingSpectators: List<String> = emptyList(),
    val approvedSpectators: List<String> = emptyList(),
    val pendingUsers: List<PendingUser> = emptyList(),
    val activeDmPeerId: String? = null, // null = Public Mesh Room, or peer ID for 1-1 Private DM
    val activeSOSAlert: SOSBeaconAlert? = null
)

class MeshViewModel(application: Application) : AndroidViewModel(application) {

    val uiState: StateFlow<MeshState> = MeshNetworkManager.uiState
    val diagnosticEvents: StateFlow<List<DiagnosticEvent>> = DiagnosticLogger.events

    val database = com.example.data.MeshChatDatabase.getDatabase(application)
    val repository = com.example.data.ChatRepository(database.chatDao(), database.callLogDao())

    val callLogs: StateFlow<List<com.example.data.CallLogEntity>> = repository.allCallLogs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        // Load saved permanent username if exists
        val prefs = application.getSharedPreferences("user_profile_prefs", Context.MODE_PRIVATE)
        val isGhost = prefs.getBoolean("is_ghost_mode", false)
        val isPerm = prefs.getBoolean("is_permanent", false)
        if (isGhost) {
            MeshNetworkManager._uiState.update { it.copy(isGhostMode = true) }
        }
        if (isPerm) {
            val savedName = prefs.getString("user_display_name", null)
            val savedId = prefs.getString("user_username_id", null)
            if (!savedName.isNullOrBlank() && !savedId.isNullOrBlank()) {
                MeshNetworkManager._uiState.update { 
                    it.copy(
                        localUserName = savedName,
                        localUsernameId = savedId,
                        isUsernamePermanent = true
                    ) 
                }
                MeshNetworkManager.meshRouter.localNodeName = savedName
            }
        }

        // Restore local message history from Room
        viewModelScope.launch {
            repository.allMessages.collect { persistedList ->
                if (persistedList.isNotEmpty() && MeshNetworkManager._uiState.value.messages.isEmpty()) {
                    val restored = persistedList.map { entity ->
                        ChatMessage(
                            id = entity.id.toString(),
                            senderId = entity.senderId,
                            senderName = entity.senderName,
                            message = entity.message,
                            timestamp = entity.timestamp,
                            isFromMe = entity.isFromMe
                        )
                    }
                    MeshNetworkManager._uiState.update { it.copy(messages = restored) }
                }
            }
        }

        // Automatic Storage Management: Run startup cache auto-clean
        viewModelScope.launch(Dispatchers.IO) {
            MeshStorageManager.autoPurgeCache(application)
        }
    }

    fun emergencyPanicWipe(context: Context) {
        viewModelScope.launch {
            repository.emergencyPanicWipe(context)
            MeshNetworkManager._uiState.update { it.copy(messages = emptyList()) }
            android.widget.Toast.makeText(context, "🚨 All records and chat logs permanently wiped!", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private var locationTracker: LocationTracker? = null

    fun startLocationTracking(context: Context, ecoMode: Boolean = false) {
        if (locationTracker == null) {
            locationTracker = LocationTracker(context, this)
        }
        locationTracker?.startTracking(ecoMode)
    }

    fun stopLocationTracking() {
        locationTracker?.stopTracking()
    }

    fun pingRadarLocation() {
        locationTracker?.requestSingleScan()
        // Also broadcast an on-demand location beacon request to all mesh nodes
        val myId = MeshNetworkManager.localNodeId
        val payload = """{"type":"radar_ping","requester":"$myId"}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
        MeshNetworkManager.webServerManager?.broadcastMessage(payload, "Radar")
    }

    fun sendLocationMessage(lat: Double, lng: Double) {
        val myId = MeshNetworkManager.localNodeId
        val myName = MeshNetworkManager.uiState.value.localUserName
        val payload = """{"type":"location","id":"$myId","name":"$myName","lat":$lat,"lng":$lng}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
        MeshNetworkManager.webServerManager?.broadcastMessage(payload, "Radar")
        updateLocalLocation(myId, myName, lat, lng)
    }

    fun generateRandomHandle(): String {
        val adjectives = listOf("cyber", "mesh", "shadow", "neon", "crypto", "hyper", "matrix", "sonic", "vortex", "pulse", "echo", "ninja", "blaze")
        val nouns = listOf("pilot", "scout", "runner", "knight", "rider", "ghost", "coder", "surfer", "spark", "node", "wave", "wolf", "falcon")
        val num = (10..99).random()
        return "@${adjectives.random()}_${nouns.random()}_$num"
    }

    fun updateUserName(newName: String, newUsernameId: String? = null, isPermanent: Boolean = false) {
        val finalId = if (!newUsernameId.isNullOrBlank()) {
            val clean = newUsernameId.trim().lowercase().replace("[^a-z0-9_@]".toRegex(), "")
            if (clean.startsWith("@")) clean else "@$clean"
        } else {
            MeshNetworkManager._uiState.value.localUsernameId
        }

        val myId = MeshNetworkManager.localNodeId
        MeshNetworkManager._uiState.update { 
            it.copy(
                localUserName = newName,
                localUsernameId = finalId,
                isUsernamePermanent = isPermanent,
                knownUsers = it.knownUsers + (myId to newName),
                knownUserIds = it.knownUserIds + (myId to finalId)
            ) 
        }
        MeshNetworkManager.meshRouter.localNodeName = newName
        
        // Persist to SharedPreferences if permanent mode selected
        val prefs = getApplication<Application>().getSharedPreferences("user_profile_prefs", Context.MODE_PRIVATE)
        if (isPermanent) {
            prefs.edit()
                .putBoolean("is_permanent", true)
                .putString("user_display_name", newName)
                .putString("user_username_id", finalId)
                .apply()
        } else {
            prefs.edit().putBoolean("is_permanent", false).apply()
        }

        // Broadcast identity to mesh with username ID
        val payload = """{"type":"sys_identity","id":"$myId","name":"$newName","usernameId":"$finalId"}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
        MeshNetworkManager.webServerManager?.broadcastMessage(payload, myId)
    }

    fun setGhostMode(enabled: Boolean) {
        MeshNetworkManager._uiState.update { it.copy(isGhostMode = enabled) }
        val prefs = getApplication<Application>().getSharedPreferences("user_profile_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("is_ghost_mode", enabled).apply()
    }

    fun updateLocalLocation(id: String, name: String, lat: Double, lng: Double) {
        MeshNetworkManager._uiState.update { state ->
            val updatedMap = state.userLocations.toMutableMap()
            updatedMap[id] = LocationMessage(id = id, name = name, lat = lat, lng = lng)
            state.copy(userLocations = updatedMap)
        }
    }

    fun kickUser(id: String) {
        val payload = org.json.JSONObject().apply {
            put("type", "sys_kicked")
            put("target", id)
        }.toString()
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
        MeshNetworkManager.wifiSocketManager?.disconnectClient(id)
    }

    fun banUser(id: String) {
        MeshNetworkManager.meshRouter.blockUser(id)
        val payload = org.json.JSONObject().apply {
            put("type", "sys_banned")
            put("target", id)
        }.toString()
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
        MeshNetworkManager.wifiSocketManager?.disconnectClient(id)
    }


    fun manuallyConnectToIp(ip: String) {
        MeshNetworkManager.wifiSocketManager?.connectToPeer(ip, 8888)
    }

    fun toggleScanning() {
        if (uiState.value.isScanning) {
            MeshNetworkManager.bleMeshManager?.stopScanning()
            MeshNetworkManager._uiState.update { it.copy(isScanning = false, isConnected = false) }
        } else {
            MeshNetworkManager.bleMeshManager?.startScanning()
            MeshNetworkManager._uiState.update { it.copy(isScanning = true, isConnected = true) }
        }
    }

    fun forceRefresh() {
        val currentState = uiState.value
        MeshNetworkManager._uiState.update { it.copy(
            messages = currentState.messages.toList()
        ) }
    }

    fun clearWebClientConnectedEvent() {
        MeshNetworkManager._uiState.update { it.copy(webClientConnectedEvent = false) }
    }

    fun clearHotspotError() {
        MeshNetworkManager.hotspotManager?.clearError()
    }

    fun toggleHotspot(isPrivate: Boolean = false) {
        if (uiState.value.isHotspotActive) {
            MeshNetworkManager.hotspotManager?.stopHotspot()
            MeshNetworkManager._uiState.update { it.copy(isPrivateRoom = false) }
        } else {
            MeshNetworkManager._uiState.update { it.copy(isPrivateRoom = isPrivate) }
            MeshNetworkManager.hotspotManager?.startHotspot()
        }
    }

    fun toggleAutoJoinBeacon(enabled: Boolean? = null) {
        MeshNetworkManager._uiState.update { 
            val newVal = enabled ?: !it.autoJoinBeaconEnabled
            it.copy(autoJoinBeaconEnabled = newVal)
        }
    }

    fun connectToDiscoveredHotspot(passwordOverride: String? = null) {
        val ssid = uiState.value.discoveredHostSsid
        val pwd = passwordOverride ?: uiState.value.discoveredHostPwd
        val ip = uiState.value.discoveredHostIp
        if (ssid != null && pwd != null) {
            MeshNetworkManager.hotspotManager?.connectToHotspot(ssid, pwd, ip)
        }
    }

    fun disconnectAndCleanup() {
        MeshNetworkManager.hotspotManager?.disconnectFromHotspot()
        MeshNetworkManager.hotspotManager?.stopHotspot()
        MeshNetworkManager.bleMeshManager?.stopScanning()
        MeshNetworkManager.bleMeshManager?.stopAdvertising()
        MeshNetworkManager.wifiSocketManager?.stop()
        MeshNetworkManager._uiState.update { it.copy(
            isScanning = false,
            isConnected = false,
            isWifiConnected = false,
            isHotspotActive = false,
            discoveredHostSsid = null,
            discoveredHostPwd = null,
            discoveredHostIp = null,
            connectedNodes = emptyList(),
            messages = emptyList() 
        ) }
        DiagnosticLogger.log("System", "Cleanup", "Full session reset complete", EventStatus.INFO)
    }

    
    fun startBurnerRoom(durationSeconds: Int = 300) {
        val burnerId = java.util.UUID.randomUUID().toString()
        MeshNetworkManager._uiState.update { it.copy(isBurnerRoomActive = true, burnerRoomCountdown = durationSeconds, burnerRoomId = burnerId, activeBurnerKeys = listOf(MeshNetworkManager._uiState.value.localUserName)) }
        
        // Notify others to enter burner room
        val burnerPayload = org.json.JSONObject().apply {
            put("type", "burner_sync")
            put("action", "start")
            put("burnerId", burnerId)
            put("duration", durationSeconds)
            put("initiator", MeshNetworkManager._uiState.value.localUserName)
        }.toString()
        MeshNetworkManager.meshRouter.routeLocalMessage(burnerPayload)
        
        startBurnerCountdown()
    }
    
    fun leaveBurnerRoom() {
        val currentBurner = MeshNetworkManager._uiState.value.burnerRoomId
        val burnerPayload = org.json.JSONObject().apply {
            put("type", "burner_sync")
            put("action", "leave")
            put("burnerId", currentBurner)
            put("user", MeshNetworkManager._uiState.value.localUserName)
        }.toString()
        MeshNetworkManager.meshRouter.routeLocalMessage(burnerPayload)
        
        clearBurnerRoom()
    }
    
    private var burnerJob: kotlinx.coroutines.Job? = null
    
    private fun startBurnerCountdown() {
        burnerJob?.cancel()
        burnerJob = viewModelScope.launch {
            while (MeshNetworkManager._uiState.value.isBurnerRoomActive && MeshNetworkManager._uiState.value.burnerRoomCountdown > 0) {
                kotlinx.coroutines.delay(1000)
                MeshNetworkManager._uiState.update { it.copy(burnerRoomCountdown = it.burnerRoomCountdown - 1) }
            }
            if (MeshNetworkManager._uiState.value.isBurnerRoomActive) {
                // Time is up, nuke it
                clearBurnerRoom()
            }
        }
    }
    
    private fun clearBurnerRoom() {
        burnerJob?.cancel()
        MeshNetworkManager._uiState.update { 
            val filteredMessages = it.messages.filter { msg -> !msg.isBurner }
            it.copy(
                isBurnerRoomActive = false, 
                burnerRoomCountdown = 0,
                burnerRoomId = "",
                activeBurnerKeys = emptyList(),
                messages = filteredMessages
            )
        }
    }

    
    fun shareAppApk(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val apkFile = File(context.applicationInfo.sourceDir)
                if (apkFile.exists()) {
                    // Copy to shared_files so FileProvider can serve it
                    val sharedDir = File(context.filesDir, "shared_files")
                    if (!sharedDir.exists()) sharedDir.mkdirs()
                    val destFile = File(sharedDir, "MeshChat.apk")
                    apkFile.copyTo(destFile, overwrite = true)
                    
                    val uri = androidx.core.content.FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        destFile
                    )
                    
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/vnd.android.package-archive"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    
                    withContext(Dispatchers.Main) {
                        context.startActivity(Intent.createChooser(intent, "Share MeshChat APK").apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("MeshViewModel", "Error sharing APK", e)
            }
        }
    }

    fun clearChat() {
        MeshNetworkManager._uiState.update { it.copy(
            messages = emptyList(),
            connectedNodes = emptyList(),
            discoveredHostSsid = null,
            discoveredHostPwd = null,
            discoveredHostIp = null,
            isConnected = false,
            isWifiConnected = false
        ) }
        if (uiState.value.isHotspotActive) {
            MeshNetworkManager.hotspotManager?.stopHotspot()
        }
        if (uiState.value.isScanning) {
            MeshNetworkManager.bleMeshManager?.stopScanning()
        }
    }

    fun blockUser(userId: String) {
        if (userId.isNotBlank()) {
            MeshNetworkManager.meshRouter.blockUser(userId)
            MeshNetworkManager._uiState.update { it.copy(
                messages = uiState.value.messages.filter { msg -> msg.senderId != userId }
            ) }
        }
    }

    
    fun uploadCanvasBackground(uri: android.net.Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val (file, fileName) = MeshStorageManager.saveUriToCache(getApplication(), uri)
            val ip = NetworkUtils.getLocalIpAddress()
            val url = "http://$ip:8080/files/${android.net.Uri.encode(fileName)}"
            
            withContext(Dispatchers.Main) {
                sendCanvasMessage("bg", "", "#000000", 0f, 0f, 10f, url)
            }
        }
    }

    suspend fun uploadFile(uri: Uri): String = withContext(Dispatchers.IO) {
        val (file, fileName) = MeshStorageManager.saveUriToCache(getApplication(), uri)
        
        withContext(Dispatchers.Main) {
            MeshNetworkManager.webServerManager?.startServer()
        }
        
        val ip = NetworkUtils.getLocalIpAddress()
        "http://$ip:8080/files/${android.net.Uri.encode(fileName)}"
    }

    fun shareFile(uri: Uri) {
        viewModelScope.launch {
            val url = uploadFile(uri)
            sendMessage("Shared a file: $url")
        }
    }

    @SuppressLint("Range")
    private fun getFileName(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = getApplication<Application>().contentResolver.query(uri, null, null, null, null)
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME))
                }
            } finally {
                cursor?.close()
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/') ?: -1
            if (cut != -1) {
                result = result?.substring(cut + 1)
            }
        }
        return result
    }

    fun sendCanvasMessage(action: String, id: String, color: String, x: Float, y: Float, strokeWidth: Float = 10f, data: String = "") {
        val payload = """{"type":"canvas","action":"$action","id":"$id","color":"$color","x":$x,"y":$y,"strokeWidth":$strokeWidth,"data":"$data"}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
        MeshNetworkManager.webServerManager?.broadcastMessage(payload, "Radar")
        MeshNetworkManager.webServerManager?.broadcastMessage(payload, "Canvas")
        updateLocalCanvas(action, id, color, x, y, strokeWidth)
    }

    fun updateLocalCanvas(action: String, id: String, color: String, x: Float, y: Float, strokeWidth: Float = 10f, data: String = "", senderId: String = "") {
        MeshNetworkManager._uiState.update { state ->
            val paths = state.canvasPaths.toMutableList()
            var newBg = state.canvasBackground
            val newLasers = state.lasers.toMutableMap()
            val isEraser = color == "ERASER"
            val parsedColor = if (isEraser) androidx.compose.ui.graphics.Color.Transparent else {
                try { androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(color)) } catch (e: Exception) { androidx.compose.ui.graphics.Color.Black }
            }
            if (action == "clear") {
                paths.clear()
            } else if (action == "undo") {
                if (paths.isNotEmpty()) {
                    paths.removeLast()
                }
            } else if (action == "bg") {
                newBg = data
            } else if (action == "laser") {
                newLasers[senderId] = androidx.compose.ui.geometry.Offset(x, y)
            } else if (action == "start") {
                paths.add(DrawPath(id, parsedColor, listOf(androidx.compose.ui.geometry.Offset(x, y)), strokeWidth, isEraser))
            } else if (action == "move") {
                val index = paths.indexOfLast { it.id == id }
                if (index != -1) {
                    val oldPath = paths[index]
                    val newPoints = oldPath.points + androidx.compose.ui.geometry.Offset(x, y)
                    paths[index] = oldPath.copy(points = newPoints)
                } else {
                    paths.add(DrawPath(id, parsedColor, listOf(androidx.compose.ui.geometry.Offset(x, y)), strokeWidth, isEraser))
                }
            } else if (action == "end") {
                // Ignore end points to prevent the (0,0) glitch
            }
            state.copy(canvasPaths = paths, canvasBackground = newBg, lasers = newLasers)
        }
    }

    fun saveCanvasToGallery(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val state = uiState.value
                val width = 1080
                val height = 1080
                val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bitmap)
                
                // Draw background
                canvas.drawColor(android.graphics.Color.WHITE)
                
                if (state.canvasBackground.isNotBlank()) {
                    try {
                        val url = java.net.URL(state.canvasBackground)
                        val connection = url.openConnection()
                        connection.connect()
                        val input = connection.getInputStream()
                        val bgBitmap = android.graphics.BitmapFactory.decodeStream(input)
                        if (bgBitmap != null) {
                            val srcRect = android.graphics.Rect(0, 0, bgBitmap.width, bgBitmap.height)
                            val imgAspect = bgBitmap.width.toFloat() / bgBitmap.height.toFloat()
                            val canvasAspect = width.toFloat() / height.toFloat()
                            var drawW = width.toFloat()
                            var drawH = height.toFloat()
                            if (imgAspect > canvasAspect) {
                                drawH = width.toFloat() / imgAspect
                            } else {
                                drawW = height.toFloat() * imgAspect
                            }
                            val left = ((width - drawW) / 2).toInt()
                            val top = ((height - drawH) / 2).toInt()
                            val dstRect = android.graphics.Rect(left, top, (left + drawW).toInt(), (top + drawH).toInt())
                            canvas.drawBitmap(bgBitmap, srcRect, dstRect, null)
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("MeshViewModel", "Failed to load background for saving", e)
                    }
                }

                // Draw paths
                val paint = android.graphics.Paint().apply {
                    style = android.graphics.Paint.Style.STROKE
                    strokeCap = android.graphics.Paint.Cap.ROUND
                    strokeJoin = android.graphics.Paint.Join.ROUND
                    isAntiAlias = true
                }

                for (drawPath in state.canvasPaths) {
                    if (drawPath.points.isEmpty()) continue
                    
                    if (drawPath.isEraser) {
                        paint.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR)
                        paint.color = android.graphics.Color.TRANSPARENT
                    } else {
                        paint.xfermode = null
                        paint.color = android.graphics.Color.argb(
                            (drawPath.color.alpha * 255).toInt(),
                            (drawPath.color.red * 255).toInt(),
                            (drawPath.color.green * 255).toInt(),
                            (drawPath.color.blue * 255).toInt()
                        )
                    }
                    paint.strokeWidth = drawPath.strokeWidth

                    val androidPath = android.graphics.Path()
                    androidPath.moveTo(drawPath.points.first().x * width, drawPath.points.first().y * height)
                    for (i in 1 until drawPath.points.size) {
                        androidPath.lineTo(drawPath.points[i].x * width, drawPath.points[i].y * height)
                    }
                    canvas.drawPath(androidPath, paint)
                }

                // Save to MediaStore
                val filename = "MeshCanvas_${System.currentTimeMillis()}.png"
                val resolver = context.contentResolver
                val contentValues = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES)
                    }
                }

                val imageUri = resolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (imageUri != null) {
                    resolver.openOutputStream(imageUri)?.use { out ->
                        bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
                    }
                    withContext(Dispatchers.Main) {
                        android.widget.Toast.makeText(context, "Canvas saved to Gallery", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("MeshViewModel", "Error saving canvas", e)
                withContext(Dispatchers.Main) {
                    android.widget.Toast.makeText(context, "Failed to save canvas", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    
    
    
    fun broadcastTicTacToeState(newState: com.example.TicTacToeState) {
        MeshNetworkManager._uiState.update { it.copy(ticTacToeState = newState) }
        val payload = """{"type":"tictactoe","state":${newState.toJson()}}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
    }

    fun broadcastConnect4State(newState: com.example.Connect4State) {
        MeshNetworkManager._uiState.update { it.copy(connect4State = newState) }
        val payload = """{"type":"connect4","state":${newState.toJson()}}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
    }

    fun broadcastChessState(newState: ChessState) {
        MeshNetworkManager._uiState.update { it.copy(chessState = newState) }
        val payload = """{"type":"chess","state":${newState.toJson()}}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
    }

    fun broadcastLudoState(newState: LudoState) {
        MeshNetworkManager._uiState.update { it.copy(ludoState = newState) }
        val payload = """{"type":"ludo","state":${newState.toJson()}}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
    }

        fun pulseBleChunk(chunk: String) {
        val intent = android.content.Intent(getApplication(), MeshForegroundService::class.java)
        intent.action = "PULSE_BLE_CHUNK"
        intent.putExtra("chunk", chunk)
        getApplication<android.app.Application>().startService(intent)
    }

    fun acceptInvite() {
        MeshNetworkManager._uiState.update { state -> 
            state.incomingInvite?.let { invite ->
                var newState = state.copy(sharedMediaType = invite.type, sharedMediaUrl = invite.url, incomingInvite = null)
                val myId = MeshNetworkManager.localNodeId
                when (invite.type) {
                    "tictactoe" -> {
                        if (newState.ticTacToeState.oPlayerId.isEmpty() && newState.ticTacToeState.xPlayerId != myId) {
                            val gState = newState.ticTacToeState.copy(oPlayerId = myId)
                            newState = newState.copy(ticTacToeState = gState)
                            MeshNetworkManager.meshRouter.routeLocalMessage("{\"type\":\"tictactoe\",\"state\":${gState.toJson()}}")
                        }
                    }
                    "connect4" -> {
                        if (newState.connect4State.yellowPlayerId.isEmpty() && newState.connect4State.redPlayerId != myId) {
                            val gState = newState.connect4State.copy(yellowPlayerId = myId)
                            newState = newState.copy(connect4State = gState)
                            MeshNetworkManager.meshRouter.routeLocalMessage("{\"type\":\"connect4\",\"state\":${gState.toJson()}}")
                        }
                    }
                    "chess" -> {
                        if (newState.chessState.blackPlayerId.isEmpty() && newState.chessState.whitePlayerId != myId) {
                            val gState = newState.chessState.copy(blackPlayerId = myId)
                            newState = newState.copy(chessState = gState)
                            MeshNetworkManager.meshRouter.routeLocalMessage("{\"type\":\"chess\",\"state\":${gState.toJson()}}")
                        }
                    }
                    "ludo" -> {
                        val ids = newState.ludoState.playerIds.toMutableMap()
                        if (!ids.values.contains(myId)) {
                            for (i in 1..3) {
                                if (ids[i].isNullOrEmpty()) {
                                    ids[i] = myId
                                    break
                                }
                            }
                            val gState = newState.ludoState.copy(playerIds = ids)
                            newState = newState.copy(ludoState = gState)
                            MeshNetworkManager.meshRouter.routeLocalMessage("{\"type\":\"ludo\",\"state\":${gState.toJson()}}")
                        }
                    }
                }
                newState
            } ?: state
        }
    }
    
    fun rejectInvite() {
        MeshNetworkManager._uiState.update { it.copy(incomingInvite = null) }
    }

    fun setSharedMedia(type: String, url: String = "", mode: String = "collaborative", maxSeats: Int = 0) {
        val hostId = MeshNetworkManager.localNodeId
        val payload = """{"type":"shared_media","mediaType":"$type","url":"$url","hostId":"$hostId","mode":"$mode","maxSeats":$maxSeats}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
        updateLocalSharedMedia(type, url, hostId, mode, maxSeats, true)
        
        
        if (type != "none") {
            val niceName = when(type) {
                "chess" -> "Standard Chess"
                "ludo" -> "Mesh Ludo"
                "web" -> "Web Media"
                else -> type
            }
            sendMessage("🎮 Started a match of $niceName! Head over to the Arcade tab to join or watch.")
        } else {
            sendMessage("🛑 The current game session has been closed.")
            // Reset game states
            MeshNetworkManager._uiState.update { it.copy(chessState = com.example.ChessEngine.reset(), ludoState = com.example.LudoState(), ticTacToeState = com.example.TicTacToeState(), connect4State = com.example.Connect4State()) }
            // Broadcast reset so others also clear
            val pChess = """{"type":"chess","state":${com.example.ChessEngine.reset().toJson()}}"""
            MeshNetworkManager.meshRouter.routeLocalMessage(pChess)
            val pLudo = """{"type":"ludo","state":${com.example.LudoState().toJson()}}"""
            MeshNetworkManager.meshRouter.routeLocalMessage(pLudo)
        }
    }

    fun approveUser(user: PendingUser) {
        MeshNetworkManager._uiState.update { state -> 
            state.copy(pendingUsers = state.pendingUsers.filter { it.id != user.id }) 
        }
        MeshNetworkManager.wifiSocketManager?.approvePeer(user.ip, user.publicKeyBase64)
    }

    fun rejectUser(user: PendingUser) {
        MeshNetworkManager._uiState.update { state -> 
            state.copy(pendingUsers = state.pendingUsers.filter { it.id != user.id }) 
        }
        MeshNetworkManager.wifiSocketManager?.disconnectClient(user.ip)
    }

    fun updateLocalSharedMedia(type: String, url: String, hostId: String = "", mode: String = "collaborative", maxSeats: Int = 0, isHost: Boolean = false) {
        MeshNetworkManager._uiState.update { it.copy(
            sharedMediaType = type, 
            sharedMediaUrl = url,
            mediaHostId = hostId,
            mediaMode = mode,
            maxSeats = maxSeats,
            activePlayers = if (type != "none" && isHost && maxSeats > 0) listOf(MeshNetworkManager.localNodeId) else emptyList()
        ) }
    }

    
    fun setDmPeer(peerId: String?) {
        MeshNetworkManager._uiState.update { it.copy(activeDmPeerId = peerId) }
    }

    fun clearDmPeer() {
        MeshNetworkManager._uiState.update { it.copy(activeDmPeerId = null) }
    }

    fun dismissSOSAlert() {
        MeshNetworkManager._uiState.update { it.copy(activeSOSAlert = null) }
    }

    fun cancelSOS() {
        MeshNetworkManager.bleMeshManager?.emergencyMode = false
        MeshNetworkManager._uiState.update { it.copy(isEmergencyMode = false, activeSOSAlert = null) }
        val cancelPayload = org.json.JSONObject().apply {
            put("type", "sos_cancel")
            put("senderId", MeshNetworkManager.localNodeId)
        }.toString()
        MeshNetworkManager.meshRouter.routeLocalMessage(cancelPayload)
        MeshNetworkManager.webServerManager?.broadcastMessage(cancelPayload, "System")
    }
    
    fun triggerSOS(customMessage: String? = null) {
        val myId = MeshNetworkManager.localNodeId
        val myName = MeshNetworkManager._uiState.value.localUserName
        val myHandle = MeshNetworkManager._uiState.value.localUsernameId
        val myLoc = MeshNetworkManager._uiState.value.userLocations[myId]
        
        val locText = if (myLoc != null) "Lat: %.4f, Lng: %.4f".format(myLoc.lat, myLoc.lng) else "GPS: Searching / Offline"
        val alertDetail = customMessage?.ifBlank { null } ?: "Immediate Assistance Required! Node $myName is broadcasting an Emergency SOS Beacon."
        val sosText = "🚨 [SOS EMERGENCY BEACON]\n$alertDetail\nLocation: $locText\nHandle: $myHandle"

        val localAlert = SOSBeaconAlert(
            senderId = myId,
            senderName = myName,
            senderHandle = myHandle,
            message = alertDetail,
            lat = myLoc?.lat,
            lng = myLoc?.lng
        )

        MeshNetworkManager.bleMeshManager?.emergencyMode = true
        MeshNetworkManager._uiState.update { it.copy(isEmergencyMode = true, activeSOSAlert = localAlert) }
        sendMessage(sosText, isEmergency = true)
        
        val sosPayload = org.json.JSONObject().apply {
            put("type", "sos_beacon")
            put("senderId", myId)
            put("senderName", myName)
            put("senderHandle", myHandle)
            put("message", alertDetail)
            if (myLoc != null) {
                put("lat", myLoc.lat)
                put("lng", myLoc.lng)
            }
            put("timestamp", System.currentTimeMillis())
        }.toString()
        MeshNetworkManager.meshRouter.routeLocalMessage(sosPayload)
        MeshNetworkManager.webServerManager?.broadcastMessage(sosPayload, "EmergencySOS")
    }


    
    fun rollRandomizer() {
        val truths = listOf("What is your biggest fear?", "Who is your secret crush?", "What is the most embarrassing thing you've done?", "Have you ever lied to get out of trouble?")
        val dares = listOf("Do 10 pushups", "Sing a song out loud", "Let someone draw on your face", "Do an impression of another player")
        val isTruth = kotlin.random.Random.nextBoolean()
        val type = if (isTruth) "Truth" else "Dare"
        val prompt = if (isTruth) truths.random() else dares.random()
        val id = java.util.UUID.randomUUID().toString()
        val name = uiState.value.localUserName
        
        val payload = """{"type":"randomizer","id":"$id","rType":"$type","prompt":"$prompt","player":"$name"}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
        MeshNetworkManager.webServerManager?.broadcastMessage(payload, "Randomizer")
        
        MeshNetworkManager._uiState.update { it.copy(activeRandomizer = RandomizerState(id, type, prompt, name)) }
        
        // Auto dismiss after 10 seconds
        kotlinx.coroutines.GlobalScope.launch {
            kotlinx.coroutines.delay(10000)
            MeshNetworkManager._uiState.update { if (it.activeRandomizer?.id == id) it.copy(activeRandomizer = null) else it }
        }
    }

    fun startPoll(question: String, options: List<String>, attachmentUri: android.net.Uri? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            var url = ""
            if (attachmentUri != null) {
                url = uploadFile(attachmentUri)
            }
            val poll = PollState(
                id = java.util.UUID.randomUUID().toString(),
                question = question,
                options = options,
                hostId = MeshNetworkManager.localNodeId,
                attachmentUrl = url
            )
            val payload = """{"type":"poll_start","id":"${poll.id}","q":"$question","options":"${options.joinToString("|")}","attachmentUrl":"$url"}"""
            MeshNetworkManager.meshRouter.routeLocalMessage(payload)
            MeshNetworkManager.webServerManager?.broadcastMessage(payload, "Poll")
            withContext(Dispatchers.Main) {
                MeshNetworkManager._uiState.update { it.copy(activePoll = poll) }
            }
        }
    }
    
    fun votePoll(pollId: String, optionIndex: Int) {
        val payload = """{"type":"poll_vote","id":"$pollId","opt":$optionIndex}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
        MeshNetworkManager.webServerManager?.broadcastMessage(payload, "Poll")
        
        MeshNetworkManager._uiState.update { state ->
            state.activePoll?.let { poll ->
                if (poll.id == pollId) {
                    val newVotes = poll.votes.toMutableMap()
                    newVotes[MeshNetworkManager.localNodeId] = optionIndex
                    state.copy(activePoll = poll.copy(votes = newVotes))
                } else state
            } ?: state
        }
    }
    
    fun closePoll() {
        val payload = """{"type":"poll_close"}"""
        MeshNetworkManager.meshRouter.routeLocalMessage(payload)
        MeshNetworkManager.webServerManager?.broadcastMessage(payload, "Poll")
        MeshNetworkManager._uiState.update { it.copy(activePoll = null) }
    }

    fun sendMessage(text: String, recipientId: String? = null, isEmergency: Boolean = false) {
        if (text.isBlank()) return
        
        // --- Lifeline Web Hook ---
        if (text.startsWith("/web ")) {
            val url = text.substring(5).trim()
            val msg = ChatMessage(senderName = "Me", senderId = MeshNetworkManager.localNodeId, message = text, isFromMe = true)
            MeshNetworkManager._uiState.update { it.copy(messages = it.messages + msg) }
            val reqPayload = org.json.JSONObject().apply {
                put("type", "lifeline_request")
                put("url", url)
            }.toString()
            MeshNetworkManager.meshRouter.routeLocalMessage(reqPayload)
            return
        }
        
        val state = uiState.value
        val isBurner = state.isBurnerRoomActive
        val currentBurnerId = state.burnerRoomId
        val targetRecipient = recipientId ?: state.activeDmPeerId

        val newMessage = ChatMessage(
            senderName = "Me",
            senderHandle = state.localUsernameId,
            senderId = MeshNetworkManager.localNodeId,
            recipientId = targetRecipient,
            message = text,
            isFromMe = true,
            isBurner = isBurner,
            isEmergency = isEmergency,
            deliveryStatus = DeliveryStatus.PENDING
        )
        
        MeshNetworkManager._uiState.update { it.copy(
            messages = it.messages + newMessage
        ) }

        if (!isBurner && !state.isGhostMode) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    repository.insertMessage(
                        com.example.data.ChatMessageEntity(
                            senderId = MeshNetworkManager.localNodeId,
                            senderName = "Me",
                            message = text,
                            timestamp = newMessage.timestamp,
                            isFromMe = true
                        )
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        
        val chatPayload = org.json.JSONObject().apply {
            put("type", "chat")
            put("message", text)
            put("senderName", state.localUserName)
            put("senderHandle", state.localUsernameId)
            if (targetRecipient != null) {
                put("recipientId", targetRecipient)
            }
            if (isEmergency) {
                put("isEmergency", true)
            }
            if (isBurner) {
                put("isBurner", true)
                put("burnerId", currentBurnerId)
            }
        }.toString()
        
        MeshNetworkManager.meshRouter.routeLocalMessage(chatPayload)
        MeshNetworkManager.webServerManager?.broadcastMessage(text, "${state.localUserName} (${state.localUsernameId})")

        // Optimistic UI state transition: PENDING -> SENT -> DELIVERED
        viewModelScope.launch {
            kotlinx.coroutines.delay(150)
            val hasPeers = MeshNetworkManager._uiState.value.knownUsers.isNotEmpty() || MeshNetworkManager._uiState.value.isConnected
            val targetStatus = if (hasPeers) DeliveryStatus.DELIVERED else DeliveryStatus.SENT
            MeshNetworkManager._uiState.update { current ->
                val updatedMessages = current.messages.map { msg ->
                    if (msg.id == newMessage.id) msg.copy(deliveryStatus = targetStatus) else msg
                }
                current.copy(messages = updatedMessages)
            }
        }
    }

    fun downloadAndOpenFile(context: Context, url: String) {
        val fileName = if (url.contains("/download")) "MeshChat.apk" else url.substringAfterLast("/")
        val localFile = MeshStorageManager.findLocalFile(context, fileName)
        
        if (localFile != null && localFile.exists()) {
            val uri = MeshStorageManager.getFileProviderUri(context, localFile)
            if (uri != null) {
                val mimeType = MeshStorageManager.getMimeType(localFile.name)
                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mimeType)
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(intent)
                } catch (e: Exception) {
                    android.widget.Toast.makeText(context, "No app found to open this file", android.widget.Toast.LENGTH_SHORT).show()
                }
            } else {
                android.widget.Toast.makeText(context, "Unable to open file", android.widget.Toast.LENGTH_SHORT).show()
            }
        } else {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    withContext(Dispatchers.Main) {
                        android.widget.Toast.makeText(context, "Downloading file...", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    val targetFile = MeshStorageManager.getCacheFile(context, fileName)
                    val connection = java.net.URL(url).openConnection()
                    connection.connect()
                    connection.getInputStream().use { input ->
                        targetFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    MeshStorageManager.autoPurgeCache(context)
                    withContext(Dispatchers.Main) {
                        downloadAndOpenFile(context, url)
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        android.widget.Toast.makeText(context, "Failed to download: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    fun saveFileToDevice(context: Context, url: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val fileName = if (url.contains("/download")) "MeshChat.apk" else url.substringAfterLast("/")
                var localFile = MeshStorageManager.findLocalFile(context, fileName)
                
                if (localFile == null || !localFile.exists()) {
                    withContext(Dispatchers.Main) {
                        android.widget.Toast.makeText(context, "Downloading file...", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    localFile = MeshStorageManager.getCacheFile(context, fileName)
                    val connection = java.net.URL(url).openConnection()
                    connection.connect()
                    connection.getInputStream().use { input ->
                        localFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    MeshStorageManager.autoPurgeCache(context)
                }
                
                val savedUri = MeshStorageManager.saveFileToPublicDownloads(context, localFile)
                withContext(Dispatchers.Main) {
                    if (savedUri != null) {
                        android.widget.Toast.makeText(context, "Saved to Downloads/MeshChat", android.widget.Toast.LENGTH_LONG).show()
                    } else {
                        android.widget.Toast.makeText(context, "Failed to save file to Downloads", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("MeshViewModel", "Error saving to device", e)
                withContext(Dispatchers.Main) {
                    android.widget.Toast.makeText(context, "Error saving: ${e.localizedMessage}", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun saveImageToGallery(context: Context, url: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val fileName = if (url.contains("/download")) "MeshChat.apk" else url.substringAfterLast("/")
                var localFile = MeshStorageManager.findLocalFile(context, fileName)
                
                if (localFile == null || !localFile.exists()) {
                    withContext(Dispatchers.Main) {
                        android.widget.Toast.makeText(context, "Downloading image...", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    localFile = MeshStorageManager.getCacheFile(context, fileName)
                    val connection = java.net.URL(url).openConnection()
                    connection.connect()
                    connection.getInputStream().use { input ->
                        localFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    MeshStorageManager.autoPurgeCache(context)
                }
                
                val savedUri = MeshStorageManager.saveImageToPublicGallery(context, localFile)
                withContext(Dispatchers.Main) {
                    if (savedUri != null) {
                        android.widget.Toast.makeText(context, "Image saved to Gallery", android.widget.Toast.LENGTH_LONG).show()
                    } else {
                        android.widget.Toast.makeText(context, "Failed to save to Gallery", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("MeshViewModel", "Error saving image to gallery", e)
                withContext(Dispatchers.Main) {
                    android.widget.Toast.makeText(context, "Error saving image: ${e.localizedMessage}", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    override fun onCleared() {
        super.onCleared()
        // Removed stopping from onCleared so it persists in background
    }

    fun approveSpectator(id: String) {
        MeshNetworkManager._uiState.update { it.copy(
            pendingSpectators = it.pendingSpectators.filter { p -> p != id },
            approvedSpectators = it.approvedSpectators + id
        )}
    }
    fun rejectSpectator(id: String) {
        MeshNetworkManager._uiState.update { it.copy(
            pendingSpectators = it.pendingSpectators.filter { p -> p != id }
        )}
    }
}
