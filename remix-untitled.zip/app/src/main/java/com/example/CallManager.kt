package com.example

import android.content.Context
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PublicKey
import java.security.KeyFactory
import java.security.spec.X509EncodedKeySpec
import javax.crypto.KeyAgreement
import javax.crypto.SecretKey
import javax.crypto.spec.SecretKeySpec

enum class CallState {
    IDLE, INCOMING, OUTGOING, ACTIVE
}

data class CallSession(
    val state: CallState = CallState.IDLE,
    val peerId: String = "",
    val peerName: String = "",
    val peerIp: String = "",
    val isEncrypted: Boolean = false,
    val connectionType: String = "Wi-Fi Direct",
    val callDurationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = false,
    val isVideoEnabled: Boolean = false,
    val isMinimized: Boolean = false
)

object CallManager {
    private val _callSession = MutableStateFlow(CallSession())
    val callSession: StateFlow<CallSession> = _callSession.asStateFlow()

    private var myKeyPair: KeyPair? = null
    var sharedSecretKey: SecretKey? = null
    private var peerPublicKeyStrTemp: String? = null
    private var timerJob: Job? = null

    private var liveVoiceManager: LiveVoiceManager? = null
    private var liveVideoManager: LiveVideoManager? = null
    private var appContext: Context? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    fun init(context: Context) {
        appContext = context.applicationContext
        if (liveVoiceManager == null) {
            liveVoiceManager = LiveVoiceManager(context.applicationContext)
        }
        if (liveVideoManager == null) {
            liveVideoManager = LiveVideoManager(context.applicationContext)
        }
    }

    fun getLiveVideoManager(): LiveVideoManager? = liveVideoManager
    fun getLiveVoiceManager(): LiveVoiceManager? = liveVoiceManager

    fun initiateCall(peerId: String, peerName: String, peerIp: String = "", sendMessage: (String) -> Unit) {
        if (_callSession.value.state != CallState.IDLE) return

        myKeyPair = generateECKeyPair()
        val pubKeyBase64 = Base64.encodeToString(myKeyPair!!.public.encoded, Base64.NO_WRAP)
        val myIp = NetworkUtils.getLocalIpAddress()

        _callSession.update {
            CallSession(
                state = CallState.OUTGOING,
                peerId = peerId,
                peerName = peerName,
                peerIp = peerIp,
                isEncrypted = false,
                connectionType = "Wi-Fi Direct"
            )
        }

        val payload = JSONObject().apply {
            put("type", "call_offer")
            put("callerId", MeshNetworkManager.localNodeId)
            put("callerName", MeshNetworkManager.uiState.value.localUserName)
            put("callerIp", myIp)
            put("targetPeerId", peerId)
            put("pubKey", pubKeyBase64)
        }.toString()

        sendMessage(payload)
    }

    fun handleCallOffer(payload: JSONObject, sendMessage: (String) -> Unit) {
        val targetPeerId = payload.optString("targetPeerId")
        // If targeted to a specific peer and it's not us, ignore
        if (targetPeerId.isNotBlank() && targetPeerId != MeshNetworkManager.localNodeId) {
            return
        }

        if (_callSession.value.state != CallState.IDLE) {
            // Send busy signal
            val busyPayload = JSONObject().apply {
                put("type", "call_end")
                put("senderId", MeshNetworkManager.localNodeId)
                put("reason", "busy")
            }.toString()
            sendMessage(busyPayload)
            return
        }

        val callerId = payload.getString("callerId")
        val callerName = payload.getString("callerName")
        val callerIp = payload.optString("callerIp", "")
        val callerPubKeyStr = payload.getString("pubKey")

        peerPublicKeyStrTemp = callerPubKeyStr

        _callSession.update {
            CallSession(
                state = CallState.INCOMING,
                peerId = callerId,
                peerName = callerName,
                peerIp = callerIp,
                isEncrypted = false,
                connectionType = "Wi-Fi Direct"
            )
        }

        appContext?.let { ctx ->
            if (!MainActivity.isAppInForeground) {
                NotificationHelper.showIncomingCallNotification(ctx, callerName, callerId)
            }
        }
    }

    fun answerCall(sendMessage: (String) -> Unit) {
        appContext?.let { NotificationHelper.cancelCallNotification(it) }
        val peerPubKeyStr = peerPublicKeyStrTemp ?: return
        myKeyPair = generateECKeyPair()
        val myPubKeyBase64 = Base64.encodeToString(myKeyPair!!.public.encoded, Base64.NO_WRAP)
        val myIp = NetworkUtils.getLocalIpAddress()

        try {
            val peerPubKey = getPublicKeyFromString(peerPubKeyStr)
            sharedSecretKey = generateSharedSecret(myKeyPair!!.private, peerPubKey)
        } catch (e: Exception) {
            Log.e("CallManager", "Key exchange error", e)
        }

        _callSession.update {
            it.copy(
                state = CallState.ACTIVE,
                isEncrypted = (sharedSecretKey != null),
                callDurationSeconds = 0
            )
        }

        val payload = JSONObject().apply {
            put("type", "call_answer")
            put("responderId", MeshNetworkManager.localNodeId)
            put("responderIp", myIp)
            put("pubKey", myPubKeyBase64)
        }.toString()
        sendMessage(payload)

        startAudioSession()
    }

    fun handleCallAnswer(payload: JSONObject) {
        if (_callSession.value.state != CallState.OUTGOING) return
        val responderPubKeyStr = payload.getString("pubKey")
        val responderIp = payload.optString("responderIp", "")

        try {
            val responderPubKey = getPublicKeyFromString(responderPubKeyStr)
            sharedSecretKey = generateSharedSecret(myKeyPair!!.private, responderPubKey)
        } catch (e: Exception) {
            Log.e("CallManager", "Key exchange answer error", e)
        }

        _callSession.update {
            it.copy(
                state = CallState.ACTIVE,
                peerIp = if (responderIp.isNotBlank()) responderIp else it.peerIp,
                isEncrypted = (sharedSecretKey != null),
                callDurationSeconds = 0
            )
        }

        startAudioSession()
    }

    private fun startAudioSession() {
        startCallTimer()
        val peerIp = _callSession.value.peerIp.takeIf { it.isNotBlank() }
        liveVoiceManager?.let { vm ->
            vm.setTargetPeerIp(peerIp)
            vm.setMuted(_callSession.value.isMuted)
            vm.setSpeakerphoneOn(_callSession.value.isSpeakerOn)
            vm.startListening()
            vm.startBroadcasting()
        }
        if (_callSession.value.isVideoEnabled) {
            liveVideoManager?.startVideoSession(peerIp)
        }
    }

    private fun startCallTimer() {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (isActive && _callSession.value.state == CallState.ACTIVE) {
                delay(1000)
                _callSession.update { it.copy(callDurationSeconds = it.callDurationSeconds + 1) }
            }
        }
    }

    fun toggleMute() {
        val newMute = !_callSession.value.isMuted
        _callSession.update { it.copy(isMuted = newMute) }
        liveVoiceManager?.setMuted(newMute)
    }

    fun toggleSpeaker() {
        val newSpeaker = !_callSession.value.isSpeakerOn
        _callSession.update { it.copy(isSpeakerOn = newSpeaker) }
        liveVoiceManager?.setSpeakerphoneOn(newSpeaker)
    }

    fun toggleVideo() {
        val newVideo = !_callSession.value.isVideoEnabled
        _callSession.update { it.copy(isVideoEnabled = newVideo) }
        val peerIp = _callSession.value.peerIp.takeIf { it.isNotBlank() }
        if (newVideo && _callSession.value.state == CallState.ACTIVE) {
            liveVideoManager?.startVideoSession(peerIp)
        } else {
            liveVideoManager?.stopVideoSession()
        }
    }

    fun toggleMinimize() {
        _callSession.update { it.copy(isMinimized = !it.isMinimized) }
    }

    fun setMinimized(minimized: Boolean) {
        _callSession.update { it.copy(isMinimized = minimized) }
    }

    fun endCall(sendMessage: (String) -> Unit) {
        val payload = JSONObject().apply {
            put("type", "call_end")
            put("senderId", MeshNetworkManager.localNodeId)
        }.toString()
        sendMessage(payload)
        resetCall()
    }

    fun handleCallEnd() {
        resetCall()
    }

    fun declineCall(sendMessage: (String) -> Unit) {
        endCall(sendMessage)
    }

    private fun resetCall() {
        val session = _callSession.value
        appContext?.let { ctx ->
            NotificationHelper.cancelCallNotification(ctx)
            if (session.state != CallState.IDLE) {
                val callType = when {
                    session.state == CallState.OUTGOING -> "OUTGOING"
                    session.state == CallState.INCOMING && session.callDurationSeconds == 0 -> "MISSED"
                    else -> "INCOMING"
                }
                scope.launch(Dispatchers.IO) {
                    try {
                        com.example.data.MeshChatDatabase.getDatabase(ctx).callLogDao().insertCallLog(
                            com.example.data.CallLogEntity(
                                peerId = session.peerId,
                                peerName = session.peerName.ifBlank { "Nearby Peer" },
                                callType = callType,
                                durationSeconds = session.callDurationSeconds,
                                isVideo = session.isVideoEnabled,
                                timestamp = System.currentTimeMillis()
                            )
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        timerJob?.cancel()
        timerJob = null
        liveVoiceManager?.stopBroadcasting()
        liveVoiceManager?.stopListening()
        liveVoiceManager?.setTargetPeerIp(null)
        liveVideoManager?.stopVideoSession()
        liveVideoManager?.setTargetPeerIp(null)

        _callSession.update { CallSession() }
        myKeyPair = null
        sharedSecretKey = null
        peerPublicKeyStrTemp = null
    }

    private fun generateECKeyPair(): KeyPair {
        val keyGen = KeyPairGenerator.getInstance("EC")
        keyGen.initialize(256)
        return keyGen.generateKeyPair()
    }

    private fun getPublicKeyFromString(base64Str: String): PublicKey {
        val bytes = Base64.decode(base64Str, Base64.NO_WRAP)
        return KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(bytes))
    }

    private fun generateSharedSecret(privateKey: java.security.PrivateKey, publicKey: PublicKey): SecretKey {
        val keyAgreement = KeyAgreement.getInstance("ECDH")
        keyAgreement.init(privateKey)
        keyAgreement.doPhase(publicKey, true)
        val secretBytes = keyAgreement.generateSecret()
        return SecretKeySpec(secretBytes, 0, 32, "AES")
    }
}
