package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium High-Contrast Dark Theme (60-30-10 Rule)
val PremiumBackground = Color(0xFF0F172A) // 60% Deep Slate (Dark)
val PremiumSurface = Color(0xFF1E293B) // 30% Lighter Slate (Surface)
val PremiumPrimary = Color(0xFF10B981) // 10% Emerald Accent
val PremiumPrimaryDark = Color(0xFF047857) // Dark Emerald
val PremiumSecondary = Color(0xFF3B82F6) // Blue Accent
val PremiumAccent = Color(0xFFEF4444) // Red error/close
val PremiumBorder = Color(0xFF334155) // Slate Border

// Text Colors
val PremiumTextPrimary = Color(0xFFF8FAFC) // Off White
val PremiumTextSecondary = Color(0xFF94A3B8) // Slate Gray
