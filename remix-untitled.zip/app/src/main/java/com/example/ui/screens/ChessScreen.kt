package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ChessEngine
import com.example.ChessState
import com.example.MeshNetworkManager

@Composable
fun ChessScreen(
    state: ChessState,
    onStateChange: (ChessState) -> Unit,
    modifier: Modifier = Modifier
) {
    val myNodeId = MeshNetworkManager.localNodeId
    
    val isWhite = state.whitePlayerId == myNodeId
    val isBlack = state.blackPlayerId == myNodeId
    val isSpectator = !isWhite && !isBlack

    var selectedIdx by remember { mutableStateOf<Int?>(null) }

    Column(modifier = modifier.fillMaxSize().background(Color(0xFF222222)), horizontalAlignment = Alignment.CenterHorizontally) {
        
        // Status Bar
        Card(
            modifier = Modifier.padding(8.dp).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF333333))
        ) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (state.winner.isNotEmpty()) {
                    Text("${state.winner} Wins!", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Button(onClick = { onStateChange(ChessEngine.reset()) }, modifier = Modifier.padding(top = 8.dp)) {
                        Text("Reset Board")
                    }
                } else {
                    val turnText = if (state.isWhiteTurn) "White's Turn" else "Black's Turn"
                    Text(turnText, color = Color.White, style = MaterialTheme.typography.titleMedium)
                }

                Spacer(modifier = Modifier.height(8.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    if (state.whitePlayerId.isEmpty()) {
                        Button(onClick = { onStateChange(ChessEngine.claimRole(state, myNodeId, "white")) }) { Text("Play White") }
                        if (isBlack) Button(onClick = { onStateChange(ChessEngine.claimRole(state, "bot", "white")) }) { Text("Bot White") }
                    } else if (isWhite) {
                        Button(onClick = { onStateChange(ChessEngine.leaveRole(state, myNodeId)) }, colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)) { Text("Leave") }
                    } else {
                        Text("White: Taken", color = Color.LightGray)
                    }

                    if (state.blackPlayerId.isEmpty()) {
                        Button(onClick = { onStateChange(ChessEngine.claimRole(state, myNodeId, "black")) }) { Text("Play Black") }
                        if (isWhite) Button(onClick = { onStateChange(ChessEngine.claimRole(state, "bot", "black")) }) { Text("Bot Black") }
                    } else if (isBlack) {
                        Button(onClick = { onStateChange(ChessEngine.leaveRole(state, myNodeId)) }, colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)) { Text("Leave") }
                    } else {
                        Text("Black: Taken", color = Color.LightGray)
                    }
                }
            }
        }

        // Board
        Box(modifier = Modifier.weight(1f).aspectRatio(1f).padding(8.dp).border(4.dp, Color(0xFF5D4037))) {
            Column(modifier = Modifier.fillMaxSize()) {
                for (row in 0..7) {
                    Row(modifier = Modifier.weight(1f)) {
                        for (col in 0..7) {
                            val isLight = (row + col) % 2 == 0
                            val bgColor = if (isLight) Color(0xFFD7CCC8) else Color(0xFF795548)
                            val idx = row * 8 + col
                            val pieceStr = state.pieces[idx]
                            
                            val isSelected = selectedIdx == idx
                            val cellColor = if (isSelected) Color(0xFFFFF59D) else bgColor

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .background(cellColor)
                                    .clickable {
                                        if (isSpectator || state.winner.isNotEmpty()) return@clickable
                                        
                                        if (selectedIdx == null) {
                                            // Select piece
                                            if (pieceStr.isNotEmpty()) {
                                                val pieceIsWhite = pieceStr.first().isUpperCase()
                                                if ((isWhite && pieceIsWhite && state.isWhiteTurn) || (isBlack && !pieceIsWhite && !state.isWhiteTurn)) {
                                                    selectedIdx = idx
                                                }
                                            }
                                        } else {
                                            // Move piece
                                            if (selectedIdx == idx) {
                                                selectedIdx = null // Deselect
                                            } else {
                                                val newState = ChessEngine.move(state, selectedIdx!!, idx, myNodeId)
                                                onStateChange(newState)
                                                selectedIdx = null
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (pieceStr.isNotEmpty()) {
                                    val pieceChar = getPieceChar(pieceStr)
                                    val isPieceWhite = pieceStr.first().isUpperCase()
                                    Text(
                                        text = pieceChar,
                                        fontSize = 32.sp,
                                        color = if (isPieceWhite) Color.White else Color.Black,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun getPieceChar(piece: String): String {
    return when (piece) {
        "P" -> "♙"
        "R" -> "♖"
        "N" -> "♘"
        "B" -> "♗"
        "Q" -> "♕"
        "K" -> "♔"
        "p" -> "♟"
        "r" -> "♜"
        "n" -> "♞"
        "b" -> "♝"
        "q" -> "♛"
        "k" -> "♚"
        else -> ""
    }
}
