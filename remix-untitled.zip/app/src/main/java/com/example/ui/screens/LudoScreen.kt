package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.LudoEngine
import com.example.LudoState

@Composable
fun LudoScreen(
    state: LudoState,
    onStateChange: (LudoState) -> Unit,
    modifier: Modifier = Modifier
) {
    val playerColors = listOf(
        Color(0xFFEF4444), // Red
        Color(0xFF10B981), // Green
        Color(0xFFF59E0B), // Yellow
        Color(0xFF3B82F6)  // Blue
    )
    val playerNames = listOf("Red", "Green", "Yellow", "Blue")
    val myNodeId = com.example.MeshNetworkManager.localNodeId
    val isMyTurn = state.playerIds[state.turn] == myNodeId

    Column(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), horizontalAlignment = Alignment.CenterHorizontally) {
        // Top Status Bar
        Card(
            modifier = Modifier.padding(top = 48.dp, start = 8.dp, end = 8.dp).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = playerColors[state.turn].copy(alpha = 0.8f))
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Text(
                    text = if (state.winner != -1) "${playerNames[state.winner]} WINS!" else "${playerNames[state.turn]}'s Turn",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Player Join Bar
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            for (i in 0..3) {
                if (state.playerIds[i].isNullOrEmpty()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Button(onClick = { 
                            val newIds = state.playerIds.toMutableMap()
                            newIds[i] = myNodeId
                            onStateChange(state.copy(playerIds = newIds))
                        }, colors = ButtonDefaults.buttonColors(containerColor = playerColors[i]), modifier = Modifier.height(36.dp)) { Text("Claim") }
                        val isPlaying = state.playerIds.values.contains(myNodeId)
                        if (isPlaying) {
                            Button(onClick = { 
                                val newIds = state.playerIds.toMutableMap()
                                newIds[i] = "bot"
                                val next = state.copy(playerIds = newIds)
                                if (next.turn == i) {
                                    onStateChange(LudoEngine.makeBotMove(next))
                                } else {
                                    onStateChange(next)
                                }
                            }, colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray), modifier = Modifier.height(36.dp)) { Text("Bot") }
                        }
                    }
                } else {
                    Text(if (state.playerIds[i] == myNodeId) "You" else if (state.playerIds[i] == "bot") "Bot" else "Taken", color = if (state.playerIds[i] == myNodeId) playerColors[i] else Color.LightGray)
                }
            }
        }
        
        BoxWithConstraints(modifier = Modifier.weight(1f).aspectRatio(1f).padding(8.dp).background(MaterialTheme.colorScheme.surface).border(2.dp, MaterialTheme.colorScheme.primary)) {
            val cellSize = maxWidth / 15f
            val borderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
            
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                val cellPx = cellSize.toPx()
                for (row in 0..14) {
                    for (col in 0..14) {
                        val bgColor = getCellColor(col, row)
                        drawRect(
                            color = bgColor,
                            topLeft = androidx.compose.ui.geometry.Offset(col * cellPx, row * cellPx),
                            size = androidx.compose.ui.geometry.Size(cellPx, cellPx)
                        )
                        drawRect(
                            color = borderColor,
                            topLeft = androidx.compose.ui.geometry.Offset(col * cellPx, row * cellPx),
                            size = androidx.compose.ui.geometry.Size(cellPx, cellPx),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f)
                        )
                    }
                }
            }
            
            // Overlay Pieces (Absolute Positioning to avoid deep view trees)
            val piecesHere = mutableMapOf<Pair<Int, Int>, MutableList<Pair<Int, Int>>>()
            for (p in 0..3) {
                for (i in 0..3) {
                    val coord = LudoEngine.getCoordinate(p, i, state.pieces[p]!![i])
                    piecesHere.getOrPut(coord) { mutableListOf() }.add(p to i)
                }
            }
            
            piecesHere.forEach { (coord, pieces) ->
                val (col, row) = coord
                pieces.forEachIndexed { index, pair ->
                    val (p, idx) = pair
                    Box(
                        modifier = Modifier
                            .offset(
                                x = (cellSize * col) + (cellSize * 0.15f) + (index * 4).dp,
                                y = (cellSize * row) + (cellSize * 0.15f) + (index * 4).dp
                            )
                            .size(cellSize * 0.7f)
                            .background(playerColors[p], CircleShape)
                            .border(2.dp, Color.White, CircleShape)
                            .clickable {
                                if (state.turn == p && state.hasRolled && state.playerIds[p] == myNodeId) {
                                    val next = LudoEngine.movePiece(state, p, idx)
                                    if (next.playerIds[next.turn] == "bot") {
                                        onStateChange(LudoEngine.makeBotMove(next))
                                    } else {
                                        onStateChange(next)
                                    }
                                }
                            }
                    )
                }
            }
        }

        // Bottom Control Deck
        Card(
            modifier = Modifier.padding(8.dp).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                if (state.winner == -1) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (!state.hasRolled) "TAP TO ROLL" else "SELECT A PIECE TO MOVE", 
                            style = MaterialTheme.typography.labelLarge, 
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .background(if(!state.hasRolled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                                .border(4.dp, MaterialTheme.colorScheme.primary, androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                                .clickable(enabled = !state.hasRolled) {
                                    if (!state.hasRolled && state.playerIds[state.turn] == myNodeId) {
                                        val next = LudoEngine.rollDice(state)
                                        if (next.playerIds[next.turn] == "bot") {
                                            onStateChange(LudoEngine.makeBotMove(next))
                                        } else {
                                            onStateChange(next)
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                if (state.hasRolled || state.diceValue > 0) state.diceValue.toString() else "?", 
                                style = MaterialTheme.typography.displayMedium, 
                                color = MaterialTheme.colorScheme.onBackground, // Always bright
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    Text("Game Over", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.headlineMedium)
                }
            }
        }
    }
}

fun getCellColor(col: Int, row: Int): Color {
    val red = Color(0xFF7F1D1D) // Darker Red for board background
    val green = Color(0xFF064E3B)
    val yellow = Color(0xFF78350F)
    val blue = Color(0xFF1E3A8A)
    val empty = Color(0xFF1E293B) // Dark Surface

    if (col in 0..5 && row in 0..5) return red
    if (col in 9..14 && row in 0..5) return green
    if (col in 9..14 && row in 9..14) return yellow
    if (col in 0..5 && row in 9..14) return blue
    if (col in 6..8 && row in 6..8) return Color.DarkGray

    if (col in 1..5 && row == 7) return red
    if (col == 7 && row in 1..5) return green
    if (col in 9..13 && row == 7) return yellow
    if (col == 7 && row in 9..13) return blue

    if (col == 1 && row == 6) return red
    if (col == 8 && row == 1) return green
    if (col == 13 && row == 8) return yellow
    if (col == 6 && row == 13) return blue

    return empty
}
