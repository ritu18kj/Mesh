package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.border
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import com.example.*
import com.example.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainChatScreen(
    viewModel: MeshViewModel,
    onLaunchLocationPermission: () -> Unit
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val diagnosticEvents by viewModel.diagnosticEvents.collectAsStateWithLifecycle()
    val callLogs by viewModel.callLogs.collectAsStateWithLifecycle()

    val locationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        if (permissions.values.any { it }) {
            // Location permission granted; location tracking will start on-demand when entering Radar tab
            viewModel.pingRadarLocation()
        }
    }
        
    var currentTab by remember { mutableStateOf("Chat") }
    var showHotspotDialog by remember { mutableStateOf(false) }
    var showDiagnosticsDialog by remember { mutableStateOf(false) }
    var selectedUser by remember { mutableStateOf<ChatMessage?>(null) }
    var showPanicWipeConfirmDialog by remember { mutableStateOf(false) }
    var showCallPickerSheet by remember { mutableStateOf(false) }
    var callPickerIsVideo by remember { mutableStateOf(false) }
    var showNoPeersDialog by remember { mutableStateOf(false) }

        // Incoming Media Invite
    if (uiState.incomingInvite != null) {
        AlertDialog(
            onDismissRequest = { viewModel.rejectInvite() },
            title = { Text("Game/Media Invite") },
            text = { Text("Someone started a shared session (${uiState.incomingInvite?.type}). Do you want to join?") },
            confirmButton = {
                Button(onClick = { viewModel.acceptInvite() }) { Text("Join") }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.rejectInvite() }) { Text("Ignore") }
            }
        )
    }

    if (uiState.pendingSpectators.isNotEmpty()) {
        val spectatorId = uiState.pendingSpectators.first()
        AlertDialog(
            onDismissRequest = { viewModel.rejectSpectator(spectatorId) },
            title = { Text("Web Spectator Request") },
            text = { Text("A web spectator ($spectatorId) wants to join the mesh.") },
            confirmButton = {
                TextButton(onClick = { viewModel.approveSpectator(spectatorId) }) { Text("Approve") }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.rejectSpectator(spectatorId) }) { Text("Reject", color = Color.Red) }
            }
        )
    }

    LaunchedEffect(uiState.isHotspotActive) {
        if (uiState.isHotspotActive) showHotspotDialog = true
        else showHotspotDialog = false
    }

    LaunchedEffect(uiState.webClientConnectedEvent) {
        if (uiState.webClientConnectedEvent) {
            showHotspotDialog = false
            viewModel.clearWebClientConnectedEvent()
        }
    }

    // Check if a game is active in fullscreen
        var isGameMinimized by remember { mutableStateOf(false) }
    val isGameActive = uiState.sharedMediaType != "none" && uiState.sharedMediaType.isNotEmpty()
    
    LaunchedEffect(uiState.sharedMediaType) {
        if (uiState.sharedMediaType != "none") {
            isGameMinimized = false
        }
    }

    var showTopMenu by remember { mutableStateOf(false) }
    var showRoomSetupDialog by remember { mutableStateOf(false) }
    var showRosterDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var profileNameInput by remember { mutableStateOf(uiState.localUserName) }
    var profileUsernameIdInput by remember { mutableStateOf(uiState.localUsernameId) }
    var profileIsPermanent by remember { mutableStateOf(uiState.isUsernamePermanent) }
    var profileIsGhost by remember { mutableStateOf(uiState.isGhostMode) }

    var showSOSConfirmDialog by remember { mutableStateOf(false) }
    var sosCustomReasonInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            if (!isGameActive || isGameMinimized) {
                val isDmActive = uiState.activeDmPeerId != null
                val dmPeerId = uiState.activeDmPeerId
                val dmPeerName = if (dmPeerId != null) (uiState.knownUsers[dmPeerId] ?: "Peer_${dmPeerId.take(5)}") else ""
                val dmPeerHandle = if (dmPeerId != null) (uiState.knownUserIds[dmPeerId] ?: "@${dmPeerName.lowercase().replace(" ", "")}") else ""

                TopAppBar(
                    title = {
                        if (isDmActive) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF203540)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Person,
                                        contentDescription = null,
                                        tint = WhatsAppGreen,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = dmPeerName,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFE9EDEF)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            Icons.Default.Lock,
                                            contentDescription = "Private DM",
                                            tint = WhatsAppCheckmarkBlue,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    }
                                    Text(
                                        text = "$dmPeerHandle • Private 1-on-1 Mesh",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = WhatsAppCheckmarkBlue,
                                        maxLines = 1
                                    )
                                }
                            }
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable { showProfileDialog = true }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(WhatsAppOutgoingDark),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Group,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "MeshChat Room",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFE9EDEF)
                                    )
                                    Text(
                                        text = buildString {
                                            append("${uiState.connectedNodes.size + 1} online • ${uiState.localUserName} (${uiState.localUsernameId})")
                                            if (uiState.isGhostMode) append(" • 👻 Ghost")
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (uiState.isGhostMode) Color(0xFFB388FF) else WhatsAppGreen,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    },
                    navigationIcon = {
                        if (isDmActive) {
                            IconButton(onClick = { viewModel.clearDmPeer() }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back to Public Room", tint = Color.White)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = if (uiState.isEmergencyMode) Color(0xFFB71C1C) else Color(0xFF1F2C34)
                    ),
                    actions = {
                        // Quick SOS Beacon button in action bar
                        IconButton(onClick = { showSOSConfirmDialog = true }) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = "Emergency SOS Beacon",
                                tint = if (uiState.isEmergencyMode) Color.Yellow else Color(0xFFFF5252)
                            )
                        }
                        IconButton(
                            onClick = {
                                if (uiState.connectedNodes.isEmpty()) {
                                    showNoPeersDialog = true
                                } else if (uiState.connectedNodes.size == 1) {
                                    val peer = uiState.connectedNodes.first()
                                    val peerName = uiState.knownUsers[peer.id] ?: peer.name
                                    val peerIp = if (uiState.isHotspotActive) "192.168.49.1" else ""
                                    CallManager.initiateCall(peer.id, peerName, peerIp) { payload ->
                                        com.example.MeshNetworkManager.meshRouter.routeLocalMessage(payload)
                                        com.example.MeshNetworkManager.webServerManager?.broadcastMessage(payload, com.example.MeshNetworkManager.localNodeId)
                                    }
                                } else {
                                    callPickerIsVideo = true
                                    showCallPickerSheet = true
                                }
                            }
                        ) {
                            Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = Color(0xFFE9EDEF))
                        }
                        IconButton(
                            onClick = {
                                if (uiState.connectedNodes.isEmpty()) {
                                    showNoPeersDialog = true
                                } else if (uiState.connectedNodes.size == 1) {
                                    val peer = uiState.connectedNodes.first()
                                    val peerName = uiState.knownUsers[peer.id] ?: peer.name
                                    val peerIp = if (uiState.isHotspotActive) "192.168.49.1" else ""
                                    CallManager.initiateCall(peer.id, peerName, peerIp) { payload ->
                                        com.example.MeshNetworkManager.meshRouter.routeLocalMessage(payload)
                                        com.example.MeshNetworkManager.webServerManager?.broadcastMessage(payload, com.example.MeshNetworkManager.localNodeId)
                                    }
                                } else {
                                    callPickerIsVideo = false
                                    showCallPickerSheet = true
                                }
                            }
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "Voice Call", tint = Color(0xFFE9EDEF))
                        }
                        // WhatsApp Style 2 QR Codes Button (Wi-Fi & WebChat)
                        IconButton(
                            onClick = {
                                if (uiState.isHotspotActive) {
                                    showHotspotDialog = true
                                } else {
                                    showRoomSetupDialog = true
                                }
                            }
                        ) {
                            Icon(
                                Icons.Default.QrCode2,
                                contentDescription = "2 QR Codes (WebChat & Wi-Fi)",
                                tint = if (uiState.isHotspotActive) WhatsAppGreen else Color(0xFFE9EDEF)
                            )
                        }
                        IconButton(onClick = { showTopMenu = true }) {
                            Icon(Icons.Default.MoreVert, "More Options", tint = Color(0xFFE9EDEF))
                        }
                        DropdownMenu(
                            expanded = showTopMenu,
                            onDismissRequest = { showTopMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AccountCircle, contentDescription = null, tint = WhatsAppGreen, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text("Profile & Username", fontWeight = FontWeight.SemiBold)
                                            Text(uiState.localUsernameId, style = MaterialTheme.typography.labelSmall, color = WhatsAppSubtleText)
                                        }
                                    }
                                },
                                onClick = { 
                                    showTopMenu = false
                                    profileNameInput = uiState.localUserName
                                    profileUsernameIdInput = uiState.localUsernameId
                                    profileIsPermanent = uiState.isUsernamePermanent
                                    profileIsGhost = uiState.isGhostMode
                                    showProfileDialog = true 
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.QrCode2, contentDescription = null, tint = WhatsAppGreen, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text("2 QR Codes (WebChat & Wi-Fi)", fontWeight = FontWeight.SemiBold)
                                            Text(if (uiState.isHotspotActive) "Hotspot Running • 2 QRs Active" else "Start Room / View 2 QRs", style = MaterialTheme.typography.labelSmall, color = WhatsAppSubtleText)
                                        }
                                    }
                                },
                                onClick = {
                                    showTopMenu = false
                                    if (uiState.isHotspotActive) showHotspotDialog = true
                                    else showRoomSetupDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF53BDEB), modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Room Roster & Members")
                                    }
                                },
                                onClick = {
                                    showTopMenu = false
                                    showRosterDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(if (uiState.isScanning) Icons.Default.BluetoothSearching else Icons.Default.Bluetooth, contentDescription = null, tint = WhatsAppGreen, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(if (uiState.isScanning) "BLE Mesh Scanning (On)" else "BLE Mesh Scanning (Off)")
                                    }
                                },
                                onClick = {
                                    showTopMenu = false
                                    viewModel.toggleScanning()
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Sensors, contentDescription = null, tint = if (uiState.autoJoinBeaconEnabled) Color(0xFF25D366) else Color.Gray, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text("BLE Pulse Auto-Join", fontWeight = FontWeight.SemiBold)
                                            Text(
                                                if (uiState.autoJoinBeaconEnabled) "Auto-join mesh rooms (Enabled)" else "Disabled (Manual connect)",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFF8696A0)
                                            )
                                        }
                                    }
                                },
                                onClick = { 
                                    showTopMenu = false
                                    viewModel.toggleAutoJoinBeacon()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(if (uiState.isEmergencyMode) "Active SOS Beacon (Cancel)" else "Broadcast SOS Beacon 🚨", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold) },
                                onClick = { showTopMenu = false; showSOSConfirmDialog = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Show Diagnostics") },
                                onClick = { showTopMenu = false; showDiagnosticsDialog = true }
                            )

                            DropdownMenuItem(
                                text = { Text("Start Burner Room 🔥", color = MaterialTheme.colorScheme.error) },
                                onClick = { showTopMenu = false; viewModel.startBurnerRoom(300) }
                            )
                            DropdownMenuItem(
                                text = { Text("Clear Chat") },
                                onClick = { showTopMenu = false; viewModel.clearChat() }
                            )
                            DropdownMenuItem(
                                text = { Text("Disconnect & Reset") },
                                onClick = { showTopMenu = false; viewModel.disconnectAndCleanup() }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color(0xFFEA4335), modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Emergency Panic Wipe", color = Color(0xFFEA4335), fontWeight = FontWeight.Bold)
                                    }
                                },
                                onClick = {
                                    showTopMenu = false
                                    showPanicWipeConfirmDialog = true
                                }
                            )
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (!isGameActive || isGameMinimized) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.background,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentTab == "Chat",
                        onClick = { currentTab = "Chat" },
                        icon = { Icon(Icons.Default.Chat, "Chat") },
                        label = { Text("Chats") }
                    )
                    NavigationBarItem(
                        selected = currentTab == "Calls",
                        onClick = { currentTab = "Calls" },
                        icon = {
                            val missedCount = callLogs.count { it.callType == "MISSED" }
                            if (missedCount > 0) {
                                BadgedBox(
                                    badge = { Badge { Text(missedCount.toString()) } }
                                ) {
                                    Icon(Icons.Default.Call, "Calls")
                                }
                            } else {
                                Icon(Icons.Default.Call, "Calls")
                            }
                        },
                        label = { Text("Calls") }
                    )
                    NavigationBarItem(
                        selected = currentTab == "Radar",
                        onClick = { currentTab = "Radar" },
                        icon = { Icon(Icons.Default.LocationOn, "Radar") },
                        label = { Text("Radar") }
                    )
                    NavigationBarItem(
                        selected = currentTab == "Arcade",
                        onClick = { currentTab = "Arcade" },
                        icon = { Icon(Icons.Default.Edit, "Arcade") },
                        label = { Text("Arcade") }
                    )
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            if (isGameActive && !isGameMinimized) {
                BackHandler {
                    isGameMinimized = true
                }
                // Game Fullscreen View
                Column(modifier = Modifier.fillMaxSize()) {
                    // Action Buttons for Game (Top Bar)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(8.dp),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.TextButton(
                            onClick = { 
                                isGameMinimized = true
                                currentTab = "Arcade" 
                            }
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back to Chat", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Minimize", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        
                        Text(
                            text = uiState.sharedMediaType.uppercase(),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        androidx.compose.material3.TextButton(
                            onClick = { 
                                // End the game globally
                                viewModel.setSharedMedia("none", "", "collaborative", 0)
                                currentTab = "Arcade" 
                            }
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "End Session", tint = androidx.compose.ui.graphics.Color(0xFFEF5350))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("End", color = androidx.compose.ui.graphics.Color(0xFFEF5350))
                        }
                    }
                    SharedMediaScreen(
                        uiState = uiState,
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    )
                }
            } else {
                // Tab Views
                when (currentTab) {
                    "Chat" -> {
                        ChatTab(uiState, viewModel, onUserClick = { selectedUser = it })
                    }
                    "Calls" -> {
                        CallsTabScreen(
                            uiState = uiState,
                            callLogs = callLogs,
                            onInitiateCall = { peerId, peerName, isVideo ->
                                val peerIp = if (uiState.isHotspotActive) "192.168.49.1" else ""
                                CallManager.initiateCall(peerId, peerName, peerIp) { payload ->
                                    com.example.MeshNetworkManager.meshRouter.routeLocalMessage(payload)
                                    com.example.MeshNetworkManager.webServerManager?.broadcastMessage(payload, com.example.MeshNetworkManager.localNodeId)
                                }
                            }
                        )
                    }
                    "Radar" -> {
                        RadarScreen(viewModel)
                    }
                    "Arcade" -> {
                        ArcadeTab(uiState, viewModel)
                    }
                }
            }
        }
        
        if (showRoomSetupDialog) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showRoomSetupDialog = false },
                title = { Text("Create Mesh Room") },
                text = { Text("Do you want this room to be Public (open to everyone nearby) or Private (requires users to manually enter the password)?") },
                confirmButton = {
                    Button(onClick = {
                        viewModel.toggleHotspot(isPrivate = false)
                        showRoomSetupDialog = false
                        showHotspotDialog = true
                    }) { Text("Public Room") }
                },
                dismissButton = {
                    OutlinedButton(onClick = {
                        viewModel.toggleHotspot(isPrivate = true)
                        showRoomSetupDialog = false
                        showHotspotDialog = true
                    }) { Text("Private Room") }
                }
            )
        }
        
        if (showProfileDialog) {
            AlertDialog(
                onDismissRequest = { showProfileDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.AccountCircle,
                            contentDescription = null,
                            tint = WhatsAppGreen,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Profile & Username ID", fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(top = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // WhatsApp Style Circular Avatar Header
                        Box(contentAlignment = Alignment.BottomEnd) {
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .clip(CircleShape)
                                    .background(WhatsAppOutgoingDark)
                                    .border(2.dp, WhatsAppGreen, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = profileNameInput.firstOrNull()?.uppercase() ?: "M",
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(WhatsAppGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.CameraAlt,
                                    contentDescription = "Edit photo",
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }

                        Text(
                            text = "🟢 Active on Mesh & WebChat",
                            style = MaterialTheme.typography.labelSmall,
                            color = WhatsAppGreen,
                            fontWeight = FontWeight.SemiBold
                        )

                        // Display Name (WhatsApp Style)
                        OutlinedTextField(
                            value = profileNameInput,
                            onValueChange = { profileNameInput = it },
                            label = { Text("Display Name (WhatsApp)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = WhatsAppGreen)
                            },
                            supportingText = {
                                Text("Visible to everyone in mesh group chats and room roster", fontSize = 11.sp)
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = WhatsAppGreen,
                                focusedLabelColor = WhatsAppGreen,
                                cursorColor = WhatsAppGreen
                            )
                        )

                        // Username ID (@handle - Instagram Style)
                        OutlinedTextField(
                            value = profileUsernameIdInput,
                            onValueChange = { input ->
                                val clean = input.trim().lowercase().replace("[^a-z0-9_@]".toRegex(), "")
                                profileUsernameIdInput = if (clean.startsWith("@") || clean.isEmpty()) clean else "@$clean"
                            },
                            label = { Text("Username ID (Instagram Handle)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = {
                                Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = Color(0xFF53BDEB))
                            },
                            trailingIcon = {
                                TextButton(
                                    onClick = {
                                        profileUsernameIdInput = viewModel.generateRandomHandle()
                                    }
                                ) {
                                    Text("🎲 Roll", color = WhatsAppGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            },
                            supportingText = {
                                Text("Your unique handle for @mentions, tagging, and direct calling", fontSize = 11.sp)
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF53BDEB),
                                focusedLabelColor = Color(0xFF53BDEB),
                                cursorColor = Color(0xFF53BDEB)
                            )
                        )

                        // Profile Mode Selection (WhatsApp Permanent vs Instagram/Guest Temporary)
                        Text(
                            text = "ACCOUNT IDENTITY MODE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = WhatsAppSubtleText,
                            modifier = Modifier.align(Alignment.Start)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Permanent Card (WhatsApp)
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { profileIsPermanent = true },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (profileIsPermanent) WhatsAppOutgoingDark else Color(0xFF1F2C34)
                                ),
                                border = if (profileIsPermanent) androidx.compose.foundation.BorderStroke(2.dp, WhatsAppGreen) else null
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            if (profileIsPermanent) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                            contentDescription = null,
                                            tint = if (profileIsPermanent) WhatsAppGreen else WhatsAppSubtleText,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            "Permanent",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFFE9EDEF)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "WhatsApp style. Saved locally across reboots.",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        color = WhatsAppSubtleText,
                                        lineHeight = 13.sp
                                    )
                                }
                            }

                            // Temporary Card (Instagram/Guest Burner)
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { profileIsPermanent = false },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (!profileIsPermanent) Color(0xFF332712) else Color(0xFF1F2C34)
                                ),
                                border = if (!profileIsPermanent) androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFFF9800)) else null
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            if (!profileIsPermanent) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                            contentDescription = null,
                                            tint = if (!profileIsPermanent) Color(0xFFFF9800) else WhatsAppSubtleText,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            "Temporary",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFFE9EDEF)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Guest / Burner. Identity wiped on exit.",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        color = WhatsAppSubtleText,
                                        lineHeight = 13.sp
                                    )
                                }
                            }
                        }

                        // Ghost Mode Storage Setting (Ephemeral RAM-Only vs Stored in Room)
                        Text(
                            text = "CHAT STORAGE & HISTORY PRIVACY",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = WhatsAppSubtleText,
                            modifier = Modifier.align(Alignment.Start)
                        )

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { profileIsGhost = !profileIsGhost },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (profileIsGhost) Color(0xFF261D38) else Color(0xFF1F2C34)
                            ),
                            border = if (profileIsGhost) androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFB388FF)) else null
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (profileIsGhost) Icons.Default.VisibilityOff else Icons.Default.Save,
                                    contentDescription = null,
                                    tint = if (profileIsGhost) Color(0xFFB388FF) else WhatsAppSubtleText,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            if (profileIsGhost) "👻 Ghost Mode (Active)" else "💾 Persistent Storage (Default)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (profileIsGhost) Color(0xFFD1C4E9) else Color(0xFFE9EDEF)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        if (profileIsGhost) "RAM-only! Zero Room SQLite disk writes. Vanishes on app close."
                                        else "Messages saved locally in Room database across app restarts.",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        color = WhatsAppSubtleText,
                                        lineHeight = 13.sp
                                    )
                                }
                                Switch(
                                    checked = profileIsGhost,
                                    onCheckedChange = { profileIsGhost = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color(0xFFB388FF),
                                        checkedTrackColor = Color(0xFF5E35B1),
                                        uncheckedThumbColor = WhatsAppSubtleText,
                                        uncheckedTrackColor = Color(0xFF121B22)
                                    )
                                )
                            }
                        }

                        // Live Chat Preview Card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = WhatsAppChatBackgroundDark),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0xFF1F2C34), RoundedCornerShape(12.dp))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    "LIVE CHAT PREVIEW",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = WhatsAppSubtleText,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    color = WhatsAppOutgoingDark,
                                    shape = RoundedCornerShape(topStart = 14.dp, topEnd = 2.dp, bottomStart = 14.dp, bottomEnd = 14.dp),
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = if (profileNameInput.isNotBlank()) profileNameInput else "Me",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = WhatsAppGreen
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (profileUsernameIdInput.isNotBlank()) profileUsernameIdInput else "@user",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFF8696A0),
                                                fontSize = 11.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "Connected to offline mesh chat!",
                                            color = Color(0xFFE9EDEF),
                                            fontSize = 14.sp
                                        )
                                        Row(
                                            modifier = Modifier.align(Alignment.End),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("12:00", fontSize = 10.sp, color = WhatsAppSubtleText)
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Icon(
                                                Icons.Default.DoneAll,
                                                contentDescription = null,
                                                modifier = Modifier.size(13.dp),
                                                tint = WhatsAppCheckmarkBlue
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (profileNameInput.isNotBlank()) {
                                viewModel.updateUserName(
                                    newName = profileNameInput.trim(),
                                    newUsernameId = profileUsernameIdInput.trim(),
                                    isPermanent = profileIsPermanent
                                )
                            }
                            viewModel.setGhostMode(profileIsGhost)
                            showProfileDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                    ) {
                        Text("Save & Apply", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { showProfileDialog = false }) { Text("Cancel") }
                }
            )
        }
        
        if (showRosterDialog) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showRosterDialog = false },
                title = { Text("Room Roster") },
                text = {
                    LazyColumn {
                        items(uiState.connectedNodes.filter { it.name.isNotBlank() }) { node ->
                            val displayName = uiState.knownUsers[node.id] ?: node.name
                            val handle = uiState.knownUserIds[node.id] ?: "@${node.name.lowercase().replace(" ", "")}"
                            ListItem(
                                headlineContent = { Text(displayName, fontWeight = FontWeight.SemiBold) },
                                supportingContent = { Text(handle, color = Color(0xFF25D366), style = MaterialTheme.typography.labelSmall) },
                                leadingContent = {
                                    Box(
                                        modifier = Modifier.size(12.dp).background(Color(0xFF25D366), shape = androidx.compose.foundation.shape.CircleShape)
                                    )
                                },
                                trailingContent = {
                                    Row(horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                                        androidx.compose.material3.IconButton(onClick = {
                                            viewModel.setDmPeer(node.id)
                                            showRosterDialog = false
                                        }) {
                                            androidx.compose.material3.Icon(
                                                androidx.compose.material.icons.Icons.Default.Lock,
                                                contentDescription = "Direct Message",
                                                tint = Color(0xFF53BDEB)
                                            )
                                        }

                                        androidx.compose.material3.IconButton(onClick = {
                                            com.example.CallManager.initiateCall(node.id, displayName) { payload ->
                                                com.example.MeshNetworkManager.meshRouter.routeLocalMessage(payload)
                                                com.example.MeshNetworkManager.webServerManager?.broadcastMessage(payload, com.example.MeshNetworkManager.localNodeId)
                                            }
                                        }) {
                                            androidx.compose.material3.Icon(
                                                androidx.compose.material.icons.Icons.Default.Call,
                                                contentDescription = "Voice Call",
                                                tint = androidx.compose.ui.graphics.Color(0xFF25D366)
                                            )
                                        }

                                        if (uiState.isHotspotActive) {
                                            androidx.compose.material3.TextButton(onClick = {
                                                viewModel.kickUser(node.id)
                                                android.widget.Toast.makeText(context, "${node.name} kicked", android.widget.Toast.LENGTH_SHORT).show()
                                            }) {
                                                Text("Kick", color = MaterialTheme.colorScheme.error)
                                            }
                                            androidx.compose.material3.TextButton(onClick = {
                                                viewModel.banUser(node.id)
                                                android.widget.Toast.makeText(context, "${node.name} banned", android.widget.Toast.LENGTH_SHORT).show()
                                            }) {
                                                Text("Ban", color = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { showRosterDialog = false }) { Text("Close") }
                }
            )
        }

        if (showPanicWipeConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showPanicWipeConfirmDialog = false },
                title = { Text("🚨 Emergency Panic Wipe", fontWeight = FontWeight.Bold, color = Color(0xFFEA4335)) },
                text = { Text("This will permanently destroy all local Room message history, call records, transferred media files, and cryptographic keys from this device with zero trace. This cannot be undone.") },
                confirmButton = {
                    Button(
                        onClick = {
                            showPanicWipeConfirmDialog = false
                            viewModel.emergencyPanicWipe(context)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA4335))
                    ) {
                        Text("ERASE & PURGE ALL")
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { showPanicWipeConfirmDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        if (showNoPeersDialog) {
            AlertDialog(
                onDismissRequest = { showNoPeersDialog = false },
                title = { Text("No Nearby Peers Connected") },
                text = { Text("To make an HD WhatsApp voice call, connect another phone using the Share / Hotspot icon, or scan for nearby Wi-Fi Direct mesh nodes.") },
                confirmButton = {
                    Button(onClick = { showNoPeersDialog = false }) {
                        Text("Got It")
                    }
                }
            )
        }

        if (showCallPickerSheet) {
            AlertDialog(
                onDismissRequest = { showCallPickerSheet = false },
                title = { Text("Select Contact to Call", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        uiState.connectedNodes.forEach { node ->
                            val displayName = uiState.knownUsers[node.id] ?: node.name
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showCallPickerSheet = false
                                        val peerIp = if (uiState.isHotspotActive) "192.168.49.1" else ""
                                        CallManager.initiateCall(node.id, displayName, peerIp) { payload ->
                                            com.example.MeshNetworkManager.meshRouter.routeLocalMessage(payload)
                                            com.example.MeshNetworkManager.webServerManager?.broadcastMessage(payload, com.example.MeshNetworkManager.localNodeId)
                                        }
                                    }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFF25D366).copy(alpha = 0.2f), androidx.compose.foundation.shape.CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(displayName.take(1).uppercase(), color = Color(0xFF25D366), fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(displayName, fontWeight = FontWeight.SemiBold)
                                    Text("Online via Wi-Fi Mesh", fontSize = 12.sp, color = Color(0xFF8696A0))
                                }
                                Icon(if (callPickerIsVideo) Icons.Default.Videocam else Icons.Default.Call, contentDescription = null, tint = Color(0xFF25D366))
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showCallPickerSheet = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Contact Action Dialog when tapping a user header on any message
        if (selectedUser != null) {
            val userMsg = selectedUser!!
            val userHandle = uiState.knownUserIds[userMsg.senderId] ?: userMsg.senderHandle.ifBlank { "@${userMsg.senderName.lowercase().replace(" ", "")}" }
            AlertDialog(
                onDismissRequest = { selectedUser = null },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(WhatsAppOutgoingDark, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                userMsg.senderName.take(1).uppercase(),
                                color = WhatsAppGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(userMsg.senderName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(userHandle, fontSize = 12.sp, color = Color(0xFF53BDEB))
                        }
                    }
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "Mesh Peer ID: ${userMsg.senderId.take(12)}...",
                            style = MaterialTheme.typography.labelSmall,
                            color = WhatsAppSubtleText
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val peerId = userMsg.senderId
                                    selectedUser = null
                                    viewModel.setDmPeer(peerId)
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = "Direct Chat", tint = Color(0xFF53BDEB))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Direct Chat (1-on-1 Mesh DM)", fontWeight = FontWeight.Medium)
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val peerId = userMsg.senderId
                                    val name = userMsg.senderName
                                    selectedUser = null
                                    CallManager.initiateCall(peerId, name) { payload ->
                                        com.example.MeshNetworkManager.meshRouter.routeLocalMessage(payload)
                                        com.example.MeshNetworkManager.webServerManager?.broadcastMessage(payload, com.example.MeshNetworkManager.localNodeId)
                                    }
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "Voice Call", tint = WhatsAppGreen)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Voice Call (Local HD Mesh Audio)", fontWeight = FontWeight.Medium)
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val peerId = userMsg.senderId
                                    val name = userMsg.senderName
                                    selectedUser = null
                                    CallManager.initiateCall(peerId, name) { payload ->
                                        com.example.MeshNetworkManager.meshRouter.routeLocalMessage(payload)
                                        com.example.MeshNetworkManager.webServerManager?.broadcastMessage(payload, com.example.MeshNetworkManager.localNodeId)
                                    }
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = WhatsAppGreen)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Video Call (Direct P2P Stream)", fontWeight = FontWeight.Medium)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { selectedUser = null }) {
                        Text("Close")
                    }
                }
            )
        }
        
        // --- Dialogs (Hotspot, Diagnostics, etc) ---
        if (showHotspotDialog) {
            androidx.compose.ui.window.Dialog(
                onDismissRequest = { showHotspotDialog = false },
                properties = androidx.compose.ui.window.DialogProperties(
                    usePlatformDefaultWidth = false,
                    dismissOnBackPress = true,
                    dismissOnClickOutside = false
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { showHotspotDialog = false }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                            Text("2 QR Codes • WebChat & Mesh Wi-Fi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { 
                                viewModel.toggleHotspot() 
                                showHotspotDialog = false
                            }) {
                                Icon(Icons.Default.Close, contentDescription = "Stop Server", tint = Color.Red)
                            }
                        }
                        
                        Spacer(Modifier.height(24.dp))
                        
                        if (uiState.isHotspotActive) {
                            Text("QR Code 1: Join Mesh Wi-Fi", style = MaterialTheme.typography.titleMedium, color = WhatsAppGreen, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text("SSID: ${uiState.hotspotSsid}", fontWeight = FontWeight.Bold)
                            Text("Password: ${uiState.hotspotPassword}")
                            Spacer(Modifier.height(14.dp))
                            
                            // Wi-Fi QR
                            val wifiQr = "WIFI:T:WPA;S:${uiState.hotspotSsid};P:${uiState.hotspotPassword};;"
                            com.example.QRCodeImage(content = wifiQr, modifier = Modifier.size(200.dp).background(Color.White).padding(8.dp))
                            
                            Spacer(Modifier.height(14.dp))
                            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                val context = LocalContext.current
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                OutlinedButton(onClick = {
                                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("SSID", uiState.hotspotSsid))
                                    android.widget.Toast.makeText(context, "SSID Copied", android.widget.Toast.LENGTH_SHORT).show()
                                }) { Text("Copy SSID") }
                                OutlinedButton(onClick = {
                                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Password", uiState.hotspotPassword))
                                    android.widget.Toast.makeText(context, "Password Copied", android.widget.Toast.LENGTH_SHORT).show()
                                }) { Text("Copy Pwd") }
                            }
                            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                Button(onClick = {
                                    viewModel.pulseBleChunk("S:" + uiState.hotspotSsid)
                                }) { Text("Pulse SSID (BLE)") }
                                Button(onClick = {
                                    viewModel.pulseBleChunk("P:" + uiState.hotspotPassword)
                                }) { Text("Pulse Pwd (BLE)") }
                            }
                            Spacer(Modifier.height(28.dp))
                        }
                        
                        Text("QR Code 2: Open WebChat in Browser", style = MaterialTheme.typography.titleMedium, color = WhatsAppGreen, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        
                        if (uiState.hotspotIp.isNotEmpty()) {
                            val url = "http://${uiState.hotspotIp}:8080"
                            Text("Tell users to connect and visit:", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("http://nexus.run", fontWeight = FontWeight.Bold, color = WhatsAppGreen, style = MaterialTheme.typography.titleMedium)
                            Text("or $url", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(14.dp))
                            
                            // URL QR
                            com.example.QRCodeImage(content = url, modifier = Modifier.size(200.dp).background(Color.White).padding(8.dp))
                        } else {
                            Text("Waiting for IP address...")
                            Spacer(Modifier.height(16.dp))
                            CircularProgressIndicator(color = WhatsAppGreen)
                        }
                        
                        Spacer(Modifier.height(32.dp))
                        Text("Or share this app with other Android devices directly.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { viewModel.shareAppApk(context) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Share, contentDescription = "Share APK")
                            Spacer(Modifier.width(8.dp))
                            Text("Share APK (Bluetooth/Nearby)")
                        }
                    }
                }
            }
        }
        if (showDiagnosticsDialog) {
            AlertDialog(
                onDismissRequest = { showDiagnosticsDialog = false },
                title = { Text("Diagnostic Logs") },
                text = {
                    val logs = com.example.DiagnosticLogger.events.collectAsState().value
                    androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.heightIn(max = 400.dp).fillMaxWidth()) {
                        items(count = logs.size) { i ->
                            val log = logs[i]
                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                Text("[${log.timestamp}] ${log.component} - ${log.action}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(log.detail, fontSize = 12.sp)
                                HorizontalDivider()
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showDiagnosticsDialog = false }) { Text("Close") } }
            )
        }

        if (showSOSConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showSOSConfirmDialog = false },
                icon = {
                    Icon(
                        Icons.Default.Warning,
                        contentDescription = "SOS Warning",
                        tint = Color(0xFFFF5252),
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        if (uiState.isEmergencyMode) "Active SOS Beacon" else "Broadcast SOS Beacon",
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column {
                        if (uiState.isEmergencyMode) {
                            Text(
                                "Your Emergency Beacon is currently broadcasting coordinates and distress signal to all nearby mesh peers.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            Text(
                                "This sends an immediate high-priority distress broadcast with your peer ID and coordinates to all discovered Wi-Fi & BLE mesh nodes in range.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            androidx.compose.material3.OutlinedTextField(
                                value = sosCustomReasonInput,
                                onValueChange = { sosCustomReasonInput = it },
                                label = { Text("Emergency Note (optional)") },
                                placeholder = { Text("e.g. Need medical assistance / lost") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                },
                confirmButton = {
                    if (uiState.isEmergencyMode) {
                        Button(
                            onClick = {
                                viewModel.cancelSOS()
                                showSOSConfirmDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                        ) {
                            Text("Cancel / Stand Down", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = {
                                val reason = if (sosCustomReasonInput.isNotBlank()) sosCustomReasonInput.trim() else "Immediate Assistance Required!"
                                viewModel.triggerSOS(customMessage = reason)
                                showSOSConfirmDialog = false
                                sosCustomReasonInput = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                        ) {
                            Text("BROADCAST SOS", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showSOSConfirmDialog = false }) {
                        Text("Dismiss")
                    }
                }
            )
        }
    }
}

@Composable
fun ChatTab(uiState: MeshState, viewModel: MeshViewModel, onUserClick: (ChatMessage) -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var fullScreenImageUrl by remember { mutableStateOf<String?>(null) }
    
    var isRecording by remember { mutableStateOf(false) }
    val audioRecorder = remember { com.example.AudioRecorderHelper(context) }
    
    val recordPermissionLauncher = rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            isRecording = true
            audioRecorder.startRecording()
        } else {
            android.widget.Toast.makeText(context, "Microphone permission required", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    
    var privateRoomInput by remember { mutableStateOf("") }
    
    val photoPicker = rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { viewModel.shareFile(it) }
    }

    if (fullScreenImageUrl != null) {
        val currentImageUrl = fullScreenImageUrl!!
        val localFile = remember(currentImageUrl) { com.example.MeshStorageManager.findLocalFile(context, currentImageUrl) }
        val displayModel: Any = localFile ?: currentImageUrl
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { fullScreenImageUrl = null },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
                coil.compose.AsyncImage(
                    model = displayModel,
                    contentDescription = "Full Screen Image",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit
                )
                // Top control bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(Color.Black.copy(alpha = 0.6f))
                        .padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { fullScreenImageUrl = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = currentImageUrl.substringAfterLast("/").ifEmpty { "Mesh Photo" },
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            viewModel.saveImageToGallery(context, currentImageUrl)
                        }
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Save to Gallery", tint = WhatsAppGreen)
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WhatsAppChatBackgroundDark)
    ) {
        if (uiState.discoveredHostSsid != null && !uiState.isHotspotActive && !uiState.isWifiConnected) {
            val context = androidx.compose.ui.platform.LocalContext.current
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.padding(16.dp).fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Wifi, contentDescription = "Wi-Fi")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("High-Speed Mesh Found!", fontWeight = FontWeight.Bold)
                    }
                    if (uiState.discoveredHostPwd == "PRIVATE") {
                        Text("Host: ${uiState.discoveredHostSsid}\nPassword: [Private Room]", modifier = Modifier.padding(top = 4.dp), color = MaterialTheme.colorScheme.error)
                        androidx.compose.material3.OutlinedTextField(
                            value = privateRoomInput,
                            onValueChange = { privateRoomInput = it },
                            label = { Text("Enter Room Password") },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        )
                        Row(modifier = Modifier.padding(top = 12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    if (privateRoomInput.isNotBlank()) {
                                        viewModel.connectToDiscoveredHotspot(passwordOverride = privateRoomInput)
                                        android.widget.Toast.makeText(context, "Requesting connection...", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                enabled = privateRoomInput.isNotBlank()
                            ) {
                                Text("Connect")
                            }
                        }
                    } else {
                        Text("Host: ${uiState.discoveredHostSsid}\nPassword: ${uiState.discoveredHostPwd}", modifier = Modifier.padding(top = 4.dp))
                        
                        Row(modifier = Modifier.padding(top = 12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                viewModel.connectToDiscoveredHotspot()
                                android.widget.Toast.makeText(context, "Requesting connection...", android.widget.Toast.LENGTH_SHORT).show()
                            }, modifier = Modifier.weight(1f)) {
                                Text("Auto-Connect")
                            }
                            
                            OutlinedButton(onClick = {
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                val clip = android.content.ClipData.newPlainText("Wi-Fi Password", uiState.discoveredHostPwd)
                                clipboard.setPrimaryClip(clip)
                                android.widget.Toast.makeText(context, "Password copied! Select ${uiState.discoveredHostSsid} in settings.", android.widget.Toast.LENGTH_LONG).show()
                                
                                val intent = android.content.Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)
                                context.startActivity(intent)
                            }, modifier = Modifier.weight(1f)) {
                                Text("Copy Password")
                            }
                        }
                    }
                }
            }
        }
        
        if (uiState.hotspotError != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.padding(16.dp).fillMaxWidth()
            ) {
                Text(uiState.hotspotError, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(16.dp))
            }
        }
        
        // Emergency SOS Broadcast Beacon Alert Banner
        if (uiState.activeSOSAlert != null) {
            val alert = uiState.activeSOSAlert!!
            Card(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFB71C1C))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = "Emergency Alert",
                                tint = Color.Yellow,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                "🚨 EMERGENCY SOS BEACON",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp
                            )
                        }
                        IconButton(
                            onClick = { viewModel.dismissSOSAlert() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss Alert", tint = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "From: ${alert.senderName} (${alert.senderHandle.ifBlank { "@peer" }})",
                        color = Color.Yellow,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        alert.message,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    if (alert.lat != null && alert.lng != null) {
                        Text(
                            "📍 Location: %.5f, %.5f".format(alert.lat, alert.lng),
                            color = Color(0xFFFFD54F),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = {
                                viewModel.setDmPeer(alert.senderId)
                            }
                        ) {
                            Text("Direct Reply", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                CallManager.initiateCall(alert.senderId, alert.senderName) { payload ->
                                    com.example.MeshNetworkManager.meshRouter.routeLocalMessage(payload)
                                    com.example.MeshNetworkManager.webServerManager?.broadcastMessage(payload, com.example.MeshNetworkManager.localNodeId)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFFB71C1C))
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Call Node", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Active 1-on-1 DM Top Header Pill
        if (uiState.activeDmPeerId != null) {
            val dmPeerId = uiState.activeDmPeerId!!
            val peerName = uiState.knownUsers[dmPeerId] ?: "Peer_${dmPeerId.take(5)}"
            val peerHandle = uiState.knownUserIds[dmPeerId] ?: "@${peerName.lowercase().replace(" ", "")}"

            Surface(
                color = Color(0xFF102A38),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = null,
                            tint = WhatsAppCheckmarkBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                "Direct Chat with $peerName",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                "$peerHandle • Only visible to both of you",
                                color = WhatsAppCheckmarkBlue,
                                fontSize = 11.sp
                            )
                        }
                    }
                    TextButton(onClick = { viewModel.clearDmPeer() }) {
                        Text("Exit DM", color = Color(0xFFE9EDEF), fontSize = 12.sp)
                    }
                }
            }
        }

        // Active SOS Beacon Local Sender Banner
        if (uiState.isEmergencyMode) {
            Card(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFD32F2F))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Yellow)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Broadcasting Emergency SOS Beacon", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Pinging all nearby mesh nodes", color = Color(0xFFFFCDD2), fontSize = 11.sp)
                        }
                    }
                    Button(
                        onClick = { viewModel.cancelSOS() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Red)
                    ) {
                        Text("Cancel SOS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Active Game Banner in Chat
        if (uiState.chessState.whitePlayerId.isNotEmpty()) {
            Card(
                modifier = Modifier.padding(16.dp).fillMaxWidth().clickable {
                    // Quick jump back to active game
                    if (uiState.chessState.whitePlayerId.isNotEmpty()) {
                        viewModel.setSharedMedia("chess", "", "game", 2)
                    }
                },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Active Game", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Game in progress! Tap to join.", color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                }
            }
        }

        
        // Burner Room Banner
        if (uiState.isBurnerRoomActive) {
            Card(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = "Burner Room", tint = MaterialTheme.colorScheme.onErrorContainer)
                            Spacer(modifier = Modifier.width(16.dp))
                            Text("🔥 BURNER ROOM ACTIVE", color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold)
                        }
                        Text("${uiState.burnerRoomCountdown}s", color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Participants: ${uiState.activeBurnerKeys.joinToString(", ")}", color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { viewModel.leaveBurnerRoom() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = MaterialTheme.colorScheme.onError)) {
                        Text("LEAVE & DESTROY")
                    }
                }
            }
        }
        
        LazyColumn(
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            reverseLayout = true
        ) {
            if (uiState.activePoll != null) {
                item {
                    com.example.ui.screens.PollOverlay(
                        poll = uiState.activePoll!!,
                        onVote = { viewModel.votePoll(uiState.activePoll!!.id, it) },
                        onClose = { viewModel.closePoll() }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
            val chronList = if (uiState.activeDmPeerId != null) {
                val peerId = uiState.activeDmPeerId!!
                val myId = com.example.MeshNetworkManager.localNodeId
                uiState.messages.filter { msg ->
                    // Show in DM thread if it's an exchange between me and peer
                    (msg.senderId == peerId && (msg.recipientId == myId || msg.recipientId == null)) ||
                    (msg.isFromMe && msg.recipientId == peerId)
                }
            } else {
                // Public room: show broadcast messages (messages without a private recipient or system messages)
                uiState.messages.filter { msg ->
                    msg.recipientId == null || msg.isEmergency
                }
            }
            if (chronList.isNotEmpty()) {
                item {
                    val pillLabel = if (uiState.activeDmPeerId != null) "🔒 Private 1-on-1 Direct Chat" else "Mesh Chat Room • End-to-End Local"
                    WhatsAppDatePill(pillLabel)
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
            items(
                items = chronList.reversed(),
                key = { msg -> "${msg.senderId}_${msg.timestamp}_${msg.id}" }
            ) { msg ->
                val chronIndex = chronList.indexOfFirst { it.id == msg.id }
                val prevMsg = if (chronIndex > 0) chronList[chronIndex - 1] else null
                val nextMsg = if (chronIndex != -1 && chronIndex < chronList.lastIndex) chronList[chronIndex + 1] else null

                val isSystem = msg.senderName == "System" || msg.senderId == "System"
                val isFirstInThread = if (isSystem) true else {
                    prevMsg == null || prevMsg.senderId != msg.senderId || prevMsg.senderName == "System" ||
                        (msg.timestamp - prevMsg.timestamp > 120_000L)
                }
                val isLastInThread = if (isSystem) true else {
                    nextMsg == null || nextMsg.senderId != msg.senderId || nextMsg.senderName == "System" ||
                        (nextMsg.timestamp - msg.timestamp > 120_000L)
                }

                val isMentioned = msg.message.contains("@${uiState.localUserName}", ignoreCase = true) || 
                    (uiState.localUsernameId.isNotBlank() && msg.message.contains(uiState.localUsernameId, ignoreCase = true))
                ChatBubble(
                    message = msg,
                    knownUserIds = uiState.knownUserIds,
                    isMentioned = isMentioned,
                    isFirstInThread = isFirstInThread,
                    isLastInThread = isLastInThread,
                    onUserClick = { onUserClick(msg) },
                    onSaveFile = { url -> viewModel.saveFileToDevice(context, url) },
                    onSaveImage = { url -> viewModel.saveImageToGallery(context, url) },
                    onOpenUrl = { url -> 
                        if (url.startsWith("meshgame://")) {
                            val game = url.removePrefix("meshgame://")
                            viewModel.setSharedMedia(game, "", "game", 2)
                        } else {
                            val isImage = com.example.MeshStorageManager.isImageFile(url)
                            if (isImage) {
                                fullScreenImageUrl = url
                            } else {
                                viewModel.downloadAndOpenFile(context, url)
                            }
                        }
                    }
                )
                if (isLastInThread) {
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
        }
        var text by remember { mutableStateOf("") }
        val fileLauncher = rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
            uri?.let { viewModel.shareFile(it) }
        }

        ChatInput(
            text = text,
            onTextChange = { text = it },
            onSendMessage = { msg ->
                viewModel.sendMessage(
                    text = msg,
                    recipientId = uiState.activeDmPeerId
                )
                text = ""
            },
            onFilePick = { fileLauncher.launch("*/*") },
            onCameraClick = {
                photoPicker.launch(
                    androidx.activity.result.PickVisualMediaRequest(
                        androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly
                    )
                )
            },
            onMicClick = {
                if (isRecording) {
                    isRecording = false
                    val file = audioRecorder.stopRecording()
                    if (file != null && file.exists()) {
                        try {
                            val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            viewModel.shareFile(uri)
                        } catch (e: Exception) {
                            android.util.Log.e("AudioRecorder", "Failed to get URI", e)
                            android.widget.Toast.makeText(context, "Failed to attach audio", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        isRecording = true
                        audioRecorder.startRecording()
                    } else {
                        recordPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                    }
                }
            },
            isRecording = isRecording
        )
    }
}

@Composable
fun ArcadeTab(uiState: MeshState, viewModel: MeshViewModel) {
    var showPollBuilder by remember { mutableStateOf(false) }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Local Arcade", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground)

        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth().clickable { viewModel.setSharedMedia("canvas", "", "collaborative", 0) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🖌️", style = MaterialTheme.typography.displaySmall)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Canvas (Collaborative)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Everyone can draw together", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth().clickable { viewModel.setSharedMedia("canvas", "", "broadcast", 0) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("👩‍🏫", style = MaterialTheme.typography.displaySmall)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Canvas (View-Only)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Only you can draw, others watch", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Card(modifier = Modifier.fillMaxWidth().clickable { 
            showPollBuilder = true 
             
        }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("📊", style = MaterialTheme.typography.displaySmall)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Live Poll", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Ask a question and see live answers", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
                Spacer(modifier = Modifier.height(16.dp))
        Card(modifier = Modifier.fillMaxWidth().clickable { 
            viewModel.rollRandomizer()
        }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🎲", style = MaterialTheme.typography.displaySmall)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Truth or Dare", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Roll a random challenge for the room", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        if (showPollBuilder) {
        com.example.ui.screens.PollBuilderDialog(
            onDismiss = { showPollBuilder = false },
            onStartPoll = { q, opts, uri -> 
                viewModel.startPoll(q, opts, uri)
                showPollBuilder = false
            }
        )
    }
    
    Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth().clickable { 
            val ip = if (uiState.hotspotIp.isNotEmpty()) uiState.hotspotIp else "127.0.0.1"
            viewModel.updateLocalSharedMedia("web", "http://$ip:8080/tictactoe", com.example.MeshNetworkManager.localNodeId, "local", 0, true)
        }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("⭕", style = MaterialTheme.typography.displaySmall)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Tic-Tac-Toe (vs AI)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Single-player strategy game", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth().clickable { 
            val ip = if (uiState.hotspotIp.isNotEmpty()) uiState.hotspotIp else "127.0.0.1"
            viewModel.updateLocalSharedMedia("web", "http://$ip:8080/chess", com.example.MeshNetworkManager.localNodeId, "local", 0, true)
        }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("♟️", style = MaterialTheme.typography.displaySmall)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Chess (In-Browser)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Offline browser chess directly on Ktor", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth().clickable { 
            val ip = if (uiState.hotspotIp.isNotEmpty()) uiState.hotspotIp else "127.0.0.1"
            viewModel.updateLocalSharedMedia("web", "http://$ip:8080/snake", com.example.MeshNetworkManager.localNodeId, "local", 0, true)
        }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🐍", style = MaterialTheme.typography.displaySmall)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Snake Classic", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Single-player arcade game", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

    Text("Pocket CDN (Offline Web Apps)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 8.dp))
        
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("💻", style = MaterialTheme.typography.displaySmall)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("Offline Web IDE", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("HTML/JS/CSS Editor with Live Preview.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    androidx.compose.material3.Button(onClick = { 
                        val ip = if (uiState.hotspotIp.isNotEmpty()) uiState.hotspotIp else "127.0.0.1"
                        viewModel.updateLocalSharedMedia("web", "http://$ip:8080/ide", com.example.MeshNetworkManager.localNodeId, "local", 0, true) 
                    }) { Text("Build (Local)") }
                    
                    androidx.compose.material3.Button(onClick = { 
                        val ip = if (uiState.hotspotIp.isNotEmpty()) uiState.hotspotIp else "127.0.0.1"
                        viewModel.sendMessage("I built a new web tool! Check it out: http://$ip:8080/ide")
                    }) { Text("Distribute (Link)") }
                    
                    androidx.compose.material3.Button(onClick = { 
                        val ip = if (uiState.hotspotIp.isNotEmpty()) uiState.hotspotIp else "127.0.0.1"
                        viewModel.setSharedMedia("web", "http://$ip:8080/ide", "collaborative", 0) 
                    }) { Text("Live Session") }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth().clickable { 
            val ip = if (uiState.hotspotIp.isNotEmpty()) uiState.hotspotIp else "127.0.0.1"
            viewModel.setSharedMedia("web", "http://$ip:8080/pool", "game", 2) 
        }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🎱", style = MaterialTheme.typography.displaySmall)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Pool (Billiards)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Multiplayer custom pool game.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("❌", style = MaterialTheme.typography.displaySmall)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Tic-Tac-Toe", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Classic 2-player mesh match.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.setSharedMedia("tictactoe", "", "game", 2) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Play Now")
                    }
                    OutlinedButton(
                        onClick = { 
                            viewModel.sendMessage("🎮 [GAME CHALLENGE]: Tic-Tac-Toe! Tap to play with me.")
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Challenge Chat")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🔴", style = MaterialTheme.typography.displaySmall)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Connect 4", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Classic grid strategy game.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.setSharedMedia("connect4", "", "game", 2) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Play Now")
                    }
                    OutlinedButton(
                        onClick = { 
                            viewModel.sendMessage("🎮 [GAME CHALLENGE]: Connect 4! Tap to play with me.")
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Challenge Chat")
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("♟️", style = MaterialTheme.typography.displaySmall)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Standard Chess", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Classic rules, true local multiplayer.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.setSharedMedia("chess", "", "game", 2) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Play Now")
                    }
                    OutlinedButton(
                        onClick = { 
                            viewModel.sendMessage("🎮 [GAME CHALLENGE]: Chess! Tap to play with me.")
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Challenge Chat")
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth().clickable { viewModel.setSharedMedia("ludo", "", "game", 4) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🎲", style = MaterialTheme.typography.displaySmall)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Mesh Ludo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("4-player local network Ludo.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        } }

@Composable
fun RadarScreen(viewModel: MeshViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var isEcoMode by remember { mutableStateOf(false) }

    // On-demand hardware lifecycle: start location tracking ONLY while RadarScreen is displayed
    // and stop immediately upon exiting to preserve 100% idle battery.
    DisposableEffect(isEcoMode) {
        viewModel.startLocationTracking(context, ecoMode = isEcoMode)
        viewModel.pingRadarLocation()
        onDispose {
            viewModel.stopLocationTracking()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        com.example.RadarView(
            userLocations = uiState.userLocations,
            myId = MeshNetworkManager.localNodeId,
            knownUserNames = uiState.knownUsers,
            isEcoMode = isEcoMode,
            onToggleEco = { newEco -> isEcoMode = newEco },
            onRefreshLocation = { viewModel.pingRadarLocation() },
            onNodeAction = { nodeId, nodeName, action ->
                if (action == "call") {
                    val peerIp = if (uiState.isHotspotActive) "192.168.49.1" else ""
                    com.example.CallManager.initiateCall(nodeId, nodeName, peerIp) { payload ->
                        com.example.MeshNetworkManager.meshRouter.routeLocalMessage(payload)
                        com.example.MeshNetworkManager.webServerManager?.broadcastMessage(payload, com.example.MeshNetworkManager.localNodeId)
                    }
                } else if (action == "chat") {
                    viewModel.sendMessage("@$nodeName ")
                }
            }
        )
    }
}


