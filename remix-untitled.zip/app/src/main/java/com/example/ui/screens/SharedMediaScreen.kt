package com.example.ui.screens

import androidx.compose.ui.unit.dp
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.SslErrorHandler
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebSettings
import android.net.http.SslError
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass

@Composable
fun SharedMediaScreen(
    uiState: com.example.MeshState,
    modifier: Modifier = Modifier
) {
    val mediaType = uiState.sharedMediaType
    val viewModel: com.example.MeshViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val mediaUrl = uiState.sharedMediaUrl
    val mediaMode = uiState.mediaMode
    val mediaHostId = uiState.mediaHostId
    val isHost = com.example.MeshNetworkManager.localNodeId == mediaHostId
    val isBroadcastOnly = mediaMode == "broadcast" && !isHost
    val activePlayers = uiState.activePlayers
    val maxSeats = uiState.maxSeats
    val hasSeat = activePlayers.contains(com.example.MeshNetworkManager.localNodeId)

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            if (isHost && mediaType != "none") {
                Button(onClick = { viewModel.setSharedMedia("none") }, modifier = Modifier.fillMaxWidth().padding(8.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text("Stop Sharing & Clear Board")
                }
            }
            Box(modifier = Modifier.weight(1f)) {
        if (mediaType == "web") {
            AndroidView(
                factory = { context ->
                    WebView(context).apply {
                        layoutParams = android.view.ViewGroup.LayoutParams(
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.setSupportZoom(true)
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        webViewClient = WebViewClient()
                        webChromeClient = android.webkit.WebChromeClient()
                        
                        val base = if (mediaUrl.startsWith("http")) mediaUrl else "https://$mediaUrl"
                        val fullUrl = if (base.contains("sim/physics")) base + "?isHost=$isHost" else base
                        loadUrl(fullUrl)
                    }
                },
                update = { webView ->
                    val currentUrl = webView.url
                    val base = if (mediaUrl.startsWith("http")) mediaUrl else "https://$mediaUrl"
                    val targetUrl = if (base.contains("sim/physics")) base + "?isHost=$isHost" else base
                    if (currentUrl != targetUrl && mediaUrl.isNotBlank()) {
                        webView.loadUrl(targetUrl)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else if (mediaType == "tictactoe") {
            val viewModel: com.example.MeshViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
            val uiState by viewModel.uiState.collectAsState()
            com.example.ui.screens.TicTacToeScreen(
                state = uiState.ticTacToeState,
                onStateChange = { newState -> viewModel.broadcastTicTacToeState(newState) },
                modifier = Modifier.fillMaxSize()
            )
        } else if (mediaType == "connect4") {
            val viewModel: com.example.MeshViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
            val uiState by viewModel.uiState.collectAsState()
            com.example.ui.screens.Connect4Screen(
                state = uiState.connect4State,
                onStateChange = { newState -> viewModel.broadcastConnect4State(newState) },
                modifier = Modifier.fillMaxSize()
            )
        } else if (mediaType == "ludo") {
            val viewModel: com.example.MeshViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
            val uiState by viewModel.uiState.collectAsState()
            LudoScreen(
                state = uiState.ludoState,
                onStateChange = { newState -> viewModel.broadcastLudoState(newState) },
                modifier = Modifier.fillMaxSize()
            )
        } else if (mediaType == "chess") {
            val viewModel: com.example.MeshViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
            val uiState by viewModel.uiState.collectAsState()
            ChessScreen(
                state = uiState.chessState,
                onStateChange = { newState -> viewModel.broadcastChessState(newState) },
                modifier = Modifier.fillMaxSize()
            )
        }
         else if (mediaType == "canvas") {
            val viewModel: com.example.MeshViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
            val uiState by viewModel.uiState.collectAsState()
            val context = androidx.compose.ui.platform.LocalContext.current
            com.example.ui.screens.CanvasScreen(
                canvasPaths = uiState.canvasPaths,
                lasers = uiState.lasers,
                backgroundUrl = uiState.canvasBackground,
                onSendCanvasMessage = { action, id, color, x, y, strokeWidth, data -> 
                    viewModel.sendCanvasMessage(action, id, color, x, y, strokeWidth, data) 
                },
                onUploadBackground = { uri -> viewModel.uploadCanvasBackground(uri) },
                onSaveCanvas = { viewModel.saveCanvasToGallery(context) },
                modifier = Modifier.fillMaxSize()
            )
        }
        } // End of inner Box

        if (isBroadcastOnly) {
            Box(modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        event.changes.forEach { it.consume() }
                    }
                }
            })
        }
        } // End of Column
    } // End of outer Box
} // End of SharedMediaScreen