package com.example.ui.screens
import androidx.compose.ui.draw.clipToBounds

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Edit
import androidx.compose.ui.text.font.FontWeight
import com.example.DrawPath
import java.util.UUID
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.mutableStateListOf


@Composable
fun CanvasScreen(
    canvasPaths: List<DrawPath>,
    lasers: Map<String, Offset>,
    backgroundUrl: String = "",
    onSendCanvasMessage: (action: String, id: String, color: String, x: Float, y: Float, strokeWidth: Float, data: String) -> Unit,
    onUploadBackground: (android.net.Uri) -> Unit = {},
    onSaveCanvas: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    val localPaths = remember { mutableStateListOf<DrawPath>() }
    val bgLauncher = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        uri?.let { onUploadBackground(it) }
    }
    
    var currentPathId by remember { mutableStateOf("") }
    var currentColor by remember { mutableStateOf("#000000") }
    var currentStrokeWidth by remember { mutableFloatStateOf(10f) }
    var isPadMode by remember { mutableStateOf(false) }
    var isLaserMode by remember { mutableStateOf(false) }
    var lastSentOffset by remember { mutableStateOf(Offset.Zero) }
    
    val dragLogic: suspend PointerInputScope.() -> Unit = {
        val canvasSize = size
        detectDragGestures(
            onDragStart = { offset ->
                currentPathId = "android-${UUID.randomUUID().toString().take(8)}"
                lastSentOffset = offset
                if (isLaserMode) {
                    onSendCanvasMessage("laser", "", currentColor, offset.x / canvasSize.width, offset.y / canvasSize.height, 10f, "")
                } else {
                    onSendCanvasMessage("start", currentPathId, currentColor, offset.x / canvasSize.width, offset.y / canvasSize.height, currentStrokeWidth, "")
                }
            },
            onDrag = { change, dragAmount ->
                change.consume()
                val dist = (change.position - lastSentOffset).getDistance()
                if (dist > 5f) {
                    lastSentOffset = change.position
                    if (isLaserMode) {
                        onSendCanvasMessage("laser", "", currentColor, change.position.x / canvasSize.width, change.position.y / canvasSize.height, 10f, "")
                    } else {
                        onSendCanvasMessage("move", currentPathId, currentColor, change.position.x / canvasSize.width, change.position.y / canvasSize.height, currentStrokeWidth, "")
                    }
                }
            },
            onDragEnd = {
                if (!isLaserMode) onSendCanvasMessage("end", currentPathId, currentColor, 0f, 0f, currentStrokeWidth, "")
            },
            onDragCancel = {
                if (!isLaserMode) onSendCanvasMessage("end", currentPathId, currentColor, 0f, 0f, currentStrokeWidth, "")
            }
        )
    }
    
    val drawContent: DrawScope.() -> Unit = {
        canvasPaths.forEach { drawPath ->
            val path = Path()
            if (drawPath.points.isNotEmpty()) {
                path.moveTo(drawPath.points.first().x * size.width, drawPath.points.first().y * size.height)
                for (i in 1 until drawPath.points.size) {
                    path.lineTo(drawPath.points[i].x * size.width, drawPath.points[i].y * size.height)
                }
                drawPath(
                    path = path,
                    color = drawPath.color,
                    style = Stroke(width = drawPath.strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round),
                    blendMode = if (drawPath.isEraser) androidx.compose.ui.graphics.BlendMode.Clear else androidx.compose.ui.graphics.BlendMode.SrcOver
                )
            }
        }
        
        // Draw Lasers
        lasers.values.forEach { offset ->
            drawCircle(
                color = Color.Red,
                radius = 15f,
                center = Offset(offset.x * size.width, offset.y * size.height)
            )
            drawCircle(
                color = Color.Yellow,
                radius = 8f,
                center = Offset(offset.x * size.width, offset.y * size.height)
            )
        }
    }
    
    Box(modifier = modifier.background(Color.White), contentAlignment = Alignment.Center) {
        Box(modifier = Modifier.aspectRatio(1f).fillMaxWidth().clipToBounds().graphicsLayer { alpha = 0.99f }) {
        if (backgroundUrl.isNotBlank()) {
            coil.compose.AsyncImage(
                model = backgroundUrl,
                contentDescription = "Background",
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Fit
            )
        }
        if (isPadMode) {
            Column(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.weight(0.75f).fillMaxWidth(), onDraw = drawContent)
                
                Box(
                    modifier = Modifier
                        .weight(0.25f)
                        .fillMaxWidth()
                        .background(Color(0xFFECEFF1).copy(alpha = 0.8f))
                        .border(2.dp, Color.LightGray)
                        .pointerInput(Unit, dragLogic)
                ) {
                    Text(
                        "TRACKPAD AREA (25%)",
                        color = Color.Gray.copy(alpha = 0.5f),
                        modifier = Modifier.align(Alignment.Center),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            Canvas(modifier = Modifier.fillMaxSize().pointerInput(Unit, dragLogic), onDraw = drawContent)
        }
        
        }
        FloatingActionButton(
            onClick = { isPadMode = !isPadMode },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            containerColor = com.example.ui.theme.PremiumSurface,
            contentColor = com.example.ui.theme.PremiumPrimary
        ) {
            Icon(if (isPadMode) Icons.Default.Fullscreen else Icons.Default.Edit, contentDescription = "Toggle Pad Mode")
        }
        Column(modifier = Modifier.align(Alignment.TopCenter).padding(top = 16.dp)) {
            Row(
                modifier = Modifier
                    .background(com.example.ui.theme.PremiumSurface, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Stroke", style = MaterialTheme.typography.labelSmall, color = Color.White)
                Slider(
                    value = currentStrokeWidth,
                    onValueChange = { currentStrokeWidth = it },
                    valueRange = 2f..50f,
                    modifier = Modifier.width(80.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = com.example.ui.theme.PremiumPrimary,
                        activeTrackColor = com.example.ui.theme.PremiumPrimary,
                        inactiveTrackColor = com.example.ui.theme.PremiumBorder
                    )
                )
                
                Spacer(modifier = Modifier.width(4.dp))
                
                IconButton(onClick = { onSendCanvasMessage("undo", "", "#000000", 0f, 0f, 10f, "") }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Undo", tint = com.example.ui.theme.PremiumPrimary)
                }
                IconButton(onClick = { onSendCanvasMessage("clear", "", "#000000", 0f, 0f, 10f, "") }) {
                    Icon(Icons.Default.Delete, contentDescription = "Clear", tint = Color(0xFFEF5350))
                }
                IconButton(onClick = { bgLauncher.launch("image/*") }) {
                    Icon(Icons.Default.Image, contentDescription = "Upload Background", tint = Color(0xFF42A5F5))
                }
                IconButton(onClick = { onSendCanvasMessage("bg", "", "#000000", 0f, 0f, 10f, "") }) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear BG", tint = Color.White)
                }
                IconButton(onClick = { isLaserMode = !isLaserMode }) {
                    Icon(Icons.Default.Album, contentDescription = "Laser Mode", tint = if (isLaserMode) Color.Red else Color.White)
                }
                IconButton(onClick = { onSaveCanvas() }) {
                    Icon(Icons.Default.CheckCircle, contentDescription = "Save Canvas", tint = com.example.ui.theme.PremiumPrimary)
                }

            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .background(com.example.ui.theme.PremiumSurface, RoundedCornerShape(24.dp)).padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val colors = listOf("#FFFFFF", "#263238", "#EF5350", "#4CAF50", "#42A5F5", "#F4D03F", "ERASER")
                colors.forEach { hex ->
                    Box(
                        modifier = Modifier.size(32.dp).clip(CircleShape)
                            .background(if (hex == "ERASER") Color.LightGray else Color(android.graphics.Color.parseColor(hex)))
                            .border(if (currentColor == hex) 3.dp else 0.dp, if (currentColor == hex) com.example.ui.theme.PremiumPrimary else Color.Transparent, CircleShape)
                            .clickable { currentColor = hex },
                        contentAlignment = Alignment.Center
                    ) {
                        if (hex == "ERASER") {
                            Icon(Icons.Default.Clear, contentDescription = "Eraser", modifier = Modifier.size(20.dp), tint = Color.DarkGray)
                        }
                    }
                }
            }
        }
    }
}