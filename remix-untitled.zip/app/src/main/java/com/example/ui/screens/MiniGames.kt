package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MeshNetworkManager
import org.json.JSONObject
import org.json.JSONArray

// TIC-TAC-TOE
@Composable
fun TicTacToeScreen(
    state: com.example.TicTacToeState,
    onStateChange: (com.example.TicTacToeState) -> Unit,
    modifier: Modifier = Modifier
) {
    val myNodeId = MeshNetworkManager.localNodeId
    val isX = state.xPlayerId == myNodeId
    val isO = state.oPlayerId == myNodeId

    Column(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Card(modifier = Modifier.padding(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (state.winner.isNotEmpty()) {
                    Text(if (state.winner == "Draw") "It's a Draw!" else "${state.winner} Wins!", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleLarge)
                    Button(onClick = { onStateChange(com.example.TicTacToeState()) }, modifier = Modifier.padding(top = 8.dp)) { Text("Reset Board") }
                } else {
                    Text(if (state.isXTurn) "X's Turn" else "O's Turn", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    if (state.xPlayerId.isEmpty() && state.oPlayerId != myNodeId) {
                        Button(onClick = { onStateChange(state.copy(xPlayerId = myNodeId)) }) { Text("Play X") }
                        if (state.oPlayerId == myNodeId) Button(onClick = { onStateChange(state.copy(xPlayerId = "bot")) }) { Text("Bot X") }
                    } else if (state.xPlayerId.isEmpty() && state.oPlayerId == myNodeId) {
                        Button(onClick = { onStateChange(state.copy(xPlayerId = "bot")) }) { Text("Add Bot X") }
                    } else {
                        Text(if(isX) "You are X" else "X: Taken", color = if(isX) MaterialTheme.colorScheme.primary else Color.LightGray)
                    }
                    if (state.oPlayerId.isEmpty() && state.xPlayerId != myNodeId) {
                        Button(onClick = { onStateChange(state.copy(oPlayerId = myNodeId)) }) { Text("Play O") }
                    } else if (state.oPlayerId.isEmpty() && state.xPlayerId == myNodeId) {
                        Button(onClick = { onStateChange(state.copy(oPlayerId = "bot")) }) { Text("Add Bot O") }
                    } else {
                        Text(if(isO) "You are O" else "O: Taken", color = if(isO) MaterialTheme.colorScheme.secondary else Color.LightGray)
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        Box(modifier = Modifier.size(300.dp).background(MaterialTheme.colorScheme.onBackground).padding(4.dp)) {
            Column(modifier = Modifier.fillMaxSize()) {
                for (row in 0..2) {
                    Row(modifier = Modifier.weight(1f)) {
                        for (col in 0..2) {
                            val idx = row * 3 + col
                            val cell = state.board[idx]
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .padding(2.dp)
                                    .background(MaterialTheme.colorScheme.surface)
                                    .clickable {
                                        if (state.winner.isNotEmpty() || cell.isNotEmpty()) return@clickable
                                        if (state.isXTurn && isX) {
                                            val newBoard = state.board.toMutableList()
                                            newBoard[idx] = "X"
                                            val nextState = state.copy(board = newBoard, isXTurn = false).checkWinner()
                                            if (!nextState.isXTurn && nextState.oPlayerId == "bot" && nextState.winner.isEmpty()) {
                                                onStateChange(nextState.makeBotMove())
                                            } else {
                                                onStateChange(nextState)
                                            }
                                        } else if (!state.isXTurn && isO) {
                                            val newBoard = state.board.toMutableList()
                                            newBoard[idx] = "O"
                                            val nextState = state.copy(board = newBoard, isXTurn = true).checkWinner()
                                            if (nextState.isXTurn && nextState.xPlayerId == "bot" && nextState.winner.isEmpty()) {
                                                onStateChange(nextState.makeBotMove())
                                            } else {
                                                onStateChange(nextState)
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = cell, 
                                    fontSize = 48.sp, 
                                    color = if (cell == "X") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// CONNECT 4
@Composable
fun Connect4Screen(
    state: com.example.Connect4State,
    onStateChange: (com.example.Connect4State) -> Unit,
    modifier: Modifier = Modifier
) {
    val myNodeId = MeshNetworkManager.localNodeId
    val isRed = state.redPlayerId == myNodeId
    val isYellow = state.yellowPlayerId == myNodeId

    Column(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Card(modifier = Modifier.padding(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (state.winner.isNotEmpty()) {
                    Text(if (state.winner == "Draw") "It's a Draw!" else "${state.winner} Wins!", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleLarge)
                    Button(onClick = { onStateChange(com.example.Connect4State()) }, modifier = Modifier.padding(top = 8.dp)) { Text("Reset Board") }
                } else {
                    Text(if (state.isRedTurn) "Red's Turn" else "Yellow's Turn", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    if (state.redPlayerId.isEmpty() && !isYellow) {
                        Button(onClick = { onStateChange(state.copy(redPlayerId = myNodeId)) }) { Text("Play Red") }
                    } else if (state.redPlayerId.isEmpty() && isYellow) {
                        Button(onClick = { onStateChange(state.copy(redPlayerId = "bot")) }) { Text("Add Bot Red") }
                    } else {
                        Text("Red: Taken", color = if(isRed) MaterialTheme.colorScheme.secondary else Color.LightGray)
                    }
                    if (state.yellowPlayerId.isEmpty() && !isRed) {
                        Button(onClick = { onStateChange(state.copy(yellowPlayerId = myNodeId)) }) { Text("Play Yellow") }
                    } else if (state.yellowPlayerId.isEmpty() && isRed) {
                        Button(onClick = { onStateChange(state.copy(yellowPlayerId = "bot")) }) { Text("Add Bot Yellow") }
                    } else {
                        Text("Yellow: Taken", color = if(isYellow) Color(0xFFFFB300) else Color.LightGray)
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        Box(modifier = Modifier.aspectRatio(7f/6f).fillMaxWidth(0.9f).background(Color(0xFF1565C0)).padding(8.dp)) {
            Row(modifier = Modifier.fillMaxSize()) {
                for (col in 0..6) {
                    Column(modifier = Modifier.weight(1f).clickable {
                        if (state.winner.isNotEmpty()) return@clickable
                        if ((state.isRedTurn && isRed) || (!state.isRedTurn && isYellow)) {
                            // Find lowest empty slot in this column
                            for (row in 5 downTo 0) {
                                if (state.board[row][col] == 0) {
                                    val newBoard = state.board.map { it.toMutableList() }.toMutableList()
                                    newBoard[row][col] = if (state.isRedTurn) 1 else 2
                                    val nextState = state.copy(board = newBoard, isRedTurn = !state.isRedTurn).checkWinner()
                                    if (nextState.winner.isEmpty() && ((nextState.isRedTurn && nextState.redPlayerId == "bot") || (!nextState.isRedTurn && nextState.yellowPlayerId == "bot"))) {
                                        onStateChange(nextState.makeBotMove())
                                    } else {
                                        onStateChange(nextState)
                                    }
                                    break
                                }
                            }
                        }
                    }) {
                        for (row in 0..5) {
                            val cell = state.board[row][col]
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .padding(4.dp)
                                    .background(
                                        color = when(cell) {
                                            1 -> Color.Red
                                            2 -> Color(0xFFFFB300)
                                            else -> MaterialTheme.colorScheme.background
                                        },
                                        shape = CircleShape
                                    )
                            )
                        }
                    }
                }
            }
        }
    }
}
