package com.example

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

object MeshNetworkManager {
    val _uiState = MutableStateFlow(MeshState())
    val uiState: StateFlow<MeshState> = _uiState.asStateFlow()

    val localNodeId = UUID.randomUUID().toString()
    val meshRouter = MeshRouter(localNodeId)
    
    var roomAesKey: javax.crypto.SecretKey? = null
    var myRsaKeyPair: java.security.KeyPair? = null

    fun initializeKeys() {
        if (myRsaKeyPair == null) {
            myRsaKeyPair = CryptoManager.generateRSAKeyPair()
        }
        if (roomAesKey == null) {
            roomAesKey = CryptoManager.generateAESKey()
        }
    }

    @SuppressLint("StaticFieldLeak")
    var webServerManager: WebServerManager? = null
    @SuppressLint("StaticFieldLeak")
    var hotspotManager: HotspotManager? = null
    @SuppressLint("StaticFieldLeak")
    var bleMeshManager: BleMeshManager? = null
    @SuppressLint("StaticFieldLeak")
    var wifiSocketManager: WifiSocketManager? = null
    @SuppressLint("StaticFieldLeak")
    var highSpeedFileTransferManager: HighSpeedFileTransferManager? = null
    
    var isInitialized = false

    fun initialize(context: Context) {
        if (isInitialized) return
        isInitialized = true
        meshRouter.localNodeName = android.os.Build.MODEL

        val appContext = context.applicationContext

        webServerManager = WebServerManager(
            context = appContext,
            onClientConnected = { ip ->
                val state = _uiState.value
                if (!state.approvedSpectators.contains(ip)) {
                    if (!state.pendingSpectators.contains(ip)) {
                        _uiState.value = state.copy(pendingSpectators = state.pendingSpectators + ip)
                    }
                }
            },
            isApproved = { ip -> _uiState.value.approvedSpectators.contains(ip) },
            getChatHistory = {
                _uiState.value.messages.takeLast(50).map { Pair(it.senderName, it.message) }
            },
            onMessageReceived = msgLambda@ { text, sender ->
                try {
                    if (text.startsWith("{")) {
                        val obj = org.json.JSONObject(text)
                        if (obj.has("type")) {
                            val type = obj.getString("type")
if (type == "canvas") {
                                val state = com.example.MeshNetworkManager._uiState.value
                                if (state.sharedMediaType == "canvas" && state.mediaMode == "broadcast") {
                                    return@msgLambda
                                }
                                val action = obj.getString("action")
                                val id = obj.optString("id", "")
                                val color = obj.optString("color", "#000000")
                                val x = obj.optDouble("x", 0.0).toFloat()
                                val y = obj.optDouble("y", 0.0).toFloat()
                                val strokeWidth = obj.optDouble("strokeWidth", 10.0).toFloat()
                                val vm = com.example.MeshNetworkManager._uiState
                                val paths = vm.value.canvasPaths.toMutableList()
                                if (action == "clear") { paths.clear() }
                                else if (action == "undo") { if (paths.isNotEmpty()) paths.removeLast() }
                                else if (action == "start") { paths.add(com.example.DrawPath(id, androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(color)), listOf(androidx.compose.ui.geometry.Offset(x, y)), strokeWidth)) }
                                else if (action == "move") {
                                    val index = paths.indexOfLast { it.id == id }
                                    if (index != -1) {
                                        val oldPath = paths[index]
                                        paths[index] = oldPath.copy(points = oldPath.points + androidx.compose.ui.geometry.Offset(x, y))
                                    }
                                }
                                vm.update { it.copy(canvasPaths = paths) }
                                meshRouter.routeLocalMessage(text)
                                com.example.MeshNetworkManager.webServerManager?.broadcastMessage(text, sender)
                                return@msgLambda
                            } else if (type == "physics") {
                                com.example.MeshNetworkManager.webServerManager?.broadcastMessage(text, sender)
                                return@msgLambda
                            } else if (type == "call_offer") {
                                com.example.CallManager.handleCallOffer(obj) { msg ->
                                    meshRouter.routeLocalMessage(msg)
                                    com.example.MeshNetworkManager.webServerManager?.broadcastMessage(msg, com.example.MeshNetworkManager.localNodeId)
                                }
                                return@msgLambda
                            } else if (type == "call_answer") {
                                com.example.CallManager.handleCallAnswer(obj)
                                return@msgLambda
                            } else if (type == "call_end") {
                                com.example.CallManager.handleCallEnd()
                                return@msgLambda
                            } else if (type == "lifeline_request") {
                                com.example.LifelineManager.handleLifelineRequest(appContext, obj, meshRouter)
                                return@msgLambda
                            } else if (type == "lifeline_response") {
                                val reqId = obj.optString("reqId")
                                val status = obj.optInt("status")
                                val recipientId = obj.optString("recipientId")
                                if (recipientId == com.example.MeshNetworkManager.localNodeId) {
                                    val responseBody = obj.optString("response")
                                    val preview = if (responseBody.length > 200) responseBody.substring(0, 200) + "..." else responseBody
                                    
                                    // Inject into chat
                                    val chatPayload = org.json.JSONObject().apply {
                                        put("type", "chat")
                                        put("message", "Lifeline Proxy Response ($status) [ID: $reqId]:\n$preview")
                                        put("senderName", "Lifeline Bridge")
                                    }.toString()
                                    meshRouter.processIncomingPacket(
                                        com.example.MeshRouter.NetworkMessage(
                                            messageId = java.util.UUID.randomUUID().toString(),
                                            senderId = "system",
                                            senderName = "Lifeline Bridge",
                                            ttl = 1,
                                            payload = chatPayload,
                                            timestamp = System.currentTimeMillis()
                                        )
                                    )
                                    return@msgLambda
                                } else {
                                    // Re-route it in the mesh so it reaches the original sender
                                    meshRouter.routeLocalMessage(text)
                                    com.example.MeshNetworkManager.webServerManager?.broadcastMessage(text, com.example.MeshNetworkManager.localNodeId)
                                }
                                return@msgLambda
                            } else if (type in listOf("tictactoe", "connect4", "ludo", "chess", "shared_media")) {


                                meshRouter.routeLocalMessage(text)
                                com.example.MeshNetworkManager.webServerManager?.broadcastMessage(text, sender)
                                if (type == "tictactoe") { com.example.MeshNetworkManager._uiState.update { it.copy(ticTacToeState = com.example.TicTacToeState.fromJson(obj.getJSONObject("state").toString())) } }
                                else if (type == "connect4") { com.example.MeshNetworkManager._uiState.update { it.copy(connect4State = com.example.Connect4State.fromJson(obj.getJSONObject("state").toString())) } }
                                else if (type == "ludo") { com.example.MeshNetworkManager._uiState.update { it.copy(ludoState = com.example.LudoState.fromJson(obj.getJSONObject("state").toString())) } }
                                return@msgLambda
                            }
                        }
                    }
                } catch(e: Exception) { e.printStackTrace() }

                DiagnosticLogger.log("Message Lifecycle", "Host Received", "Host phone successfully parsed the JSON payload", EventStatus.SUCCESS)
                val webMsg = ChatMessage(
                    senderName = sender,
                    senderId = "web_client",
                    message = text,
                    isFromMe = false
 )
                _uiState.update { it.copy(
                    messages = it.messages + webMsg
 ) }
                meshRouter.routeLocalMessage("${sender}: $text")
                webServerManager?.broadcastMessage(text, sender)
            }
 )

        hotspotManager = HotspotManager(appContext)
        bleMeshManager = BleMeshManager(appContext)
        wifiSocketManager = WifiSocketManager(appContext, localNodeId)
        
        initializeKeys()
        CallManager.init(appContext)
        if (highSpeedFileTransferManager == null) {
            highSpeedFileTransferManager = HighSpeedFileTransferManager(appContext).apply {
                startServer()
            }
        }
        
        wifiSocketManager?.start()
        
        _uiState.value = _uiState.value.copy(
            messages = listOf(
                ChatMessage(
                    senderName = "System",
                    senderId = "system",
                    message = "Network Ready.",
                    isFromMe = false
 )
 )
 )
    }
}

class MeshForegroundService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    override fun onCreate() {
        super.onCreate()
        
        createNotificationChannel()
        val notification = NotificationCompat.Builder(this, "MeshChatServiceChannel")
            .setContentTitle("MeshChat Network Alive")
            .setContentText("Routing messages in the background...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(1, notification)
        }
        
        scope.launch {
            try {
                MeshNetworkManager.initialize(applicationContext)

                val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MeshChat::WakeLock")
                wakeLock?.acquire()

                val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                wifiLock = wifiManager.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "MeshChat::WifiLock")
                wifiLock?.acquire()

                startObserving()
            } catch (e: Exception) {
                Log.e("MeshForegroundService", "Initialization error", e)
            }
        }
    }

    private fun startObserving() {
        val manager = MeshNetworkManager
        
        scope.launch {
            var lastIp = ""
            while (true) {
                val ip = NetworkUtils.getLocalIpAddress()
                if (ip != lastIp) {
                    if (ip != "127.0.0.1" && ip.isNotEmpty()) {
                        DiagnosticLogger.log("Network", "IP Assignment", "OS granted valid local IP: $ip", EventStatus.SUCCESS)
                    } else if (ip == "127.0.0.1") {
                        DiagnosticLogger.log("Network", "IP Assignment", "No external IP, using loopback (127.0.0.1)", EventStatus.INFO)
                    }
                    lastIp = ip
                }
                com.example.MeshNetworkManager._uiState.value = com.example.MeshNetworkManager._uiState.value.copy(hotspotIp = ip)
                kotlinx.coroutines.delay(3000)
            }
        }
        
        scope.launch {
            manager.meshRouter.incomingMessages.collect { networkMessage ->
                DiagnosticLogger.logMeshToWebHop(networkMessage.messageId, networkMessage.senderId, networkMessage.payload)
                var handledSpecial = false
                try {
                    if (networkMessage.payload.startsWith("{")) {
                        val obj = org.json.JSONObject(networkMessage.payload)
                        if (obj.has("type")) {
                            val type = obj.getString("type")
if (type == "canvas") {
                                val state = com.example.MeshNetworkManager._uiState.value
                                if (state.sharedMediaType == "canvas" && state.mediaMode == "broadcast") {
                                    if (networkMessage.senderId != state.mediaHostId) {
                                        return@collect
                                    }
                                }
                                handledSpecial = true
                                val action = obj.getString("action")
                                val id = obj.optString("id", "")
                                val color = obj.optString("color", "#000000")
                                val x = obj.optDouble("x", 0.0).toFloat()
                                val y = obj.optDouble("y", 0.0).toFloat()
                                val strokeWidth = obj.optDouble("strokeWidth", 10.0).toFloat()
                                val data = obj.optString("data", "")
                                
                                val vm = MeshNetworkManager._uiState
                                var paths = vm.value.canvasPaths.toMutableList()
                                var newLasers = vm.value.lasers.toMutableMap()
                                var newBg = vm.value.canvasBackground
                                
                                if (action == "laser") {
                                    newLasers[networkMessage.senderId] = androidx.compose.ui.geometry.Offset(x, y)
                                } else if (action == "bg") {
                                    newBg = data
                                } else if (action == "clear") {
                                    paths.clear()
                                    newLasers.clear()
                                    newBg = ""
                                } else if (action == "undo") {
                                    if (paths.isNotEmpty()) paths.removeLast()
                                } else if (action == "start") {
                                    paths.add(com.example.DrawPath(id, androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(color)), listOf(androidx.compose.ui.geometry.Offset(x, y)), strokeWidth))
                                } else if (action == "move" || action == "end") {
                                    val index = paths.indexOfLast { it.id == id }
                                    if (index != -1) {
                                        val oldPath = paths[index]
                                        val newPoints = if (action == "end") oldPath.points else oldPath.points + androidx.compose.ui.geometry.Offset(x, y)
                                        
                                        // Auto snap on end
                                        if (action == "end" && newPoints.size > 10) {
                                            val start = newPoints.first()
                                            val end = newPoints.last()
                                            val dist = Math.hypot((start.x - end.x).toDouble(), (start.y - end.y).toDouble())
                                            if (dist < 0.05) {
                                                var minX = 1f; var maxX = 0f; var minY = 1f; var maxY = 0f
                                                newPoints.forEach { p ->
                                                    if (p.x < minX) minX = p.x
                                                    if (p.x > maxX) maxX = p.x
                                                    if (p.y < minY) minY = p.y
                                                    if (p.y > maxY) maxY = p.y
                                                }
                                                val cx = (minX + maxX) / 2f
                                                val cy = (minY + maxY) / 2f
                                                val radius = maxOf(maxX - minX, maxY - minY) / 2f
                                                
                                                val circlePoints = mutableListOf<androidx.compose.ui.geometry.Offset>()
                                                for (i in 0..36) {
                                                    val angle = i * 10 * Math.PI / 180.0
                                                    circlePoints.add(androidx.compose.ui.geometry.Offset((cx + radius * Math.cos(angle)).toFloat(), (cy + radius * Math.sin(angle)).toFloat()))
                                                }
                                                paths[index] = oldPath.copy(points = circlePoints)
                                            } else {
                                                paths[index] = oldPath.copy(points = newPoints)
                                            }
                                        } else {
                                            paths[index] = oldPath.copy(points = newPoints)
                                        }
                                    } else {
                                        paths.add(com.example.DrawPath(id, androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(color)), listOf(androidx.compose.ui.geometry.Offset(x, y)), strokeWidth))
                                    }
                                }
                                vm.update { it.copy(canvasPaths = paths, lasers = newLasers, canvasBackground = newBg) }
                            } else if (type == "randomizer") {
                                handledSpecial = true
                                val rId = obj.getString("id")
                                val rType = obj.getString("rType")
                                val prompt = obj.getString("prompt")
                                val player = obj.getString("player")
                                val randState = com.example.RandomizerState(rId, rType, prompt, player)
                                com.example.MeshNetworkManager._uiState.update { it.copy(activeRandomizer = randState) }
                                kotlinx.coroutines.GlobalScope.launch {
                                    kotlinx.coroutines.delay(10000)
                                    com.example.MeshNetworkManager._uiState.update { if (it.activeRandomizer?.id == rId) it.copy(activeRandomizer = null) else it }
                                }
                            } else if (type == "poll_start") {
                                handledSpecial = true
                                val pId = obj.getString("id")
                                val q = obj.getString("q")
                                val opts = obj.getString("options").split("|")
                                val attUrl = obj.optString("attachmentUrl", "")
                                val poll = com.example.PollState(pId, q, opts, emptyMap(), networkMessage.senderId, attUrl)
                                com.example.MeshNetworkManager._uiState.update { it.copy(activePoll = poll) }
                            } else if (type == "poll_vote") {
                                handledSpecial = true
                                val pId = obj.getString("id")
                                val opt = obj.getInt("opt")
                                com.example.MeshNetworkManager._uiState.update { state ->
                                    state.activePoll?.let { poll ->
                                        if (poll.id == pId) {
                                            val newVotes = poll.votes.toMutableMap()
                                            newVotes[networkMessage.senderId] = opt
                                            state.copy(activePoll = poll.copy(votes = newVotes))
                                        } else state
                                    } ?: state
                                }
                            } else if (type == "poll_close") {
                                handledSpecial = true
                                com.example.MeshNetworkManager._uiState.update { it.copy(activePoll = null) }
                            } else if (type == "canvas_sync") {
                                handledSpecial = true
                                val pathsArr = obj.optJSONArray("paths")
                                val newPaths = mutableListOf<com.example.DrawPath>()
                                if (pathsArr != null) {
                                    for (i in 0 until pathsArr.length()) {
                                        val pObj = pathsArr.getJSONObject(i)
                                        val cId = pObj.getString("id")
                                        val colorStr = pObj.getString("color")
                                        val sw = pObj.getDouble("strokeWidth").toFloat()
                                        val ptsArr = pObj.getJSONArray("points")
                                        val pts = mutableListOf<androidx.compose.ui.geometry.Offset>()
                                        for (j in 0 until ptsArr.length()) {
                                            val ptObj = ptsArr.getJSONObject(j)
                                            pts.add(androidx.compose.ui.geometry.Offset(ptObj.getDouble("x").toFloat(), ptObj.getDouble("y").toFloat()))
                                        }
                                        newPaths.add(com.example.DrawPath(cId, androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(colorStr)), pts, sw))
                                    }
                                }
                                val bg = obj.optString("bg", "")
                                MeshNetworkManager._uiState.update { it.copy(canvasPaths = newPaths, canvasBackground = bg) }
                            } else if (type == "sys_sync_request") {
                                handledSpecial = true
                                val state = MeshNetworkManager._uiState.value
                                if (state.sharedMediaType != "none" && state.mediaHostId == manager.localNodeId) {
                                    val inviteMsg = org.json.JSONObject().apply {
                                        put("type", "media_invite")
                                        put("mediaType", state.sharedMediaType)
                                        put("url", state.sharedMediaUrl)
                                    }.toString()
                                    manager.meshRouter.routeLocalMessage(inviteMsg)

                                    if (state.sharedMediaType == "canvas") {
                                        val canvasMsg = org.json.JSONObject().apply {
                                            put("type", "canvas_sync")
                                            val pathsArr2 = org.json.JSONArray()
                                            state.canvasPaths.forEach { p ->
                                                val pObj = org.json.JSONObject()
                                                pObj.put("id", p.id)
                                                val hex = String.format("#%02X%02X%02X", (p.color.red * 255).toInt(), (p.color.green * 255).toInt(), (p.color.blue * 255).toInt())
                                                pObj.put("color", hex)
                                                pObj.put("strokeWidth", p.strokeWidth.toDouble())
                                                val pts = org.json.JSONArray()
                                                p.points.forEach { pt ->
                                                    val ptObj = org.json.JSONObject()
                                                    ptObj.put("x", pt.x.toDouble())
                                                    ptObj.put("y", pt.y.toDouble())
                                                    pts.put(ptObj)
                                                }
                                                pObj.put("points", pts)
                                                pathsArr2.put(pObj)
                                            }
                                            put("paths", pathsArr2)
                                            put("bg", state.canvasBackground)
                                        }.toString()
                                        manager.meshRouter.routeLocalMessage(canvasMsg)
                                    } else if (state.sharedMediaType == "chess") {
                                        val msg = org.json.JSONObject().apply {
                                            put("type", "chess")
                                            put("state", state.chessState.toJson())
                                        }.toString()
                                        manager.meshRouter.routeLocalMessage(msg)
                                    } else if (state.sharedMediaType == "tictactoe") {
                                        val msg = org.json.JSONObject().apply {
                                            put("type", "tictactoe")
                                            put("state", org.json.JSONObject(state.ticTacToeState.toJson()))
                                        }.toString()
                                        manager.meshRouter.routeLocalMessage(msg)
                                    }
                                }
                                if (state.activePoll != null && state.activePoll!!.hostId == manager.localNodeId) {
                                    val pollMsg = org.json.JSONObject().apply {
                                        put("type", "poll")
                                        put("id", state.activePoll!!.id)
                                        put("q", state.activePoll!!.question)
                                        val pathsArr2 = org.json.JSONArray()
                                        state.activePoll!!.options.forEach { pathsArr2.put(it) }
                                        put("opts", pathsArr2)
                                        put("url", state.activePoll!!.attachmentUrl)
                                    }.toString()
                                    manager.meshRouter.routeLocalMessage(pollMsg)
                                }
                            } else if (type == "chess") {
                                handledSpecial = true
                                val stateJson = obj.getJSONObject("state").toString()
                                val newState = ChessState.fromJson(stateJson)
                                MeshNetworkManager._uiState.update { it.copy(chessState = newState) }
                            } else if (type == "tictactoe") {
                                handledSpecial = true
                                val stateJson = obj.getJSONObject("state").toString()
                                val newState = com.example.TicTacToeState.fromJson(stateJson)
                                MeshNetworkManager._uiState.update { it.copy(ticTacToeState = newState) }
                            } else if (type == "connect4") {
                                handledSpecial = true
                                val stateJson = obj.getJSONObject("state").toString()
                                val newState = com.example.Connect4State.fromJson(stateJson)
                                MeshNetworkManager._uiState.update { it.copy(connect4State = newState) }
                            } else if (type == "ludo") {
                                handledSpecial = true
                                val stateJson = obj.getJSONObject("state").toString()
                                val newState = LudoState.fromJson(stateJson)
                                MeshNetworkManager._uiState.update { it.copy(ludoState = newState) }
                            } else if (type == "shared_media") {
                                handledSpecial = true
                                val mediaType = obj.getString("mediaType")
                                val mediaUrl = obj.optString("url", "")
                                if (mediaType == "none") {
                                    MeshNetworkManager._uiState.update { state -> 
                                        state.copy(sharedMediaType = "none", sharedMediaUrl = "", incomingInvite = null)
                                    }
                                } else {
                                    // Set an invite instead of forcing them in immediately
                                    MeshNetworkManager._uiState.update { state -> 
                                        state.copy(incomingInvite = com.example.MediaInvite(mediaType, mediaUrl))
                                    }
                                }
                            
                            } else if (type == "chat") {
                                handledSpecial = true
                                val messageText = obj.getString("message")
                                val senderNameFallback = obj.optString("senderName", "Unknown")
                                val isBurner = obj.optBoolean("isBurner", false)
                                val msgBurnerId = obj.optString("burnerId", "")
                                val recipientId = if (obj.has("recipientId") && !obj.isNull("recipientId")) obj.getString("recipientId") else null
                                val isEmergency = obj.optBoolean("isEmergency", false)

                                val myNodeId = com.example.MeshNetworkManager.localNodeId
                                // Private DM filtering: If recipientId is specified, ensure it is directed to me (or sent by me)
                                if (recipientId != null && recipientId != myNodeId && networkMessage.senderId != myNodeId) {
                                    // Not addressed to this node, ignore silently
                                    return@collect
                                }
                                
                                val state = com.example.MeshNetworkManager._uiState.value
                                
                                // Security constraint: If we are in a burner room, drop non-burner chats.
                                // If we are not in a burner room, drop burner chats (or just display a generic "encrypted text").
                                val displayMessage = if (state.isBurnerRoomActive && state.burnerRoomId == msgBurnerId) {
                                    messageText
                                } else if (state.isBurnerRoomActive && msgBurnerId != state.burnerRoomId) {
                                    null // Drop it
                                } else if (!state.isBurnerRoomActive && isBurner) {
                                    "🔥 [Encrypted Burner Message]"
                                } else {
                                    messageText
                                }
                                
                                if (displayMessage != null) {
                                    val senderHandle = obj.optString("senderHandle", "")
                                    if (senderHandle.isNotBlank()) {
                                        com.example.MeshNetworkManager._uiState.update { state ->
                                            state.copy(knownUserIds = state.knownUserIds + (networkMessage.senderId to senderHandle))
                                        }
                                    }
                                    val newChatMessage = ChatMessage(
                                        id = networkMessage.messageId,
                                        senderName = if (networkMessage.senderName.isNotBlank()) networkMessage.senderName else senderNameFallback,
                                        senderHandle = senderHandle,
                                        senderId = networkMessage.senderId,
                                        recipientId = recipientId,
                                        message = displayMessage,
                                        isFromMe = false,
                                        timestamp = networkMessage.timestamp,
                                        isBurner = isBurner,
                                        isEmergency = isEmergency
                                    )
                                    com.example.MeshNetworkManager._uiState.update { it.copy(
                                        messages = it.messages + newChatMessage
                                    ) }

                                    val isGhostMode = com.example.MeshNetworkManager._uiState.value.isGhostMode
                                    if (!isBurner && !isGhostMode) {
                                        scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                            try {
                                                com.example.data.MeshChatDatabase.getDatabase(applicationContext).chatDao().insertMessage(
                                                    com.example.data.ChatMessageEntity(
                                                        senderId = newChatMessage.senderId,
                                                        senderName = newChatMessage.senderName,
                                                        message = newChatMessage.message,
                                                        timestamp = newChatMessage.timestamp,
                                                        isFromMe = false
                                                    )
                                                )
                                            } catch (e: Exception) {
                                                e.printStackTrace()
                                            }
                                        }
                                        if (!MainActivity.isAppInForeground) {
                                            val notifPrefix = if (recipientId != null) "[Private DM] " else ""
                                            NotificationHelper.showMessageNotification(
                                                applicationContext,
                                                notifPrefix + newChatMessage.senderName,
                                                newChatMessage.message
                                            )
                                        }
                                    }
                                }
                            } else if (type == "sos_beacon") {
                                handledSpecial = true
                                val sId = obj.optString("senderId", networkMessage.senderId)
                                val sName = obj.optString("senderName", if (networkMessage.senderName.isNotBlank()) networkMessage.senderName else "Unknown Peer")
                                val sHandle = obj.optString("senderHandle", "")
                                val alertMsg = obj.optString("message", "Immediate Assistance Required!")
                                val lat = if (obj.has("lat")) obj.getDouble("lat") else null
                                val lng = if (obj.has("lng")) obj.getDouble("lng") else null
                                val ts = obj.optLong("timestamp", networkMessage.timestamp)

                                val beaconAlert = com.example.SOSBeaconAlert(
                                    senderId = sId,
                                    senderName = sName,
                                    senderHandle = sHandle,
                                    message = alertMsg,
                                    lat = lat,
                                    lng = lng,
                                    timestamp = ts
                                )

                                com.example.MeshNetworkManager._uiState.update {
                                    it.copy(activeSOSAlert = beaconAlert)
                                }

                                if (!MainActivity.isAppInForeground) {
                                    NotificationHelper.showMessageNotification(
                                        applicationContext,
                                        "🚨 EMERGENCY SOS BEACON: $sName",
                                        alertMsg
                                    )
                                }
                            } else if (type == "sos_cancel") {
                                handledSpecial = true
                                val sId = obj.optString("senderId", networkMessage.senderId)
                                com.example.MeshNetworkManager._uiState.update {
                                    if (it.activeSOSAlert?.senderId == sId) {
                                        it.copy(activeSOSAlert = null)
                                    } else it
                                }
                            } else if (type == "burner_sync") {
                                handledSpecial = true
                                val action = obj.optString("action")
                                val bId = obj.optString("burnerId")
                                val duration = obj.optInt("duration", 300)
                                val initiator = obj.optString("initiator", "Someone")
                                val user = obj.optString("user", "")
                                
                                val state = com.example.MeshNetworkManager._uiState.value
                                
                                if (action == "start") {
                                    if (!state.isBurnerRoomActive) {
                                        // Auto-join the burner room!
                                        com.example.MeshNetworkManager._uiState.update { 
                                            it.copy(
                                                isBurnerRoomActive = true,
                                                burnerRoomId = bId,
                                                burnerRoomCountdown = duration,
                                                activeBurnerKeys = listOf(state.localUserName, initiator)
                                            )
                                        }
                                        com.example.MeshNetworkManager.webServerManager?.broadcastMessage("Burner room initiated by $initiator", "System")
                                        
                                        // Start local countdown
                                        val sysMsg = ChatMessage(id = java.util.UUID.randomUUID().toString(), senderId = "System", senderName = "System", message = "🔥 You have entered a Burner Room with $initiator.\nAll messages will self-destruct in $duration seconds.", timestamp = System.currentTimeMillis(), isFromMe = false, isBurner = true)
                                        com.example.MeshNetworkManager._uiState.update { it.copy(messages = it.messages + sysMsg) }
                                    }
                                } else if (action == "leave" && state.isBurnerRoomActive && state.burnerRoomId == bId) {
                                    val newKeys = state.activeBurnerKeys.filter { it != user }
                                    com.example.MeshNetworkManager._uiState.update { it.copy(activeBurnerKeys = newKeys) }
                                    val sysMsg = ChatMessage(id = java.util.UUID.randomUUID().toString(), senderId = "System", senderName = "System", message = "$user left the burner room.", timestamp = System.currentTimeMillis(), isFromMe = false, isBurner = true)
                                    com.example.MeshNetworkManager._uiState.update { it.copy(messages = it.messages + sysMsg) }
                                }
                            } else if (type == "sys_handshake") {

                                handledSpecial = true
                                val ssid = obj.getString("ssid")
                                val pwd = obj.getString("pwd")
                                val ip = obj.getString("ip")
                                val sysMsg = ChatMessage(
                                    senderName = "System",
                                    isFromMe = false,
                                    message = "High-Speed Mesh Found!\nHost: $ssid\nPassword: $pwd"
                                )
                                MeshNetworkManager._uiState.update { it.copy(
                                    discoveredHostSsid = ssid,
                                    discoveredHostPwd = pwd,
                                    discoveredHostIp = ip,
                                    messages = listOf(sysMsg) + it.messages
                                ) }
                            } else if (type == "sys_identity") {
                                handledSpecial = true
                                val id = obj.getString("id")
                                val name = obj.getString("name")
                                val uId = obj.optString("usernameId", "")
                                val vm = MeshNetworkManager._uiState
                                val users = vm.value.knownUsers.toMutableMap()
                                val uIds = vm.value.knownUserIds.toMutableMap()
                                users[id] = name
                                if (uId.isNotEmpty()) uIds[id] = uId
                                vm.update { it.copy(knownUsers = users, knownUserIds = uIds) }
                            } else if (type == "sys_state_sync") {
                                handledSpecial = true
                                val vm = MeshNetworkManager._uiState
                                
                                val msgArray = obj.optJSONArray("messages")
                                val newMessages = mutableListOf<ChatMessage>()
                                if (msgArray != null) {
                                    for (i in 0 until msgArray.length()) {
                                        val mObj = msgArray.getJSONObject(i)
                                        newMessages.add(ChatMessage(
                                            id = mObj.getString("id"),
                                            senderId = mObj.getString("senderId"),
                                            senderName = mObj.getString("senderName"),
                                            message = mObj.getString("message"),
                                            timestamp = mObj.getLong("timestamp"),
                                            isFromMe = mObj.getString("senderId") == MeshNetworkManager.localNodeId
                                        ))
                                    }
                                }
                                
                                val usersObj = obj.optJSONObject("users")
                                val newUsers = vm.value.knownUsers.toMutableMap()
                                if (usersObj != null) {
                                    val keys = usersObj.keys()
                                    while (keys.hasNext()) {
                                        val k = keys.next()
                                        newUsers[k] = usersObj.getString(k)
                                    }
                                }
                                
                                vm.update { it.copy(
                                    messages = (it.messages + newMessages).distinctBy { msg -> msg.id }.sortedBy { msg -> msg.timestamp },
                                    knownUsers = newUsers
                                )}
                            } else if (type == "location") {
                                handledSpecial = true
                                val id = obj.getString("id")
                                val name = obj.getString("name")
                                val lat = obj.getDouble("lat")
                                val lng = obj.getDouble("lng")
                                val vm = MeshNetworkManager._uiState
                                val locs = vm.value.userLocations.toMutableMap()
                                locs[id] = LocationMessage(id = id, name = name, lat = lat, lng = lng)
                                vm.update { it.copy(userLocations = locs) }
                            } else if (type == "radar_ping") {
                                handledSpecial = true
                                val myId = MeshNetworkManager.localNodeId
                                val myName = MeshNetworkManager._uiState.value.localUserName
                                val myLoc = MeshNetworkManager._uiState.value.userLocations[myId]
                                if (myLoc != null) {
                                    val reply = """{"type":"location","id":"$myId","name":"$myName","lat":${myLoc.lat},"lng":${myLoc.lng}}"""
                                    MeshNetworkManager.meshRouter.routeLocalMessage(reply)
                                    MeshNetworkManager.webServerManager?.broadcastMessage(reply, "Radar")
                                }
                            }
                        }
                    }
                } catch (e: Exception) { e.printStackTrace() }

                com.example.MeshNetworkManager.webServerManager?.broadcastMessage(networkMessage.payload, if (networkMessage.senderName.isNotBlank()) networkMessage.senderName else "Peer_${networkMessage.senderId.take(4)}")
                if (!handledSpecial) {
                    val newChatMessage = ChatMessage(
                        id = networkMessage.messageId,
                        senderName = if (networkMessage.senderName.isNotBlank()) networkMessage.senderName else "Peer_${networkMessage.senderId.take(4)}",
                        senderId = networkMessage.senderId,
                        message = networkMessage.payload,
                        isFromMe = false,
                        timestamp = networkMessage.timestamp
                    )
                    com.example.MeshNetworkManager._uiState.update { it.copy(
                        messages = it.messages + newChatMessage
                    ) }
                    val isGhostMode = com.example.MeshNetworkManager._uiState.value.isGhostMode
                    if (!isGhostMode) {
                        scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                            try {
                                com.example.data.MeshChatDatabase.getDatabase(applicationContext).chatDao().insertMessage(
                                    com.example.data.ChatMessageEntity(
                                        senderId = newChatMessage.senderId,
                                        senderName = newChatMessage.senderName,
                                        message = newChatMessage.message,
                                        timestamp = newChatMessage.timestamp,
                                        isFromMe = false
                                    )
                                )
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                        if (!MainActivity.isAppInForeground) {
                            NotificationHelper.showMessageNotification(
                                applicationContext,
                                newChatMessage.senderName,
                                newChatMessage.message
                            )
                        }
                    }
                }
                DiagnosticLogger.logMeshToWebHop(networkMessage.messageId, networkMessage.senderId, networkMessage.payload)
            }
        }

        scope.launch {
            manager.meshRouter.outboundBroadcasts.collect { networkMessage ->
                try {
                    val safePayload = networkMessage.payload.replace("\"", "\\\"").replace("\n", "\\n")
                    val json = """{"messageId":"${networkMessage.messageId}","senderId":"${networkMessage.senderId}","senderName":"${networkMessage.senderName.replace("\"", "\\\"")}","ttl":${networkMessage.ttl},"payload":"$safePayload","timestamp":${networkMessage.timestamp},"signature":"${networkMessage.signature}","publicKey":"${networkMessage.publicKey}"}"""
                    
                    val originSource = if (networkMessage.senderId == manager.localNodeId) "Local App -> Mesh" else "Web/Other -> Mesh"

                    if (manager.wifiSocketManager?.hasActiveConnections() == true) {
                        DiagnosticLogger.logHop(originSource, networkMessage.messageId, "Interface: Wi-Fi TCP, Payload: $safePayload")
                        DiagnosticLogger.log("Message Lifecycle", "Wi-Fi Broadcast", "Attempting to send to all connected TCP sockets", EventStatus.PENDING)
                        manager.wifiSocketManager?.broadcastPacket(json)
                        DiagnosticLogger.log("Message Lifecycle", "Wi-Fi Broadcast", "Successfully broadcast to TCP sockets", EventStatus.SUCCESS)
                    } else {
                        DiagnosticLogger.log("Message Lifecycle", "Wi-Fi Broadcast", "No active TCP connections to broadcast to", EventStatus.INFO)
                    }

                    // SMART ROUTING LOGIC
                    val isHighBandwidth = safePayload.contains("\"type\":\"call_offer\"") || 
                                          safePayload.contains("\"type\":\"call_answer\"") || 
                                          safePayload.contains("\"type\":\"call_audio\"") ||
                                          safePayload.contains("\"type\":\"shared_media\"") ||
                                          safePayload.length > 1024

                    if (isHighBandwidth && manager.wifiSocketManager?.hasActiveConnections() == true) {
                        DiagnosticLogger.log("Message Lifecycle", "Smart Routing", "High-bandwidth packet detected. Bypassing BLE to prevent congestion. Using Wi-Fi exclusively.", EventStatus.INFO)
                    } else {
                        scope.launch {
                            DiagnosticLogger.logHop(originSource, networkMessage.messageId, "Interface: BLE Mesh, Payload: $safePayload")
                            DiagnosticLogger.log("Message Lifecycle", "BLE Broadcast", "Attempting to send to nearby Bluetooth nodes", EventStatus.PENDING)
                            manager.bleMeshManager?.broadcastPacket(json)
                            DiagnosticLogger.log("Message Lifecycle", "BLE Broadcast", "Successfully broadcast via BLE GATT", EventStatus.SUCCESS)
                            kotlinx.coroutines.delay(2500)
                        }
                    }
                } catch(e: Exception) {
                    Log.e("MeshForeground", "Error broadcasting outbound packet", e)
                    DiagnosticLogger.log("Message Lifecycle", "Broadcast Error", "Error broadcasting outbound packet: ${e.message}", EventStatus.ERROR)
                }
            }
        }
        scope.launch {
            var currentBleNodes = emptyList<MeshNode>()
            var currentWifiNodes = emptyMap<String, String>()

            fun updateCombinedNodes() {
                val wifiNodes = currentWifiNodes.map { (ip, name) -> 
                    MeshNode(id = ip, name = name, signalStrength = 100) 
                }
                val combined = (currentBleNodes + wifiNodes).distinctBy { it.id }
                com.example.MeshNetworkManager._uiState.value = com.example.MeshNetworkManager._uiState.value.copy(
                    connectedNodes = combined,
                    isWifiConnected = currentWifiNodes.isNotEmpty()
                )
            }

            scope.launch {
                manager.bleMeshManager?.activeNodes?.collect { nodes ->
                    currentBleNodes = nodes
                    updateCombinedNodes()
                }
            }
            
            scope.launch {
                manager.wifiSocketManager?.activeWifiNodes?.collect { nodesMap ->
                    currentWifiNodes = nodesMap
                    updateCombinedNodes()
                }
            }
        }


        scope.launch {
            manager.hotspotManager?.hotspotState?.collect { hotspotInfo ->
                com.example.MeshNetworkManager._uiState.value = com.example.MeshNetworkManager._uiState.value.copy(
                    isHotspotActive = hotspotInfo.isActive,
                    hotspotSsid = hotspotInfo.ssid,
                    hotspotPassword = hotspotInfo.password,
                    hotspotError = hotspotInfo.error
 )
                if (hotspotInfo.isActive) {
                    scope.launch {
                        var newIp = NetworkUtils.getLocalIpAddress()
                        var retries = 0
                        while (newIp == "127.0.0.1" && retries < 15) {
                            kotlinx.coroutines.delay(1000)
                            newIp = NetworkUtils.getLocalIpAddress()
                            retries++
                        }
                        com.example.MeshNetworkManager._uiState.value = com.example.MeshNetworkManager._uiState.value.copy(hotspotIp = newIp)
                        com.example.LocalDnsServer.start(newIp)
                        if (newIp != "127.0.0.1") {
                            val hs = JSONObject()
                            hs.put("type", "sys_handshake")
                            hs.put("ssid", hotspotInfo.ssid)
                            hs.put("pwd", hotspotInfo.password)
                            hs.put("ip", newIp)
                            hs.put("isPrivate", com.example.MeshNetworkManager.uiState.value.isPrivateRoom)
                            com.example.MeshNetworkManager.meshRouter.routeLocalMessage(hs.toString())
                        }
                        
                        com.example.MeshNetworkManager.webServerManager?.stopServer()
                        kotlinx.coroutines.delay(1000)
                        com.example.MeshNetworkManager.webServerManager?.startServer()
                        com.example.MeshNetworkManager._uiState.update { it.copy(
                            messages = it.messages + ChatMessage(
                                senderName = "System",
                                senderId = "system",
                                message = "Local Hook Active. Web Server is running on " + newIp + ". Tell others to scan QR code to connect.",
                                isFromMe = false
                            ),
                            isWebServerRunning = true
                        ) }
                    }
                } else {
                    // Ensure it is running even without hotspot
                    com.example.MeshNetworkManager.webServerManager?.startServer(8080)
                    com.example.MeshNetworkManager._uiState.update { it.copy(isWebServerRunning = true) }
                }
            }
        }

        scope.launch {
            manager.bleMeshManager?.incomingPackets?.collect { json ->
                processIncomingJson(json)
            }
        }
        scope.launch {
            manager.wifiSocketManager?.incomingPackets?.collect { json ->
                processIncomingJson(json)
            }
        }
    }

    private fun processIncomingJson(json: String) {
        if (json.startsWith("SYS_WIFI_PEER_JOINED:")) {
            val ip = json.removePrefix("SYS_WIFI_PEER_JOINED:")
            // We are the host, let's sync state to this new peer
            val currentState = MeshNetworkManager._uiState.value
            if (currentState.isHotspotActive) {
                // Send chat history (last 50 messages)
                val recentMessages = currentState.messages.takeLast(50)
                val syncObj = JSONObject().apply {
                    put("type", "sys_state_sync")
                    val msgArray = org.json.JSONArray()
                    recentMessages.forEach { msg ->
                        val mObj = JSONObject().apply {
                            put("id", msg.id)
                            put("senderId", msg.senderId)
                            put("senderName", msg.senderName)
                            put("message", msg.message)
                            put("timestamp", msg.timestamp)
                        }
                        msgArray.put(mObj)
                    }
                    put("messages", msgArray)
                    
                    // Add known users
                    val usersObj = JSONObject()
                    currentState.knownUsers.forEach { (k, v) -> usersObj.put(k, v) }
                    put("users", usersObj)
                }
                
                MeshNetworkManager.meshRouter.routeLocalMessage(syncObj.toString())
                MeshNetworkManager.meshRouter.routeLocalMessage("{\"type\":\"sys_sync_request\"}")
            }
            return
        } else if (json == "SYS_ROOM_CLOSED") {
            MeshNetworkManager._uiState.update { 
                it.copy(
                    isEmergencyMode = false,
                    messages = it.messages + ChatMessage(id = java.util.UUID.randomUUID().toString(), senderId = "System", senderName = "System", message = "The Host has closed the room. Disconnected.", timestamp = System.currentTimeMillis(), isFromMe = false)
                )
            }
            return
        }

        try {
            val obj = JSONObject(json)
            if (obj.has("type") && obj.getString("type") == "handshake") {
                val ssid = obj.getString("ssid")
                val pwd = obj.getString("pwd")
                val ip = obj.getString("ip")
                val currentState = MeshNetworkManager._uiState.value
                MeshNetworkManager._uiState.value = currentState.copy(
                    discoveredHostSsid = ssid,
                    discoveredHostPwd = pwd,
                    discoveredHostIp = ip
                )
                
                // BitChat-style BLE pulse beacon: Auto-join rooms without scanning QR if auto-join is enabled & room is public
                if (currentState.autoJoinBeaconEnabled && 
                    !currentState.isHotspotActive && 
                    !currentState.isWifiConnected && 
                    pwd != "PRIVATE") {
                    Log.i("MeshService", "BitChat pulse beacon received for $ssid - auto-joining...")
                    DiagnosticLogger.log("BLE Pulse Beacon", "Auto-Join", "Auto-joining mesh room $ssid without QR scan", EventStatus.SUCCESS)
                    MeshNetworkManager.hotspotManager?.connectToHotspot(ssid, pwd, ip)
                }
                return
            }
            val msg = MeshRouter.NetworkMessage(
                messageId = obj.getString("messageId"),
                senderId = obj.getString("senderId"),
                ttl = obj.getInt("ttl"),
                payload = obj.getString("payload"),
                timestamp = obj.getLong("timestamp"),
                signature = obj.optString("signature", ""),
                publicKey = obj.optString("publicKey", "")
 )
            MeshNetworkManager.meshRouter.processIncomingPacket(msg)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "MeshChatServiceChannel",
                "MeshChat Background Service",
                NotificationManager.IMPORTANCE_LOW
 )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "PULSE_BLE_CHUNK") {
            val chunk = intent.getStringExtra("chunk")
            if (chunk != null) {
                MeshNetworkManager.bleMeshManager?.pulseBleChunk(chunk)
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        wakeLock?.release()
        wifiLock?.release()
        MeshNetworkManager.hotspotManager?.stopHotspot()
        com.example.LocalDnsServer.stop()
        MeshNetworkManager.webServerManager?.stopServer()
        MeshNetworkManager.bleMeshManager?.stopScanning()
        MeshNetworkManager.bleMeshManager?.stopAdvertising()
        MeshNetworkManager.wifiSocketManager?.stop()
        super.onDestroy()
    }
}
