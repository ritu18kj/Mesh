package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput
import com.example.data.ChatMessageEntity
import com.example.data.MeshChatDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val notifId = intent.getIntExtra(NotificationHelper.EXTRA_NOTIFICATION_ID, -1)
        when (intent.action) {
            NotificationHelper.ACTION_MARK_READ -> {
                if (notifId != -1) {
                    NotificationHelper.dismissNotification(context, notifId)
                }
            }
            NotificationHelper.ACTION_DECLINE_CALL -> {
                if (notifId != -1) {
                    NotificationHelper.cancelCallNotification(context)
                }
                CallManager.declineCall { payload ->
                    MeshNetworkManager.meshRouter.routeLocalMessage(payload)
                    MeshNetworkManager.webServerManager?.broadcastMessage(payload, MeshNetworkManager.localNodeId)
                }
            }
            NotificationHelper.ACTION_REPLY_MESSAGE -> {
                val remoteInput = RemoteInput.getResultsFromIntent(intent)
                val replyText = remoteInput?.getCharSequence(NotificationHelper.KEY_TEXT_REPLY)?.toString()
                if (!replyText.isNullOrBlank()) {
                    if (notifId != -1) {
                        NotificationHelper.dismissNotification(context, notifId)
                    }
                    val senderName = MeshNetworkManager.uiState.value.localUserName
                    val senderId = MeshNetworkManager.localNodeId
                    val timestamp = System.currentTimeMillis()

                    val jsonPayload = JSONObject().apply {
                        put("type", "chat")
                        put("message", replyText)
                        put("sender", senderName)
                        put("senderId", senderId)
                        put("timestamp", timestamp)
                    }.toString()

                    // Route over offline mesh
                    MeshNetworkManager.meshRouter.routeLocalMessage(jsonPayload)
                    MeshNetworkManager.webServerManager?.broadcastMessage(replyText, senderName)

                    // Persist to local Room database
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            MeshChatDatabase.getDatabase(context.applicationContext).chatDao().insertMessage(
                                ChatMessageEntity(
                                    senderId = senderId,
                                    senderName = senderName,
                                    message = replyText,
                                    timestamp = timestamp,
                                    isFromMe = true
                                )
                            )
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            }
        }
    }
}
